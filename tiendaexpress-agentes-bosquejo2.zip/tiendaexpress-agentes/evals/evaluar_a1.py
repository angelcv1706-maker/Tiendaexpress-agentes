"""Evaluación de A1 en LangSmith: conjunto dorado → experimento con métricas.

  python -m evals.evaluar_a1            # crea el dataset si no existe y corre el experimento

Requiere LANGSMITH_API_KEY y ANTHROPIC_API_KEY (con MODO_SIMULADO=1 evalúa la heurística).
Su AGENTS.md de A1 pide 40 mensajes etiquetados: aquí hay 8 para empezar; completen el resto
con mensajes reales anonimizados y con las correcciones humanas de la cola HITL.
"""
from __future__ import annotations

from dotenv import load_dotenv
from langsmith import Client, evaluate

from src.agentes.a1_clasificador.agente import clasificar

load_dotenv()
DATASET = "tiendaexpress-a1-dorado"

EJEMPLOS = [
    ("¿Cuánto cuesta y en cuánto llega a Trujillo?", "preventa", "precio", ["envio", "precio"]),
    ("¿Tienen la Vivobook 15 en stock?", "preventa", "info_producto", ["producto"]),
    ("Me llegó roto el ventilador del pedido PED-10001", "devolucion", "devolucion", []),
    ("Necesito 20 laptops para mi empresa", "preventa", "compleja", []),
    ("Quiero poner un reclamo formal", "fuera_de_alcance", "compleja", []),
    ("¿Puedo agendar una demo del Galaxy A55?", "preventa", "demo", []),
    ("Lo quiero, ¿cómo pago?", "preventa", "compra", []),
    ("El celular que compré no prende y además quiero cotizar otro", "preventa", "compleja", []),
]


def preparar_dataset(cliente: Client) -> None:
    if cliente.has_dataset(dataset_name=DATASET):
        return
    ds = cliente.create_dataset(DATASET, description="Conjunto dorado de A1 (TiendaExpress)")
    cliente.create_examples(
        dataset_id=ds.id,
        inputs=[{"texto": t} for t, *_ in EJEMPLOS],
        outputs=[{"dominio": d, "intencion": i, "requiere": r} for _, d, i, r in EJEMPLOS])


def objetivo(inputs: dict) -> dict:
    return clasificar(inputs["texto"])


# Evaluadores de código: reciben outputs y reference_outputs y devuelven una métrica.
def dominio_correcto(outputs: dict, reference_outputs: dict) -> bool:
    return outputs["dominio"] == reference_outputs["dominio"]


def intencion_correcta(outputs: dict, reference_outputs: dict) -> bool:
    return outputs["intencion"] == reference_outputs["intencion"]


def no_omite_ramas(outputs: dict, reference_outputs: dict) -> bool:
    """A1 §5: no omitir ramas de `requiere` (puede sobrar, no faltar)."""
    return set(reference_outputs["requiere"]) <= set(outputs["requiere"])


def p_no_es_uno(outputs: dict) -> bool:
    """A1 §5: no devolver p fija ni redondeada a 1,0."""
    return outputs["p"] < 1.0


if __name__ == "__main__":
    c = Client()
    preparar_dataset(c)
    evaluate(objetivo, data=DATASET, experiment_prefix="a1-haiku",
             evaluators=[dominio_correcto, intencion_correcta, no_omite_ramas, p_no_es_uno],
             max_concurrency=2)
