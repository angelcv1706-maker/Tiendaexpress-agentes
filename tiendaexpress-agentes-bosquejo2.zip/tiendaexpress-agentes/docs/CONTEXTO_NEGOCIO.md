# Contexto de negocio · TiendaExpress Perú S.A.C.

> Fuente de verdad del dominio para el equipo y para los agentes. Todo AGENTS.md remite aquí en lugar de repetir reglas.
> Caso **simulado** (curso Automatización Inteligente de Procesos · UPAO · 2026-20). Las políticas son decisiones del caso, no normativa real. Las referencias legales se citan como marco y deben verificarse antes de usarse fuera del curso.
> Fuentes: TO-BE «Gestionar devoluciones y reembolsos», TO-BE «Atender consultas pre-venta», diagrama de arquitectura «Un orquestador, nueve agentes, dos dominios», Laboratorios 01 y 03.

---

## 1. La empresa

| Dato | Valor |
|---|---|
| Razón social | TiendaExpress Perú S.A.C. |
| Giro | Venta minorista online de electrónica y electrodomésticos pequeños |
| Mercado | Personas naturales en Perú (B2C). Lima Metropolitana y provincias |
| Moneda | Soles (S/), precios con IGV (18 %) incluido |
| Zona horaria | America/Lima (UTC-05:00) |
| Almacén | Almacén TiendaExpress (único punto de despacho y recepción de devoluciones) |
| Couriers | Scharff y Olva (contratados; no se negocian) |
| Pasarelas de pago | Niubiz y Culqi |
| Comprobantes | Boleta o factura electrónica; las devoluciones generan **nota de crédito electrónica** en el ERP contable |

**Problema que se automatiza:** la atención pre-venta y la postventa dependen de personas que responden por WhatsApp y portal, consultan stock, precios y courier a mano, y coordinan reembolsos por mensajes sueltos. Hay respuestas lentas, criterios distintos entre asesores y reprocesos.

---

## 2. Canales y horarios

| Canal | Uso | Horario |
|---|---|---|
| Portal web (chat) | Consultas pre-venta y solicitudes de devolución | Agentes 24/7 |
| WhatsApp Business | Igual que el portal; además, notificaciones salientes con plantillas aprobadas | Agentes 24/7 |
| Atención humana (asesores, soporte) | Casos derivados por la compuerta HITL | Lun–sáb 09:00–19:00 |

Hay **un solo punto de contacto**: todo mensaje entra por A0 Recepción, sin importar el canal.

---

## 3. Catálogo

- **Categorías:** laptops y PC, smartphones y tablets, TV y audio, gaming, accesorios, electrodomésticos pequeños (p. ej., ventiladores, licuadoras).
- **Identificador de producto:** `SKU` (texto, único). La ficha técnica, la garantía del fabricante y el precio de lista viven en el ERP; el texto de la ficha y las FAQ se indexan en la base de conocimiento (RAG).
- **Stock:** el que reporta el ERP en el momento de la consulta. Una respuesta nunca se basa en un stock leído hace más de 15 minutos.
- **Alternativas:** si no hay stock, se ofrecen hasta 3 productos de la misma categoría, con rango de precio ±20 % y stock disponible.

---

## 4. Políticas comerciales (D1 · Pre-venta)

### 4.1 Precios y descuentos
- El precio de lista del ERP es la única fuente; un agente **nunca** inventa ni redondea precios.
- Las promociones solo se aplican si están vigentes en `MCP Cotizaciones` en la fecha de la consulta.
- **Descuento ≤ 10 %** sobre lista: A3 Cotizador lo aplica de forma automática si una promoción vigente lo respalda.
- **Descuento > 10 %**, o pedido de rebaja sin promoción: pasa a la **compuerta HITL** (aprobación del Coordinador Comercial).
- Cuotas: solo las que ofrece la promoción o el medio de pago vigente. Se informan como «hasta N cuotas con tarjetas participantes», nunca como financiamiento propio.

### 4.2 Cotizaciones
- Una cotización contiene `SKU`, cantidad, precio unitario, descuento, subtotal, costo de envío, total (IGV incluido) y fecha de vencimiento.
- **Vigencia:** 72 horas. No reserva stock; el stock se compromete al pagar.
- La compra por volumen (más de 5 unidades del mismo SKU) o para empresas pasa a un asesor; las cotizaciones corporativas son otro proceso y quedan **fuera de alcance**.

### 4.3 Envíos
- El costo y el plazo se obtienen de la API del courier (`cotizar_envio`) con el distrito o ubigeo de destino y el peso.
- Plazos de referencia: Lima Metropolitana, 24–48 h; provincias, 3–7 días hábiles. Siempre manda lo que devuelve la API.
- Envío gratis desde S/ 299 de total en Lima Metropolitana (política simulada).

### 4.4 Demos y calificación de leads
- **Demo:** videollamada de 30 min con un asesor para ver un producto. Se agenda de lunes a sábado entre 10:00 y 18:00, con al menos 2 h de anticipación y hasta 14 días adelante. Cada lead tiene como máximo **1 demo activa**.
- **Lead score** de 0 a 100, calculado por A5:

| Señal | Puntos |
|---|---|
| Intención de compra explícita («lo quiero», «cómo pago») | +30 |
| Producto consultado con stock | +15 |
| Monto cotizado ≥ S/ 1 000 | +15 |
| Presupuesto o fecha de compra declarados | +15 |
| Segunda interacción o más en 7 días | +10 |
| Pidió demo o hablar con un asesor | +15 |

- **Lead calificado: score ≥ 60.** Se registra en el CRM como oportunidad y se ofrece una demo (A4) o el pre-pedido.
- Una consulta sin respuesta del cliente en 24 h se cierra como **no convertida** (el lead sigue en el CRM).

---

## 5. Políticas postventa (D2 · Devoluciones y reembolsos)

### 5.1 Cuándo procede una devolución con reembolso
- **Plazo:** hasta 7 días calendario desde la entrega registrada.
- **Motivos aceptados:** producto dañado en el transporte, producto distinto al pedido o falla de fábrica.
- **Evidencia obligatoria:** código de pedido existente, motivo (texto de 1 a 300 caracteres) y al menos una foto (URL).
- **Motivos rechazados:** daño por mal uso, falta de accesorios atribuible al cliente, plazo vencido o pedido inexistente.
- Si el plazo de 7 días venció pero el producto sigue en garantía del fabricante: se **rechaza** el reembolso y se orienta al cliente hacia la garantía del fabricante (servicio técnico, **fuera de alcance**).

### 5.2 Caso complejo
Pasa a Soporte humano cuando ocurre cualquiera de estas condiciones:
- Las fotos no permiten decidir.
- El cliente reclama algo que contradice el pedido.
- Hay un segundo reclamo del mismo pedido.
- La confianza del veredicto es p < 0,50.

### 5.3 Recojo y recepción
- El recojo se programa con el courier (Scharff u Olva) en la dirección del pedido.
- El almacén confirma la recepción y el estado (webhook «recepción OK»). Si el paquete **no coincide** con lo declarado, el caso vuelve a validación («Reevaluar caso»).

### 5.4 Reembolso
- **Solo después** del estado `PRODUCTO_RECIBIDO` con conformidad del almacén. Nunca antes.
- Se reembolsa por el **mismo medio de pago**, como reversión en Niubiz o Culqi. El monto es el pagado por el ítem; si la falla es atribuible a TiendaExpress, se suma el envío original. Nunca supera el total pagado del pedido.
- Cada reembolso genera una **nota de crédito electrónica** en el ERP contable.
- El cliente recibe un comprobante de reembolso (A9). El tiempo de acreditación depende del banco emisor y se comunica como estimado.

---

## 6. Proceso D1 · Atender consultas pre-venta (TO-BE)

**Disparador:** el cliente envía una consulta por WhatsApp o portal. **Resultado:** respuesta enviada y, si el cliente confirma, pre-pedido registrado en el ERP (que inicia «Gestionar y dar seguimiento a los pedidos»). Si no, la consulta se cierra como no convertida.

| Elemento BPMN | Carril TO-BE | Agente | Herramienta |
|---|---|---|---|
| Consulta recibida (WhatsApp / Web) | Atención al Cliente | A0 Recepción | Canal |
| Registrar consulta en historial | Atención al Cliente | A0 Recepción | MCP CRM `registrar_interaccion` |
| Clasificar intención | Orquestador | A1 Clasificador | `decide()` |
| ¿Resoluble por agentes? | Orquestador | Compuerta HITL (con la p de A1) | — |
| ¿Qué información requiere? | Orquestador | Orquestador | — |
| Consultar ficha técnica y stock en ERP | Catálogo y Stock | A2 Asesor RAG | RAG + MCP Pagos y ERP `consultar_stock` |
| Calcular precio, promociones y cuotas | Comercial | A3 Cotizador | MCP Cotizaciones |
| Cotizar envío y plazo con API courier | Logístico | A3 Cotizador (solo lectura) | MCP Courier `cotizar_envio` |
| Consolidar respuesta y verificar datos | Orquestador | Orquestador + A5 Calificador | MCP CRM `actualizar_lead_score` |
| Proponer productos alternativos | Catálogo y Stock | A2 Asesor RAG | RAG |
| Atender consulta compleja (+ SLA 2 h) | Asesor de Ventas | Humano vía cola HITL | Cola de aprobación |
| Enviar respuesta al cliente | Atención al Cliente | A0 Recepción | Canal |
| Intención de compra recibida → Registrar pre-pedido en ERP | Atención al Cliente | A3 Cotizador | MCP Pagos y ERP `crear_prepedido` |
| 24 h sin respuesta → Registrar consulta como no convertida | Orquestador | A5 Calificador | MCP CRM `cerrar_lead` |
| *(por modelar)* Agendar demo | — | A4 Agendador | MCP Citas |

---

## 7. Proceso D2 · Gestionar devoluciones y reembolsos (TO-BE)

**Disparador:** el cliente envía una solicitud de devolución con fotos. **Resultado:** caso cerrado con reembolso registrado (reversión + nota de crédito + comprobante enviado), o solicitud rechazada con el motivo notificado.

| Elemento BPMN | Carril TO-BE | Agente | Herramienta |
|---|---|---|---|
| Recibir solicitud por Portal Web / WhatsApp | Atención al Cliente | A0 Recepción | Canal |
| Orquestar | Orquestador | Orquestador (A1 clasifica «devolución») | — |
| Validar garantía y fotos | Validador | A6 Validador | RAG políticas + MCP Pagos y ERP `buscar_pedido` |
| ¿Veredicto aprobado? / ¿Caso complejo? | Orquestador | Compuerta HITL | — |
| Atender caso complejo | Soporte | Humano vía cola HITL | Cola de aprobación |
| Programar recojo del paquete / Invocar API Courier | Logístico | A8 Logístico | MCP Courier `programar_recojo` |
| Webhook recepción OK → Actualizar estado a Producto Recibido | Orquestador | A8 Logístico | MCP Pagos y ERP `actualizar_estado_caso` |
| Procesar reembolso / Reversión / Nota de crédito | Financiero | A7 Financiero | MCP Pagos y ERP `revertir_pago`, `registrar_nota_credito` |
| Reevaluar caso | Financiero → Validador | A7 → A6 | — |
| Solicitud rechazada / Comprobante de reembolso | → Cliente | A9 Notificador | Canal (plantillas) |

---

## 8. Arquitectura (resumen)

```
Canales (portal, WhatsApp) → Orquestador (Deep Agent supervisor, LangGraph)
  → A0 Recepción (PII) · A1 Clasificador (p, intención)
  → D1: A2 Asesor RAG · A3 Cotizador · A4 Agendador · A5 Calificador
  → D2: A6 Validador · A7 Financiero · A8 Logístico · A9 Notificador
  → Compuerta HITL → Capa cognitiva (LLM) + Capa de conocimiento (RAG, PostgreSQL + pgvector)
  → Herramientas (servidores FastMCP) → Sistemas externos → Gobierno
```

| Servidor MCP | Herramientas | Quién escribe |
|---|---|---|
| MCP Cotizaciones | `obtener_precio`, `listar_promociones`, `calcular_cuotas`, `crear_cotizacion`, `obtener_cotizacion` | A3 |
| MCP Citas | `consultar_disponibilidad`, `reservar_demo`, `reprogramar_demo`, `cancelar_demo` | A4 |
| MCP CRM | `buscar_cliente`, `registrar_interaccion`, `upsert_lead`, `actualizar_lead_score`, `cerrar_lead` | A0 (interacciones), A5 (leads) |
| MCP Courier | `cotizar_envio`, `programar_recojo`, `consultar_estado_envio` | A8 (A3 solo `cotizar_envio`) |
| MCP Pagos y ERP | `buscar_pedido`, `consultar_stock`, `crear_prepedido`, `actualizar_estado_caso`, `revertir_pago`, `registrar_nota_credito` | A3 (`crear_prepedido`), A8 (`actualizar_estado_caso`), A7 (pagos y notas) |

**Conocimiento (pgvector):** colecciones `catalogo`, `faq`, `politicas_garantia` y `politicas_devolucion`. Cada fragmento indica su fuente y fecha de vigencia.

---

## 9. Gobierno

### 9.1 Compuerta HITL
| Condición | Acción |
|---|---|
| p ≥ 0,80 (τ_auto) | Ejecuta automáticamente |
| 0,50 ≤ p < 0,80 | Revisión humana antes de ejecutar |
| p < 0,50 (τ_rev) | Escala a humano (asesor o soporte) |
| Descuento > 10 % | Aprobación del Coordinador Comercial |
| Caso complejo de devolución | Soporte |

Una probabilidad **nunca concede autorización**: los límites de monto, plazo y permisos se aplican por código, aunque p = 0,99. Cada decisión humana se guarda como etiqueta para recalibrar los umbrales.

### 9.2 Datos personales (marco: Ley 29733 de Protección de Datos Personales)
- A0 enmascara nombre, DNI/RUC, teléfono, correo y dirección **antes** de que el texto llegue al LLM o a los registros (`<TEL_1>`, `<DNI_1>`…). La tabla de correspondencia vive solo en la base de datos.
- Los datos de tarjeta nunca pasan por el sistema: los procesa la pasarela.

### 9.3 Idempotencia (clave = hash del contenido de negocio, sin marcas de tiempo)
| Operación | Clave |
|---|---|
| Consulta entrante | `HASH(canal\|id_mensaje_del_canal)` |
| Cotización | `HASH(id_cliente\|sku\|cantidad\|codigo_promo)` |
| Demo | `HASH(lead_id\|sku\|inicio)` |
| Devolución | `HASH(pedido\|motivo)` (normalizados, en minúsculas) |
| Reembolso | `HASH(id_caso\|monto)` — un caso se reembolsa una sola vez |

### 9.4 Catálogo de errores (tres clases)
| Clase | Ejemplo | Respuesta |
|---|---|---|
| De datos | Falta foto, pedido inexistente, SKU no existe | Rechazar con motivo y no reintentar |
| Transitorio / de sistema | Timeout del courier (4 intentos, espera de 2 s), error de pasarela (3 intentos, espera de 5 s) | Reintentar; si persiste, enviar a `cola_fallidos` con la carga completa |
| Manual | Veredicto ambiguo, paquete que no coincide | Derivar a humano o reevaluar |

### 9.5 Trazas
Cada ejecución registra `trace_id`, agente, herramienta, entrada y salida enmascaradas, p, decisión y duración.

---

## 10. Entidades, identificadores y estados

| Entidad | ID | Estados |
|---|---|---|
| Consulta | `CON-AAAAMMDD-####` | RECIBIDA → CLASIFICADA → RESPONDIDA → CONVERTIDA \| NO_CONVERTIDA \| EN_ASESOR |
| Lead | `LEAD-#####` | NUEVO → CALIFICADO → DEMO_AGENDADA → CONVERTIDO \| PERDIDO |
| Cotización | `COT-#####` | VIGENTE → ACEPTADA \| VENCIDA |
| Demo | `CITA-#####` | RESERVADA → REALIZADA \| CANCELADA \| NO_ASISTIÓ |
| Pedido | `PED-#####` | Viene del proceso de pedidos (solo lectura en D1 y D2) |
| Caso de devolución | `SOL-#####` | RECIBIDA → EN_VALIDACION → APROBADA \| RECHAZADA \| EN_SOPORTE → RECOJO_PROGRAMADO → PRODUCTO_RECIBIDO → (REEVALUACION) → REEMBOLSADA → CERRADA |
| Recojo | `RCJ-######` | PROGRAMADO → RECOGIDO → ENTREGADO_ALMACEN |
| Reembolso | `REEM-######` | SOLICITADO → REVERTIDO → NOTA_CREDITO_EMITIDA |

---

## 11. Roles humanos

| Rol | Interviene en |
|---|---|
| Asesor de Ventas | Consultas complejas y demos (D1) |
| Coordinador de Atención al Cliente | Alerta por SLA de 2 h vencido y revisión de la cola HITL de D1 |
| Coordinador Comercial | Aprueba descuentos mayores al 10 % |
| Soporte postventa | Casos complejos de devolución (D2) |
| Personal de almacén | Recepción física y confirmación del estado del producto |

---

## 12. Glosario

- **HITL:** *human in the loop*; una persona aprueba o decide antes de que el sistema ejecute.
- **p:** confianza calibrada que devuelve `decide()` (0–1).
- **Pre-pedido:** pedido creado en el ERP pendiente de pago; inicia el proceso de pedidos.
- **Nota de crédito:** comprobante electrónico que anula total o parcialmente una venta.
- **Reversión:** devolución del cargo a la tarjeta por medio de la pasarela.

---

## 13. Supuestos y pendientes

1. El TO-BE de pre-venta todavía **no modela a A4 Agendador ni el umbral de lead score ≥ 60 de A5**. Hay que agregar «¿Lead calificado?» → «Agendar demo».
2. Los carriles del TO-BE de pre-venta no coinciden uno a uno con los agentes: «Catálogo y Stock» corresponde a A2, y «Comercial» más la cotización de envío del carril «Logístico» corresponden a A3. La tabla del §6 es la equivalencia oficial.
3. El TO-BE de pre-venta dice «n8n AI Agent», pero la implementación vigente es LangGraph. Conviene renombrar la tarea como «Clasificar intención».
4. Los plazos, montos y puntajes marcados como política simulada son decisiones del caso y se pueden ajustar con el contacto validador.
