# AGENTS.md · TiendaExpress · Plataforma multiagente

> Léelo antes de cualquier tarea. Reglas de negocio completas: `docs/CONTEXTO_NEGOCIO.md`. Cada agente tiene su propio `AGENTS.md` en `src/agentes/<id>/`. Si hay conflicto, manda el más específico y, si no se resuelve, se pregunta al equipo.

## 1. Propósito
Automatiza dos procesos de TiendaExpress Perú S.A.C. (tienda online de electrónica, caso simulado):
- **D1 · Atender consultas pre-venta:** información de producto, cotización, demo agendada y calificación de leads. Termina con un pre-pedido en el ERP o con la consulta cerrada como no convertida.
- **D2 · Gestionar devoluciones y reembolsos:** validar la garantía, recoger el producto, reembolsar y notificar. Termina con el caso cerrado o la solicitud rechazada.

**Fuera de alcance:** cobro y despacho de pedidos (otro proceso), cotizaciones corporativas, servicio técnico de garantía del fabricante, reclamos del Libro de Reclamaciones y negociación con couriers.

## 2. Arquitectura
```
src/orquestador/      Deep Agent supervisor (LangGraph): enruta por intención y gestiona el estado del hilo
src/agentes/a0..a9/   un agente por carpeta: AGENTS.md, prompt.md, agente.py
src/decision/         decide() tipada y umbrales HITL (τ_auto = 0,80; τ_rev = 0,50)
src/hitl/             cola de aprobación humana
src/mcp_servers/      cotizaciones, citas, crm, courier, pagos_erp (FastMCP)
src/conocimiento/     ingesta RAG → PostgreSQL + pgvector
docs/                 CONTEXTO_NEGOCIO.md, bpmn/ (TO-BE de D1 y D2)
tests/                por agente y por servidor MCP
```
| Agente | Dominio | Carril BPMN TO-BE |
|---|---|---|
| A0 Recepción | Compartido | Atención al Cliente |
| A1 Clasificador | Compartido | Orquestador |
| A2 Asesor RAG | D1 | Catálogo y Stock |
| A3 Cotizador | D1 | Comercial (+ cotización de envío) |
| A4 Agendador | D1 | *(por modelar)* |
| A5 Calificador | D1 | Orquestador (consolidar / no convertida) |
| A6 Validador | D2 | Validador |
| A7 Financiero | D2 | Financiero |
| A8 Logístico | D2 | Logístico |
| A9 Notificador | D2 | Envíos al Cliente |

**Decisiones:**
- Los agentes nunca llaman a sistemas externos directamente; solo lo hacen por medio de los servidores MCP, porque así se centralizan los permisos, los reintentos y las trazas.
- Las reglas de monto, plazo y permiso se validan en código (`src/decision/`), no en el prompt, porque un LLM no garantiza cumplirlas.
- Los agentes no se llaman entre sí; el orquestador es el único que delega, porque así cada paso queda trazado.

## 3. Convenciones
- Código, nombres y mensajes en **español**; `snake_case` en Python e identificadores con prefijo (`CON-`, `LEAD-`, `COT-`, `CITA-`, `SOL-`, `RCJ-`, `REEM-`).
- Montos en `Decimal` con 2 decimales y en S/ con IGV incluido; fechas ISO 8601 en America/Lima.
- Errores en tres clases (`ErrorDeDatos`, `ErrorTransitorio`, `ErrorManual`). La respuesta depende de la clase (ver contexto §9.4).
- Registro en JSON con `trace_id`, `agente`, `herramienta`, `p`, `decision` y `duracion_ms`. Nunca se registra PII sin enmascarar.
- Toda escritura en un sistema externo lleva su clave de idempotencia (contexto §9.3).
- Commits que expliquen el porqué; un incremento por commit.

## 4. Comandos
```
Instalar:   pip install -r requirements.txt     (copiar .env.example a .env)
Base:       docker compose up -d postgres         (PostgreSQL + pgvector)
Ingesta:    python -m src.conocimiento.ingestar
MCP:        python -m src.mcp_servers.<servidor>
Ejecutar:   python -m src.orquestador
Probar:     pytest -q        ·  por agente: pytest tests/agentes/test_a3_cotizador.py -q
```

## 5. Restricciones
- **No ejecutar un reembolso sin el estado `PRODUCTO_RECIBIDO`.** Previene que se pague por un producto que nunca volvió.
- **No aplicar descuentos mayores al 10 % sin aprobación HITL.** Previene pérdidas de margen por un LLM complaciente.
- **No enviar PII al LLM ni a los logs sin pasar por A0.** Previene incumplir la Ley 29733 y filtrar datos en las trazas.
- **No escribir credenciales en código, prompts ni `.env` versionado.** Previene la exposición en el historial; si ocurre, se **rota** primero.
- **No inventar precios, stock, plazos ni políticas;** si la herramienta no responde, se dice que no se sabe. Previene compromisos comerciales falsos.
- **No agregar dependencias ni servidores MCP sin acuerdo del equipo.** Previene duplicar lógica y ampliar la superficie de ataque.
- **No tratar `p` como permiso:** los límites se validan siempre en código. Previene acciones automáticas por exceso de confianza.
- **No implementar procesos fuera de alcance** (cobro, despacho, garantía del fabricante). Previene funcionalidad que nadie pidió.
