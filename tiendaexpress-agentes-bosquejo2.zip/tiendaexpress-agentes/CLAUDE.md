@AGENTS.md

Claude Code lee CLAUDE.md, no AGENTS.md; esta línea importa las reglas del equipo para que valgan también aquí.
