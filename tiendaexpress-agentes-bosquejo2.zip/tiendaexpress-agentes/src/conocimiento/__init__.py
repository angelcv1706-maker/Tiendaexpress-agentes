"""Capa de conocimiento (RAG).

Diseño de producción (contexto §8): PostgreSQL + pgvector con las colecciones `catalogo`,
`faq`, `politicas_garantia` y `politicas_devolucion`; cada fragmento con fuente y vigencia.
Anthropic no ofrece embeddings propios: su documentación recomienda Voyage AI
(`langchain-voyageai`). Ver `ingestar.py`.

Para que el bosquejo corra sin base de datos ni claves, `buscar()` usa una búsqueda léxica
en memoria con la MISMA firma que tendrá la versión pgvector. Cambiar la implementación no
debe tocar a los agentes.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from src.datos.simulados import PRODUCTOS


@dataclass
class Fragmento:
    coleccion: str
    doc_id: str
    texto: str
    similitud: float


DOCUMENTOS: dict[str, list[tuple[str, str]]] = {
    "catalogo": [(sku, f"{p['nombre']}. Categoría {p['categoria']}. "
                       f"Garantía del fabricante {p['garantia_fabricante_meses']} meses.")
                 for sku, p in PRODUCTOS.items()],
    "faq": [
        ("FAQ-ENVIO-01", "Los envíos a Lima Metropolitana llegan en 24 a 48 horas y a provincias en 3 a 7 días hábiles, según el courier."),
        ("FAQ-PAGO-01", "Aceptamos tarjetas a través de Niubiz y Culqi. Las cuotas dependen de la promoción y del banco emisor."),
    ],
    "politicas_devolucion": [
        ("POL-DEV-01", "Devolución con reembolso hasta 7 días calendario desde la entrega registrada. Motivos aceptados: daño en el transporte, producto distinto al pedido o falla de fábrica."),
        ("POL-DEV-02", "No procede la devolución por mal uso, falta de accesorios atribuible al cliente, plazo vencido o pedido inexistente."),
    ],
    "politicas_garantia": [
        ("POL-GAR-01", "Si venció el plazo de devolución pero el producto sigue en garantía del fabricante, se orienta al cliente al servicio técnico autorizado."),
    ],
}


def _tokens(texto: str) -> set[str]:
    texto = unicodedata.normalize("NFKD", texto.lower()).encode("ascii", "ignore").decode()
    return {t for t in re.findall(r"[a-z0-9]+", texto) if len(t) > 2}


def buscar(coleccion: str, consulta: str, k: int = 5, umbral: float = 0.75) -> list[Fragmento]:
    """Devuelve hasta k fragmentos con similitud ≥ umbral (A2 §2: 0,75 y máximo 5).

    La similitud léxica aquí es la fracción de términos de la consulta presentes en el
    documento; con pgvector será la similitud coseno de los embeddings.
    """
    q = _tokens(consulta)
    if not q:
        return []
    resultado = []
    for doc_id, texto in DOCUMENTOS.get(coleccion, []):
        d = _tokens(texto) | _tokens(doc_id)
        sim = len(q & d) / len(q)
        resultado.append(Fragmento(coleccion, doc_id, texto, round(sim, 2)))
    resultado.sort(key=lambda f: f.similitud, reverse=True)
    return [f for f in resultado[:k] if f.similitud >= umbral]


def resolver_sku(texto: str, max_candidatos: int = 3) -> list[str]:
    """Candidatos de SKU mencionados en el texto (por SKU literal o por nombre)."""
    literal = [s for s in PRODUCTOS if s.lower() in texto.lower()]
    if literal:
        return literal[:1]
    q = _tokens(texto)
    puntajes = []
    for sku, p in PRODUCTOS.items():
        comunes = len(q & _tokens(p["nombre"]))
        if comunes:
            puntajes.append((comunes, sku))
    puntajes.sort(reverse=True)
    if puntajes and (len(puntajes) == 1 or puntajes[0][0] > puntajes[1][0]):
        return [puntajes[0][1]]
    return [s for _, s in puntajes[:max_candidatos]]
