"""Ingesta RAG a PostgreSQL + pgvector (versión de producción, NO probada en el bosquejo).

Uso:  python -m src.conocimiento.ingestar --coleccion catalogo
Requiere: docker compose up -d postgres, PGVECTOR_URL y VOYAGE_API_KEY en .env,
          pip install langchain-postgres langchain-voyageai

Esqueleto pensado para revisar con el equipo antes de usarlo.
"""
from __future__ import annotations

import argparse
import os


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--coleccion", required=True,
                        choices=["catalogo", "faq", "politicas_garantia", "politicas_devolucion"])
    args = parser.parse_args()

    from langchain_core.documents import Document
    from langchain_postgres import PGVector          # pip install langchain-postgres
    from langchain_voyageai import VoyageAIEmbeddings  # pip install langchain-voyageai

    from src.comun.base import ahora
    from src.conocimiento import DOCUMENTOS

    docs = [Document(page_content=texto,
                     metadata={"doc_id": doc_id, "fuente": args.coleccion,
                               "vigente_desde": ahora().date().isoformat()})
            for doc_id, texto in DOCUMENTOS[args.coleccion]]
    store = PGVector(embeddings=VoyageAIEmbeddings(model="voyage-3.5"),
                     collection_name=args.coleccion,
                     connection=os.environ["PGVECTOR_URL"], use_jsonb=True)
    store.add_documents(docs, ids=[d.metadata["doc_id"] for d in docs])
    print(f"{len(docs)} fragmentos cargados en '{args.coleccion}'")


if __name__ == "__main__":
    main()
