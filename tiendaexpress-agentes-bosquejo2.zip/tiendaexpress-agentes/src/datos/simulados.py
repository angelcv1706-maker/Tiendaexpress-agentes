"""Datos SIMULADOS que reemplazan al ERP, CRM, courier, pasarela y agenda.

Solo para el bosquejo y las pruebas. En producción, cada servidor MCP llama al sistema real
y este módulo desaparece. Las fechas de entrega se calculan respecto de hoy para que los
casos de prueba (día 7 frente a día 8) sigan funcionando cualquier día.
"""
from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

from src.comun.base import ahora

PRODUCTOS = {
    "LAP-ASUS-VB15": {"nombre": "Laptop ASUS Vivobook 15 (Ryzen 5, 16 GB, 512 GB SSD)",
                      "categoria": "laptops", "precio_lista": Decimal("2499.00"), "stock": 8,
                      "peso_kg": Decimal("2.1"), "garantia_fabricante_meses": 12},
    "LAP-LEN-IP3": {"nombre": "Laptop Lenovo IdeaPad 3 (Core i5, 8 GB, 512 GB SSD)",
                    "categoria": "laptops", "precio_lista": Decimal("2199.00"), "stock": 0,
                    "peso_kg": Decimal("1.9"), "garantia_fabricante_meses": 12},
    "LAP-HP-15": {"nombre": "Laptop HP 15 (Core i5, 16 GB, 512 GB SSD)",
                  "categoria": "laptops", "precio_lista": Decimal("2349.00"), "stock": 5,
                  "peso_kg": Decimal("1.8"), "garantia_fabricante_meses": 12},
    "CEL-SAM-A55": {"nombre": "Smartphone Samsung Galaxy A55 256 GB",
                    "categoria": "smartphones", "precio_lista": Decimal("1599.00"), "stock": 20,
                    "peso_kg": Decimal("0.4"), "garantia_fabricante_meses": 12},
    "VEN-IMA-16": {"nombre": "Ventilador de pie Imaco 16\"",
                   "categoria": "electrodomesticos", "precio_lista": Decimal("149.90"), "stock": 30,
                   "peso_kg": Decimal("4.5"), "garantia_fabricante_meses": 6},
}

PROMOCIONES = [
    {"codigo": "CYBER10", "sku": "LAP-ASUS-VB15", "descuento": Decimal("0.10"),
     "vigente_desde": ahora() - timedelta(days=2), "vigente_hasta": ahora() + timedelta(days=5),
     "cuotas_max": 12, "sin_intereses": True},
    {"codigo": "VERANO5", "sku": "CEL-SAM-A55", "descuento": Decimal("0.05"),
     "vigente_desde": ahora() - timedelta(days=30), "vigente_hasta": ahora() - timedelta(days=1),
     "cuotas_max": 6, "sin_intereses": False},  # vencida: no debe aplicarse
]

CLIENTES = {"CLI-00001": {"lead_id": "LEAD-00001", "interacciones_7d": 1}}

PEDIDOS = {
    "PED-10001": {"cliente": "CLI-00001", "sku": "VEN-IMA-16", "monto_item": Decimal("149.90"),
                  "envio": Decimal("15.00"), "total_pagado": Decimal("164.90"),
                  "medio_pago": "niubiz", "fecha_entrega": ahora() - timedelta(days=3),
                  "distrito": "Trujillo", "direccion": "<DIRECCION_PEDIDO_10001>"},
    "PED-10002": {"cliente": "CLI-00001", "sku": "CEL-SAM-A55", "monto_item": Decimal("1599.00"),
                  "envio": Decimal("0.00"), "total_pagado": Decimal("1599.00"),
                  "medio_pago": "culqi", "fecha_entrega": ahora() - timedelta(days=8),
                  "distrito": "Miraflores", "direccion": "<DIRECCION_PEDIDO_10002>"},
}

COBERTURA_COURIER = {  # distrito → {courier: (costo envío S/, plazo en horas)}
    "Miraflores": {"scharff": (Decimal("12.00"), 24), "olva": (Decimal("10.00"), 48)},
    "Trujillo": {"olva": (Decimal("25.00"), 72)},
    "Arequipa": {"scharff": (Decimal("28.00"), 96), "olva": (Decimal("26.00"), 120)},
}
LIMA_METROPOLITANA = {"Miraflores", "San Isidro", "Surco", "Los Olivos", "San Miguel"}

# Estado mutable (en producción: bases de datos de cada sistema)
CASOS: dict[str, dict] = {}
COTIZACIONES: dict[str, dict] = {}
LEADS: dict[str, dict] = {"LEAD-00001": {"estado": "NUEVO", "score": 0, "senales": {}}}
DEMOS: dict[str, dict] = {}
REEMBOLSOS: dict[str, dict] = {}
IDEMPOTENCIA: dict[str, str] = {}   # clave → id ya creado
INTERACCIONES: list[dict] = []
