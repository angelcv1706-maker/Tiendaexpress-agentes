"""Utilidades compartidas: dinero, fechas, IDs, idempotencia, errores y registro.

Convenciones de /AGENTS.md §3: montos en Decimal (S/ con IGV), fechas ISO 8601 en
America/Lima, errores en tres clases y registro JSON sin PII.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import logging
import time
from contextlib import contextmanager
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from zoneinfo import ZoneInfo

LIMA = ZoneInfo("America/Lima")


# ---------------------------------------------------------------- dinero y fechas
def soles(valor) -> Decimal:
    """Convierte a Decimal con 2 decimales (HALF_UP). Nunca usar float para montos."""
    return Decimal(str(valor)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def formato_soles(monto: Decimal) -> str:
    """S/ 1 299,00 (espacio de miles y coma decimal, como pide A3)."""
    entero, dec = f"{soles(monto):.2f}".split(".")
    entero = f"{int(entero):,}".replace(",", " ")
    return f"S/ {entero},{dec}"


def ahora() -> datetime:
    return datetime.now(LIMA)


# ---------------------------------------------------------------- identificadores
_contadores: dict[str, itertools.count] = {}


def nuevo_id(prefijo: str, digitos: int = 5) -> str:
    """CON-, LEAD-, COT-, CITA-, SOL-, RCJ-, REEM- (contador en memoria para el bosquejo)."""
    if prefijo == "CON":
        n = next(_contadores.setdefault(prefijo, itertools.count(1)))
        return f"CON-{ahora():%Y%m%d}-{n:04d}"
    n = next(_contadores.setdefault(prefijo, itertools.count(1)))
    return f"{prefijo}-{n:0{digitos}d}"


def clave_idempotencia(*partes) -> str:
    """HASH del contenido de negocio, sin marcas de tiempo (contexto §9.3)."""
    normal = "|".join(str(p).strip().lower() for p in partes)
    return hashlib.sha256(normal.encode()).hexdigest()[:32]


# ---------------------------------------------------------------- errores (§9.4)
class ErrorDeDatos(Exception):
    """Rechazar con motivo y no reintentar."""


class ErrorTransitorio(Exception):
    """Reintentar; si persiste, a cola_fallidos con la carga completa."""


class ErrorManual(Exception):
    """Derivar a humano o reevaluar."""


# ---------------------------------------------------------------- registro JSON
_log = logging.getLogger("tiendaexpress")
if not _log.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(message)s"))
    _log.addHandler(_h)
    _log.setLevel(logging.INFO)


def registrar(trace_id: str, agente: str, herramienta: str | None = None, p: float | None = None,
              decision: str | None = None, duracion_ms: int | None = None, **extra) -> None:
    """Una línea JSON por evento. Nunca pasar texto sin enmascarar en `extra`."""
    _log.info(json.dumps({"trace_id": trace_id, "agente": agente, "herramienta": herramienta,
                          "p": p, "decision": decision, "duracion_ms": duracion_ms, **extra},
                         ensure_ascii=False, default=str))


@contextmanager
def cronometro():
    inicio = time.perf_counter()
    medida = {"ms": 0}
    try:
        yield medida
    finally:
        medida["ms"] = int((time.perf_counter() - inicio) * 1000)
