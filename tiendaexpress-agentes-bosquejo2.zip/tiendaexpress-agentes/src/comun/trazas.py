"""Anonimizador de LangSmith: las trazas no guardan datos personales (Ley 29733, /AGENTS.md §5).

LangSmith registra la entrada y la salida de cada paso, incluida la entrada del grafo, que es el
mensaje del cliente ANTES de que A0 lo enmascare. Este módulo instala un cliente de LangSmith con
un anonimizador que aplica los mismos tipos de dato que A0 (DNI, RUC, teléfono, correo, tarjeta,
dirección y nombre) a todo lo que se envía.

Los patrones de números exigen que no haya letras ni guiones alrededor, para no borrar
identificadores del sistema como CON-20261102-0001 o los UUID de las trazas.
"""

from __future__ import annotations

import os
import re

REGLAS = [
    (re.compile(r"(?<![\w-])(?:\d[ -]?){13,19}(?![\w-])"), "<TARJETA>"),
    (re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b"), "<CORREO>"),
    (re.compile(r"(?<![\w-])(?:10|15|17|20)\d{9}(?![\w-])"), "<RUC>"),
    (re.compile(r"(?<![\w-])(?:\+?51[ -]?)?9\d{2}[ -]?\d{3}[ -]?\d{3}(?![\w-])"), "<TEL>"),
    (re.compile(r"(?<![\w-])\d{8}(?![\w-])"), "<DNI>"),
    (
        re.compile(r"\b(?:Av\.?|Avenida|Jr\.?|Jir[oó]n|Calle|Psje\.?|Pasaje|Mz\.?)\s+[^,.\n]{3,60}", re.I),
        "<DIRECCION>",
    ),
    (re.compile(r"(?<=\bme llamo )[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?: [A-ZÁÉÍÓÚÑ][a-záéíóúñ]+){0,3}"), "<NOMBRE>"),
]


def anonimizador():
    from langsmith.anonymizer import create_anonymizer

    return create_anonymizer([{"pattern": patron, "replace": marca} for patron, marca in REGLAS])


def configurar_langsmith() -> bool:
    """Instala el cliente global de LangSmith con anonimizador. Devuelve True si se activó."""
    if os.getenv("LANGSMITH_TRACING", "").lower() != "true" or not os.getenv("LANGSMITH_API_KEY"):
        return False
    from langsmith import Client, configure

    configure(client=Client(anonymizer=anonimizador()))
    return True
