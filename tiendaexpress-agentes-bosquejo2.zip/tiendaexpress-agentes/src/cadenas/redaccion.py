"""Cadena LCEL del orquestador: datos verificados | prompt | Claude | StrOutputParser."""

from __future__ import annotations

import json

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

from src import simulado
from src.cadenas import eslabon_modelo

SISTEMA = """Redactas la respuesta de TiendaExpress Perú S.A.C. a un cliente.
Usa SOLO los datos del JSON. No inventes precios, stock, plazos ni políticas: si un dato no está,
no lo menciones. Montos tal como vienen en 'total_texto'. Español peruano neutro, trato de «usted»,
máximo 3 párrafos cortos. Si hay alternativas por falta de stock, ofrécelas. Si hay una cotización,
indica que es válida por 72 horas y que no reserva stock."""

prompt = ChatPromptTemplate.from_messages(
    [("system", SISTEMA), ("human", "{datos_json}")]
)


def _simulada(valor_prompt) -> str:
    return simulado.redactar(json.loads(valor_prompt.to_messages()[-1].content))


def cadena_redaccion():
    a_json = RunnableLambda(
        lambda datos: {
            "datos_json": json.dumps(datos, ensure_ascii=False, default=str)
        },
        name="datos_a_json",
    )
    if simulado.activo():
        return (
            a_json | prompt | RunnableLambda(_simulada, name="redactor[simulado]")
        ).with_config(run_name="lcel_redaccion")
    return (a_json | prompt | eslabon_modelo("asesor") | StrOutputParser()).with_config(
        run_name="lcel_redaccion"
    )
