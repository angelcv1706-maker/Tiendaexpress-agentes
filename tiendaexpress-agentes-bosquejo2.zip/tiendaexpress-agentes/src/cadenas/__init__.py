"""Cadenas LCEL (LangChain Expression Language) del proyecto.

Todas las llamadas a Claude pasan por aquí, compuestas con el operador `|`:
    prompt | modelo | parser
Cada agente importa su cadena; ningún agente arma prompts ni llama al modelo por su cuenta.

| Archivo              | Cadena                         | La usa |
|----------------------|--------------------------------|--------|
| clasificacion.py     | prompt | Claude → Clasificacion | A1     |
| rag.py               | recuperar ∥ pregunta | prompt | Claude → SalidaA2 | A2 |
| extraccion.py        | prompt | Claude → DatosCotizacion | A3   |
| evidencia.py         | armar mensajes | Claude (visión) → LecturaEvidencia | A6 |
| redaccion.py         | prompt | Claude | StrOutputParser | Orquestador |

Con MODO_SIMULADO=1 cada cadena reemplaza solo el eslabón del modelo por una heurística,
así la estructura LCEL (y su traza en LangSmith) es la misma con o sin API key.
"""

from __future__ import annotations

from langchain_core.runnables import Runnable, RunnableLambda

from src import simulado


def eslabon_modelo(
    rol: str,
    esquema=None,
    temperatura: float = 0.0,
    heuristica=None,
    nombre: str = "modelo",
) -> Runnable:
    """El eslabón del modelo de una cadena: Claude real o su heurística simulada."""
    if simulado.activo() and heuristica is not None:
        return RunnableLambda(heuristica, name=f"{nombre}[simulado]")
    from src.config import modelo

    llm = modelo(rol, temperatura)
    return llm.with_structured_output(esquema) if esquema is not None else llm
