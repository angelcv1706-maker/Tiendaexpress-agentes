"""Cadena LCEL de A1: prompt | Claude (salida tipada).

La autoconsistencia se hace con `cadena.batch([...] * N)`: N muestras en paralelo de la
misma cadena, y `p` sale de la proporción de votos (ver src/decision/confianza.py).
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

from src import simulado
from src.cadenas import eslabon_modelo

PROMPT = (
    Path(__file__).parents[1] / "agentes" / "a1_clasificador" / "prompt.md"
).read_text(encoding="utf-8")


class Clasificacion(BaseModel):
    dominio: Literal["preventa", "devolucion", "fuera_de_alcance"]
    intencion: Literal[
        "info_producto", "precio", "envio", "demo", "compra", "devolucion", "compleja"
    ]
    requiere: list[Literal["producto", "precio", "envio"]] = Field(default_factory=list)
    motivo: str


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", PROMPT),
        ("human", "Historial: {historial}\n\nMensaje: {texto}"),
    ]
)


def _simulada(valor_prompt) -> Clasificacion:
    texto = valor_prompt.to_messages()[-1].content.split("Mensaje: ", 1)[-1]
    c = simulado.clasificar(texto)
    return Clasificacion(
        **{k: c[k] for k in ("dominio", "intencion", "requiere", "motivo")}
    )


def cadena_clasificacion():
    return (
        prompt
        | eslabon_modelo("clasificador", Clasificacion, 0.7, _simulada, "clasificador")
    ).with_config(run_name="lcel_clasificacion_a1")
