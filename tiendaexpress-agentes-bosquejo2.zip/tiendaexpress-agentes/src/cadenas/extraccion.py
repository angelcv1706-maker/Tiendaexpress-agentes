"""Cadena LCEL de A3: prompt | Claude → DatosCotizacion. Claude solo extrae; no calcula."""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

from src import simulado
from src.cadenas import eslabon_modelo


class DatosCotizacion(BaseModel):
    producto_mencionado: str = Field(
        description="Producto tal como lo nombra el cliente, o ''"
    )
    cantidad: int = Field(default=1, ge=1)
    distrito: str = Field(default="", description="Distrito o ciudad de destino, o ''")
    pide_cuotas: bool = False
    pide_rebaja: bool = Field(
        default=False, description="Pide descuento adicional o regatea"
    )


prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Extrae los datos de cotización del mensaje del cliente de una tienda de "
            "electrónica en Perú. No inventes datos ausentes.",
        ),
        ("human", "{texto}"),
    ]
)


def _simulada(valor_prompt) -> DatosCotizacion:
    return DatosCotizacion(
        **simulado.extraer_cotizacion(valor_prompt.to_messages()[-1].content)
    )


def cadena_extraccion():
    return (
        prompt
        | eslabon_modelo("extractor", DatosCotizacion, 0.0, _simulada, "extractor")
    ).with_config(run_name="lcel_extraccion_a3")
