"""Cadena LCEL de A6: armar mensajes multimodales | Claude (visión) → LecturaEvidencia."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.runnables import RunnableLambda
from pydantic import BaseModel, Field

from src import simulado
from src.cadenas import eslabon_modelo

PROMPT = (
    Path(__file__).parents[1] / "agentes" / "a6_validador" / "prompt.md"
).read_text(encoding="utf-8")


class LecturaEvidencia(BaseModel):
    motivo_categoria: Literal[
        "transporte", "producto_distinto", "falla_fabrica", "mal_uso", "otro"
    ]
    fotos_coinciden: bool = Field(
        description="Las fotos muestran el producto del pedido"
    )
    fotos_concluyentes: bool = Field(
        description="Las fotos permiten ver el daño declarado"
    )
    contradice_pedido: bool
    p: float = Field(ge=0, le=1, description="Confianza en la lectura")
    motivo_para_cliente: str = Field(
        description="Explicación breve y amable, sin reglas internas"
    )


def armar_mensajes(e: dict) -> list:
    contenido = [
        {
            "type": "text",
            "text": f"Producto del pedido: {e['producto']}\n"
            f"Motivo del cliente: {e['motivo']}\n"
            f"Políticas aplicables:\n{e['politicas']}",
        }
    ]
    contenido += [{"type": "image", "url": url} for url in e["fotos"][:5]]
    return [SystemMessage(PROMPT), HumanMessage(contenido)]


def _simulada(mensajes: list) -> LecturaEvidencia:
    bloques = mensajes[-1].content
    texto = (
        bloques[0]["text"]
        .split("Motivo del cliente: ", 1)[1]
        .split("\nPolíticas", 1)[0]
    )
    fotos = [b["url"] for b in bloques[1:]]
    return LecturaEvidencia(**simulado.lectura_evidencia(texto, fotos))


def cadena_evidencia():
    return (
        RunnableLambda(armar_mensajes, name="armar_mensajes")
        | eslabon_modelo("validador", LecturaEvidencia, 0.0, _simulada, "validador")
    ).with_config(run_name="lcel_evidencia_a6")
