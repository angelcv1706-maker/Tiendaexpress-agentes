"""Cadena LCEL RAG de A2:

    {contexto: pregunta | recuperar | formatear, pregunta, sku}  (RunnableParallel)
      | prompt | Claude → SalidaA2

El stock NO entra a esta cadena: lo lee A2 del ERP en código (A2 §5).
"""

from __future__ import annotations

from operator import itemgetter
from pathlib import Path

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableParallel
from pydantic import BaseModel, Field

from src.cadenas import eslabon_modelo
from src.conocimiento import buscar

PROMPT = (
    Path(__file__).parents[1] / "agentes" / "a2_asesor_rag" / "prompt.md"
).read_text(encoding="utf-8")


class SalidaA2(BaseModel):
    respuesta: str = Field(description="Texto para el cliente, sin precios")
    fuentes: list[str] = Field(default_factory=list, description="doc_id citados")


def recuperar(pregunta: str) -> list:
    return buscar("catalogo", pregunta, umbral=0.3) + buscar(
        "faq", pregunta, umbral=0.5
    )


def formatear(fragmentos: list) -> str:
    return (
        "\n".join(f"[{f.doc_id}] {f.texto}" for f in fragmentos) or "(sin fragmentos)"
    )


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", PROMPT),
        (
            "human",
            "Fragmentos recuperados:\n{contexto}\n\nSKU identificado: {sku}\nPregunta: {pregunta}",
        ),
    ]
)


def _simulada(valor_prompt) -> SalidaA2:
    contenido = valor_prompt.to_messages()[-1].content
    fuentes = [
        linea[1 : linea.index("]")]
        for linea in contenido.splitlines()
        if linea.startswith("[")
    ]
    return SalidaA2(respuesta="", fuentes=fuentes[:1])


def cadena_rag():
    entrada = RunnableParallel(
        contexto=itemgetter("pregunta")
        | RunnableLambda(recuperar, name="recuperar")
        | RunnableLambda(formatear, name="formatear"),
        pregunta=itemgetter("pregunta"),
        sku=itemgetter("sku"),
    )
    return (
        entrada | prompt | eslabon_modelo("asesor", SalidaA2, 0.0, _simulada, "asesor")
    ).with_config(run_name="lcel_rag_a2")
