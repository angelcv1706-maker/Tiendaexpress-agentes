"""MCP Cotizaciones (simulado). Ejecutar aparte: python -m src.mcp_servers.cotizaciones"""
from __future__ import annotations

from datetime import timedelta

from fastmcp import FastMCP

from src.comun.base import ahora, clave_idempotencia, nuevo_id
from src.datos import simulados as db
from src.decision import VIGENCIA_COTIZACION_H

mcp = FastMCP("mcp-cotizaciones")


@mcp.tool
def obtener_precio(sku: str) -> dict:
    """Precio de lista con IGV incluido, en soles."""
    prod = db.PRODUCTOS.get(sku)
    if not prod:
        return {"error": "ErrorDeDatos", "detalle": f"SKU {sku} no existe"}
    return {"sku": sku, "precio_lista": str(prod["precio_lista"]), "moneda": "PEN"}


@mcp.tool
def listar_promociones(sku: str) -> list[dict]:
    """Solo promociones vigentes hoy para el SKU."""
    hoy = ahora()
    return [{"codigo": p["codigo"], "descuento": str(p["descuento"]), "cuotas_max": p["cuotas_max"],
             "sin_intereses": p["sin_intereses"], "vigente_hasta": p["vigente_hasta"].isoformat()}
            for p in db.PROMOCIONES
            if p["sku"] == sku and p["vigente_desde"] <= hoy <= p["vigente_hasta"]]


@mcp.tool
def calcular_cuotas(monto: str, cuotas_max: int, sin_intereses: bool) -> dict:
    """Texto de cuotas tal como lo permite la promoción (nunca financiamiento propio)."""
    texto = f"hasta {cuotas_max} cuotas con tarjetas participantes"
    if sin_intereses:
        texto += " sin intereses"
    return {"monto": monto, "texto": texto}


@mcp.tool
def crear_cotizacion(id_cliente: str, sku: str, cantidad: int, precio_unitario: str,
                     descuento: str, subtotal: str, envio: str, total: str,
                     codigo_promo: str = "") -> dict:
    """Crea la cotización (vigencia 72 h). Idempotente por cliente|sku|cantidad|promo."""
    clave = clave_idempotencia(id_cliente, sku, cantidad, codigo_promo)
    if clave in db.IDEMPOTENCIA:
        return {"id_cotizacion": db.IDEMPOTENCIA[clave], "repetida": True,
                **db.COTIZACIONES[db.IDEMPOTENCIA[clave]]}
    cot_id = nuevo_id("COT")
    vence = ahora() + timedelta(hours=VIGENCIA_COTIZACION_H)
    db.COTIZACIONES[cot_id] = {"id_cliente": id_cliente, "sku": sku, "cantidad": cantidad,
                               "precio_unitario": precio_unitario, "descuento": descuento,
                               "subtotal": subtotal, "envio": envio, "total": total,
                               "vence": vence.isoformat(), "estado": "VIGENTE"}
    db.IDEMPOTENCIA[clave] = cot_id
    return {"id_cotizacion": cot_id, "repetida": False, **db.COTIZACIONES[cot_id]}


@mcp.tool
def obtener_cotizacion(id_cotizacion: str) -> dict:
    cot = db.COTIZACIONES.get(id_cotizacion)
    if not cot:
        return {"error": "ErrorDeDatos", "detalle": "cotización inexistente"}
    if cot["estado"] == "VIGENTE" and ahora().isoformat() > cot["vence"]:
        cot["estado"] = "VENCIDA"
    return {"id_cotizacion": id_cotizacion, **cot}


if __name__ == "__main__":
    mcp.run()
