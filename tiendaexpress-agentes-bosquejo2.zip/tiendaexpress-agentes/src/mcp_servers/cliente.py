"""Único punto por el que los agentes llegan a los servidores MCP.

- PERMISOS replica la tabla «Quién escribe» del contexto §8: un agente solo puede llamar
  a las herramientas de su fila. Así A3 no puede programar recojos y A7 no puede cotizar.
- Si existe la variable MCP_URL_<SERVIDOR> (p. ej. MCP_URL_PAGOS_ERP=http://localhost:9005/mcp)
  se conecta por HTTP; si no, usa el servidor FastMCP en el mismo proceso (modo bosquejo).
- Reintentos por clase de error (§9.4): courier 4 × 2 s, pasarela 3 × 5 s.
"""
from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager

import jsonschema  # noqa: F401  pre-carga: el cliente MCP la importa tarde y `langgraph dev` lo marca como bloqueante
from fastmcp import Client
from langchain.mcp import MCPAdapter  # beta en langchain 1.4

from src.comun.base import ErrorDeDatos, ErrorTransitorio, cronometro, registrar
from src.mcp_servers import cotizaciones, otros, pagos_erp

SERVIDORES = {
    "cotizaciones": cotizaciones.mcp,
    "pagos_erp": pagos_erp.mcp,
    "crm": otros.crm,
    "courier": otros.courier,
    "citas": otros.citas,
}

PERMISOS: dict[str, set[tuple[str, str]]] = {
    "a0": {("crm", "buscar_cliente"), ("crm", "registrar_interaccion")},
    "a2": {("pagos_erp", "consultar_stock")},
    "a3": {("cotizaciones", "obtener_precio"), ("cotizaciones", "listar_promociones"),
           ("cotizaciones", "calcular_cuotas"), ("cotizaciones", "crear_cotizacion"),
           ("cotizaciones", "obtener_cotizacion"), ("courier", "cotizar_envio"),
           ("pagos_erp", "crear_prepedido")},
    "a4": {("citas", "consultar_disponibilidad"), ("citas", "reservar_demo"),
           ("citas", "cancelar_demo")},
    "a5": {("crm", "upsert_lead"), ("crm", "actualizar_lead_score"), ("crm", "cerrar_lead"),
           ("crm", "buscar_cliente")},
    "a6": {("pagos_erp", "buscar_pedido")},
    "a7": {("pagos_erp", "buscar_pedido"), ("pagos_erp", "revertir_pago"), ("pagos_erp", "consultar_reembolso"),
           ("pagos_erp", "registrar_nota_credito"), ("pagos_erp", "actualizar_estado_caso")},
    "a8": {("courier", "cotizar_envio"), ("courier", "programar_recojo"),
           ("courier", "consultar_estado_envio"), ("pagos_erp", "buscar_pedido"),
           ("pagos_erp", "actualizar_estado_caso")},
}

REINTENTOS = {"courier": (4, 2.0), "pagos_erp": (3, 5.0)}


def destino(servidor: str):
    url = os.getenv(f"MCP_URL_{servidor.upper()}")
    return url or SERVIDORES[servidor]


async def llamar(agente: str, servidor: str, herramienta: str, trace_id: str = "-", **args) -> dict:
    if (servidor, herramienta) not in PERMISOS.get(agente, set()):
        raise PermissionError(f"{agente} no puede usar {servidor}.{herramienta}")
    intentos, espera = REINTENTOS.get(servidor, (1, 0.0))
    for intento in range(1, intentos + 1):
        try:
            with cronometro() as t:
                async with Client(destino(servidor)) as c:
                    res = await c.call_tool(herramienta, args)
            registrar(trace_id, agente, f"{servidor}.{herramienta}", duracion_ms=t["ms"])
            data = res.data
            if isinstance(data, dict) and data.get("error") == "ErrorDeDatos":
                raise ErrorDeDatos(data.get("detalle", ""))
            return data
        except (ConnectionError, TimeoutError) as e:
            if intento == intentos:
                # Aquí iría el envío a `cola_fallidos` con la carga completa.
                raise ErrorTransitorio(f"{servidor}.{herramienta}: {e}") from e
            await asyncio.sleep(espera)


@asynccontextmanager
async def herramientas_langchain(agente: str, servidor: str):
    """Herramientas MCP como tools de LangChain (langchain.mcp, beta), filtradas por permiso.

    Úsenlo cuando un agente de `create_agent` deba decidir qué herramienta llamar (A2).
    """
    permitidas = {h for s, h in PERMISOS[agente] if s == servidor}
    async with MCPAdapter(destino(servidor)) as adaptador:
        yield [t for t in await adaptador.list_tools() if t.name in permitidas]
