"""MCP CRM, MCP Courier y MCP Citas (simulados) en un solo archivo para el bosquejo.

En el repositorio final cada uno va en su archivo (crm.py, courier.py, citas.py), como dice
/AGENTS.md §2. Ejecutar uno aparte: python -m src.mcp_servers.otros crm
"""
from __future__ import annotations

import sys
from datetime import datetime, timedelta

from fastmcp import FastMCP

from src.comun.base import LIMA, ahora, clave_idempotencia, nuevo_id
from src.datos import simulados as db

# ------------------------------------------------------------------ CRM
crm = FastMCP("mcp-crm")


@crm.tool
def buscar_cliente(cliente_ref: str) -> dict:
    return {"cliente_ref": cliente_ref, **db.CLIENTES.get(cliente_ref, {"lead_id": None, "interacciones_7d": 0})}


@crm.tool
def registrar_interaccion(id_consulta: str, canal: str, texto_enmascarado: str) -> dict:
    db.INTERACCIONES.append({"id_consulta": id_consulta, "canal": canal, "texto": texto_enmascarado})
    return {"ok": True}


@crm.tool
def upsert_lead(cliente_ref: str) -> dict:
    cli = db.CLIENTES.setdefault(cliente_ref, {"lead_id": None, "interacciones_7d": 0})
    if not cli["lead_id"]:
        cli["lead_id"] = nuevo_id("LEAD")
        db.LEADS[cli["lead_id"]] = {"estado": "NUEVO", "score": 0, "senales": {}}
    return {"lead_id": cli["lead_id"], **db.LEADS[cli["lead_id"]]}


@crm.tool
def actualizar_lead_score(lead_id: str, score: int, senales: dict, estado: str) -> dict:
    db.LEADS[lead_id].update({"score": score, "senales": senales, "estado": estado})
    return {"lead_id": lead_id, **db.LEADS[lead_id]}


@crm.tool
def cerrar_lead(lead_id: str, motivo: str) -> dict:
    db.LEADS[lead_id]["cierre"] = motivo   # el lead no se borra (A5 §5)
    return {"lead_id": lead_id, "motivo": motivo}


# ------------------------------------------------------------------ Courier
courier = FastMCP("mcp-courier")


@courier.tool
def cotizar_envio(distrito: str, peso_kg: str) -> dict:
    """Opciones de envío por courier. Lista vacía = sin cobertura."""
    opciones = db.COBERTURA_COURIER.get(distrito, {})
    return {"distrito": distrito, "lima_metropolitana": distrito in db.LIMA_METROPOLITANA,
            "opciones": [{"courier": c, "costo": str(costo), "plazo_h": h}
                         for c, (costo, h) in opciones.items()]}


@courier.tool
def programar_recojo(id_caso: str, distrito: str, direccion: str, courier: str, ventana: str) -> dict:
    clave = clave_idempotencia("recojo", id_caso)
    if clave not in db.IDEMPOTENCIA:
        db.IDEMPOTENCIA[clave] = nuevo_id("RCJ", 6)
    fecha = (ahora() + timedelta(days=1)).date().isoformat()
    return {"id_recojo": db.IDEMPOTENCIA[clave], "courier": courier, "fecha": fecha, "ventana": ventana}


@courier.tool
def consultar_estado_envio(id_recojo: str) -> dict:
    return {"id_recojo": id_recojo, "estado": "PROGRAMADO"}


# ------------------------------------------------------------------ Citas
citas = FastMCP("mcp-citas")


@citas.tool
def consultar_disponibilidad(desde: str, hasta: str) -> list[str]:
    """Horarios libres (ISO, America/Lima) cada 30 min entre 10:00 y 17:30, lun-sáb."""
    inicio = datetime.fromisoformat(desde).astimezone(LIMA)
    fin = datetime.fromisoformat(hasta).astimezone(LIMA)
    ocupados = {d["inicio"] for d in db.DEMOS.values() if d["estado"] == "RESERVADA"}
    libres, t = [], inicio.replace(minute=0 if inicio.minute == 0 else 30, second=0, microsecond=0)
    while t <= fin and len(libres) < 50:
        if t.weekday() < 6 and 10 <= t.hour < 18 and t.isoformat() not in ocupados:
            libres.append(t.isoformat())
        t += timedelta(minutes=30)
    return libres


@citas.tool
def reservar_demo(lead_id: str, sku: str, inicio: str) -> dict:
    clave = clave_idempotencia(lead_id, sku, inicio)
    if clave not in db.IDEMPOTENCIA:
        cita = nuevo_id("CITA")
        db.DEMOS[cita] = {"lead_id": lead_id, "sku": sku, "inicio": inicio, "estado": "RESERVADA"}
        db.IDEMPOTENCIA[clave] = cita
    return {"id_cita": db.IDEMPOTENCIA[clave], **db.DEMOS[db.IDEMPOTENCIA[clave]]}


@citas.tool
def cancelar_demo(id_cita: str) -> dict:
    db.DEMOS[id_cita]["estado"] = "CANCELADA"
    return {"id_cita": id_cita, "estado": "CANCELADA"}


SERVIDORES = {"crm": crm, "courier": courier, "citas": citas}

if __name__ == "__main__":
    SERVIDORES[sys.argv[1]].run()
