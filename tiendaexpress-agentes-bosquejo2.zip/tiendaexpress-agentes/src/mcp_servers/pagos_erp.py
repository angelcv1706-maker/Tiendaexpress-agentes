"""MCP Pagos y ERP (simulado). Ejecutar aparte: python -m src.mcp_servers.pagos_erp"""
from __future__ import annotations

from decimal import Decimal

from fastmcp import FastMCP

from src.comun.base import ahora, clave_idempotencia, nuevo_id
from src.datos import simulados as db

mcp = FastMCP("mcp-pagos-erp")


@mcp.tool
def buscar_pedido(pedido: str) -> dict:
    p = db.PEDIDOS.get(pedido)
    if not p:
        return {"existe": False}
    return {"existe": True, "pedido": pedido, **{k: (str(v) if isinstance(v, Decimal) else v)
                                                  for k, v in p.items() if k != "fecha_entrega"},
            "fecha_entrega": p["fecha_entrega"].isoformat()}


@mcp.tool
def consultar_stock(sku: str) -> dict:
    """Stock en tiempo real (A2 §2: nunca del índice RAG)."""
    prod = db.PRODUCTOS.get(sku)
    if not prod:
        return {"error": "ErrorDeDatos", "detalle": f"SKU {sku} no existe"}
    return {"sku": sku, "stock": prod["stock"], "leido_en": ahora().isoformat()}


@mcp.tool
def crear_prepedido(id_cotizacion: str) -> dict:
    cot = db.COTIZACIONES.get(id_cotizacion)
    if not cot or cot["estado"] != "VIGENTE":
        return {"error": "ErrorDeDatos", "detalle": "cotización inexistente o no vigente"}
    clave = clave_idempotencia("prepedido", id_cotizacion)
    if clave not in db.IDEMPOTENCIA:
        db.IDEMPOTENCIA[clave] = nuevo_id("PED")
        cot["estado"] = "ACEPTADA"
    return {"id_prepedido": db.IDEMPOTENCIA[clave], "id_cotizacion": id_cotizacion}


@mcp.tool
def actualizar_estado_caso(id_caso: str, estado: str, detalle: str = "") -> dict:
    caso = db.CASOS.setdefault(id_caso, {})
    caso.update({"estado": estado, "detalle": detalle, "actualizado": ahora().isoformat()})
    return {"id_caso": id_caso, "estado": estado}


@mcp.tool
def revertir_pago(pedido: str, monto: str, clave: str) -> dict:
    """Reversión en la misma pasarela del cobro. Idempotente por HASH(id_caso|monto)."""
    if clave in db.IDEMPOTENCIA:
        return {"id_reembolso": db.IDEMPOTENCIA[clave], "repetida": True}
    p = db.PEDIDOS[pedido]
    reem = nuevo_id("REEM", 6)
    db.REEMBOLSOS[reem] = {"pedido": pedido, "monto": monto, "medio": p["medio_pago"],
                           "estado": "REVERTIDO"}
    db.IDEMPOTENCIA[clave] = reem
    return {"id_reembolso": reem, "medio": p["medio_pago"], "repetida": False}


@mcp.tool
def consultar_reembolso(clave: str) -> dict:
    """Estado de un reembolso por su clave de idempotencia (sin efectos)."""
    reem = db.IDEMPOTENCIA.get(clave)
    if not reem:
        return {"existe": False}
    nc = db.IDEMPOTENCIA.get(clave_idempotencia("nc", reem))
    return {"existe": True, "id_reembolso": reem, "medio": db.REEMBOLSOS[reem]["medio"], "nota_credito": nc}


@mcp.tool
def registrar_nota_credito(pedido: str, monto: str, motivo: str, id_reembolso: str) -> dict:
    clave = clave_idempotencia("nc", id_reembolso)
    if clave not in db.IDEMPOTENCIA:
        db.IDEMPOTENCIA[clave] = f"NC-{id_reembolso[-6:]}"
        db.REEMBOLSOS[id_reembolso]["estado"] = "NOTA_CREDITO_EMITIDA"
    return {"nota_credito": db.IDEMPOTENCIA[clave], "pedido": pedido, "monto": monto}


if __name__ == "__main__":
    mcp.run()
