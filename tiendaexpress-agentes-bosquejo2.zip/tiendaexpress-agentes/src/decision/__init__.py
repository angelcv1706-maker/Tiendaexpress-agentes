"""Umbrales y `decide()` tipada (contexto §9.1).

Las reglas de monto, plazo y permiso viven aquí, en código: una `p` alta nunca concede
autorización. Los umbrales NO se repiten en ningún prompt.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

TAU_AUTO = 0.80          # p ≥ τ_auto → ejecutar automáticamente
TAU_REV = 0.50           # p < τ_rev  → escalar a humano
DESCUENTO_MAX_AUTO = Decimal("0.10")   # > 10 % → Coordinador Comercial
LEAD_CALIFICADO = 60
PLAZO_DEVOLUCION_DIAS = 7
VIGENCIA_COTIZACION_H = 72
ENVIO_GRATIS_DESDE = Decimal("299.00")


class Ruta(str, Enum):
    AUTOMATICO = "automatico"
    REVISION = "revision_humana"
    ESCALAR = "escalar_humano"


def ruta_por_confianza(p: float) -> Ruta:
    """Compuerta HITL por confianza. No es un permiso: los límites se validan aparte."""
    if not 0.0 <= p <= 1.0:
        raise ValueError(f"p fuera de rango: {p}")
    if p >= TAU_AUTO:
        return Ruta.AUTOMATICO
    if p >= TAU_REV:
        return Ruta.REVISION
    return Ruta.ESCALAR


def descuento_requiere_hitl(descuento: Decimal, respaldado_por_promo: bool) -> bool:
    """§4.1: > 10 % o rebaja sin promoción vigente → aprobación humana."""
    return descuento > DESCUENTO_MAX_AUTO or (descuento > 0 and not respaldado_por_promo)


@dataclass(frozen=True)
class Decision:
    """Lo que devuelve decide(): la etiqueta, su confianza y la ruta que sigue."""
    etiqueta: str
    p: float
    ruta: Ruta
    motivo: str


def decide(etiqueta: str, p: float, motivo: str = "", forzar_humano: bool = False) -> Decision:
    ruta = Ruta.ESCALAR if forzar_humano else ruta_por_confianza(p)
    return Decision(etiqueta=etiqueta, p=p, ruta=ruta, motivo=motivo)
