"""Cómo obtener `p` con Claude.

La API de Claude no expone logprobs, así que `p` no puede leerse del modelo directamente.
Este bosquejo usa autoconsistencia: se pide la misma clasificación N veces y `p` es la
proporción de votos de la etiqueta ganadora. Luego `calibrar()` corrige esa proporción
con las decisiones humanas guardadas en `etiquetas_calibracion` (contexto §9.1).

Costo: N llamadas por mensaje. Con Haiku 5.5 y N = 5 sigue siendo barato; ajusten N.
"""
from __future__ import annotations

from collections import Counter
from typing import Callable, Sequence


def autoconsistencia(muestrear: Callable[[], str], n: int = 5) -> tuple[str, float]:
    votos = Counter(muestrear() for _ in range(n))
    etiqueta, cuenta = votos.most_common(1)[0]
    return etiqueta, cuenta / n


def calibrar(p_cruda: float, historial: Sequence[tuple[float, bool]] | None = None) -> float:
    """Calibración por cubetas (histograma) sobre (p_cruda, acerto_el_humano).

    Sin historial suficiente devuelve p_cruda recortada a 0,99 (nunca 1,0: A1 §5).
    Con más de ~200 etiquetas conviene pasar a regresión isotónica (scikit-learn).
    """
    p = min(p_cruda, 0.99)
    if not historial or len(historial) < 30:
        return round(p, 2)
    ancho = 0.2
    cubeta = [ok for pc, ok in historial if abs(pc - p_cruda) <= ancho / 2]
    if len(cubeta) < 10:
        return round(p, 2)
    return round(min(sum(cubeta) / len(cubeta), 0.99), 2)
