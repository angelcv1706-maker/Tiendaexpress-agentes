"""MODO_SIMULADO=1: reemplaza cada llamada a Claude por una heurística simple.

Sirve para recorrer el grafo completo en el IDE o en LangGraph Studio sin API key ni costo,
y para las pruebas. NO evalúa la calidad de los agentes: para eso está LangSmith (evals/).
"""
from __future__ import annotations

import os
import re


def activo() -> bool:
    return os.getenv("MODO_SIMULADO", "0") == "1"


def clasificar(texto: str) -> dict:
    t = texto.lower()
    requiere = []
    if any(w in t for w in ["stock", "tienen", "caracter", "ficha", "garant", "disponib"]):
        requiere.append("producto")
    if any(w in t for w in ["cuánto", "cuanto", "precio", "cuesta", "cuotas", "descuento"]):
        requiere.append("precio")
    if any(w in t for w in ["llega", "envío", "envio", "delivery", "despacho a"]):
        requiere.append("envio")
    if re.search(r"\b([6-9]|\d{2,})\s+(laptops|unidades|equipos)", t) or "empresa" in t or "<ruc_" in t:
        return {"dominio": "preventa", "intencion": "compleja", "requiere": [], "p": 0.9, "motivo": "volumen/empresa"}
    if "reclamo formal" in t or "libro de reclamaciones" in t:
        return {"dominio": "fuera_de_alcance", "intencion": "compleja", "requiere": [], "p": 0.9, "motivo": "reclamo"}
    if any(w in t for w in ["roto", "dañad", "devolver", "devolución", "devolucion", "no funciona", "falla"]):
        return {"dominio": "devolucion", "intencion": "devolucion", "requiere": [], "p": 0.9, "motivo": "devolución"}
    if any(w in t for w in ["lo quiero", "cómo pago", "como pago", "confirmo", "comprar"]):
        return {"dominio": "preventa", "intencion": "compra", "requiere": [], "p": 0.9, "motivo": "compra"}
    if "demo" in t or "asesor" in t:
        return {"dominio": "preventa", "intencion": "demo", "requiere": requiere, "p": 0.85, "motivo": "demo"}
    if requiere:
        intencion = "precio" if "precio" in requiere else ("envio" if "envio" in requiere else "info_producto")
        return {"dominio": "preventa", "intencion": intencion, "requiere": requiere, "p": 0.9, "motivo": "palabras clave"}
    return {"dominio": "preventa", "intencion": "info_producto", "requiere": ["producto"], "p": 0.6,
            "motivo": "sin señales claras"}


def extraer_cotizacion(texto: str) -> dict:
    t = texto.lower()
    m = re.search(r"\b(\d{1,3})\s+(unidades|laptops|equipos)", t)
    distrito = next((d for d in ["Miraflores", "Trujillo", "Arequipa", "San Isidro", "Surco"] if d.lower() in t), "")
    return {"producto_mencionado": texto, "cantidad": int(m.group(1)) if m else 1, "distrito": distrito,
            "pide_cuotas": "cuota" in t, "pide_rebaja": "rebaja" in t or "más barato" in t}


def lectura_evidencia(motivo: str, fotos: list[str]) -> dict:
    t = motivo.lower()
    categoria = ("transporte" if any(w in t for w in ["roto", "golpe", "dañad"]) else
                 "producto_distinto" if "distinto" in t or "otro modelo" in t else
                 "falla_fabrica" if "no funciona" in t or "falla" in t else
                 "mal_uso" if "se me cayó" in t or "mojé" in t else "otro")
    dudosa = any("borrosa" in f for f in fotos)
    return {"motivo_categoria": categoria, "fotos_coinciden": True, "fotos_concluyentes": not dudosa,
            "contradice_pedido": False, "p": 0.45 if dudosa else 0.88,
            "motivo_para_cliente": "Revisamos su evidencia y la solicitud cumple la política de devoluciones."
            if categoria in {"transporte", "producto_distinto", "falla_fabrica"} else
            "Según la evidencia, el motivo no está cubierto por la política de devoluciones."}


def redactar(datos: dict) -> str:
    partes = []
    a2, a3 = datos.get("a2"), datos.get("a3")
    if a2 and not a2.get("necesita_aclaracion"):
        if a2["stock"] > 0:
            partes.append(f"Sí tenemos {a2['nombre']} en stock ({a2['stock']} unidades).")
        else:
            alts = ", ".join(a["nombre"] for a in a2["alternativas"]) or "ninguna por ahora"
            partes.append(f"{a2['nombre']} está sin stock. Alternativas disponibles: {alts}.")
    if a3 and not a3.get("necesita_aclaracion"):
        txt = f"El total es {a3['total_texto']} (IGV incluido)"
        if a3.get("envio_gratis"):
            txt += ", con envío gratis"
        elif a3.get("plazo_envio_h"):
            txt += f", envío incluido con llegada estimada en {a3['plazo_envio_h']} h"
        partes.append(txt + f". Cotización {a3.get('id_cotizacion', '')} válida por 72 horas.")
    if datos.get("demo"):
        partes.append(datos["demo"])
    return " ".join(partes) or "Gracias por escribirnos. ¿Podría darnos más detalle del producto?"
