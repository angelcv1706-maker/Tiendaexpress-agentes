"""A7 Financiero como Deep Agent (create_deep_agent).

Memoria: src/agentes/a7_financiero/AGENTS.md · Skill: politica-reembolso
HITL: `revertir_pago` necesita aprobación humana (interrupt_on). La interrupción sube hasta el
grafo principal y se reanuda con Command(resume={"decisions": [{"type": "approve"}]}).

Las herramientas no guardan estado entre llamadas: al reanudar tras la aprobación, el nodo se
vuelve a ejecutar, así que cada herramienta recalcula el monto y consulta el reembolso por su
clave de idempotencia.
"""

from __future__ import annotations

from decimal import Decimal

from langchain.tools import tool

from src import simulado
from src.agentes.a7_financiero.agente import calcular_monto, verificar_precondiciones
from src.comun.base import clave_idempotencia
from src.deep_agents import backend_solo_lectura
from src.mcp_servers.cliente import llamar

PROMPT = """Eres A7, el agente financiero de TiendaExpress. Ejecutas reembolsos de casos de devolución
aprobados. Primero escribe tu plan con `write_todos`. Antes de actuar, lee la skill `politica-reembolso` y sigue su orden. Nunca calcules montos
tú mismo: usa las herramientas. Si una precondición falla, detente y explica el motivo."""

ATRIBUIBLES = {"transporte", "producto_distinto", "falla_fabrica"}


async def _monto(caso: dict, trace_id: str) -> tuple[Decimal, str]:
    p = await llamar("a7", "pagos_erp", "buscar_pedido", trace_id=trace_id, pedido=caso["pedido"])
    monto = calcular_monto(
        Decimal(p["monto_item"]),
        Decimal(p["envio"]),
        Decimal(p["total_pagado"]),
        caso.get("motivo_categoria") in ATRIBUIBLES,
    )
    return monto, p["medio_pago"]


async def _reembolso(caso: dict, trace_id: str) -> tuple[Decimal, str, dict]:
    monto, medio = await _monto(caso, trace_id)
    clave = clave_idempotencia(caso["id_caso"], monto)
    estado = await llamar("a7", "pagos_erp", "consultar_reembolso", trace_id=trace_id, clave=clave)
    return monto, clave, {**estado, "medio": estado.get("medio", medio)}


def mensaje_autorizacion(caso: dict, monto, medio: str) -> str:
    """Lo que ve quien aprueba: acción, efecto, motivo, caso original y opciones (sin firma en blanco)."""
    from src.comun.base import formato_soles

    importe = formato_soles(monto)
    return (
        f"Acción: revertir el pago del pedido {caso['pedido']} (caso {caso['id_caso']}) por {importe} "
        f"en {medio.capitalize()}.\n"
        f"Efecto: el cliente recibe {importe} en su medio de pago original; deshacerlo exige un nuevo cobro.\n"
        "Motivo de la detención: toda reversión de pago requiere aprobación humana (política de A7).\n"
        f"Caso original: {caso.get('texto') or '(sin texto)'} · motivo validado: {caso.get('motivo_categoria')}.\n"
        "Opciones: Aprobar → se revierte el pago y se emite la nota de crédito. "
        "Rechazar → no se mueve dinero y el caso queda REEMBOLSO_PENDIENTE con el motivo que escribas."
    )


def construir(caso: dict, trace_id: str = "-", monto=None, medio: str = ""):
    from deepagents import create_deep_agent
    from langchain.agents.middleware import TodoListMiddleware

    @tool
    def verificar_precondiciones_reembolso() -> str:
        """Comprueba PRODUCTO_RECIBIDO, veredicto aprobado y que no haya reembolso previo."""
        verificar_precondiciones(caso)
        return "Precondiciones cumplidas."

    @tool
    async def calcular_monto_reembolso() -> str:
        """Calcula el monto a reembolsar (ítem + envío si la falla es de la tienda; tope: total pagado)."""
        monto, medio = await _monto(caso, trace_id)
        return f"Monto: {monto} soles, por {medio}."

    @tool
    async def revertir_pago() -> str:
        """Revierte el cobro en la misma pasarela. Requiere aprobación humana. Una sola vez por caso."""
        monto, clave, estado = await _reembolso(caso, trace_id)
        if estado["existe"]:
            return f"Ya revertido: {estado['id_reembolso']}"
        rev = await llamar(
            "a7",
            "pagos_erp",
            "revertir_pago",
            trace_id=trace_id,
            pedido=caso["pedido"],
            monto=str(monto),
            clave=clave,
        )
        return f"Reversión hecha: {rev['id_reembolso']}"

    @tool
    async def registrar_nota_credito() -> str:
        """Registra la nota de crédito electrónica del reembolso en el ERP."""
        monto, _, estado = await _reembolso(caso, trace_id)
        if not estado["existe"]:
            return "No hay reversión registrada: primero revertir_pago."
        nc = await llamar(
            "a7",
            "pagos_erp",
            "registrar_nota_credito",
            trace_id=trace_id,
            pedido=caso["pedido"],
            monto=str(monto),
            motivo="devolución",
            id_reembolso=estado["id_reembolso"],
        )
        await llamar(
            "a7",
            "pagos_erp",
            "actualizar_estado_caso",
            trace_id=trace_id,
            id_caso=caso["id_caso"],
            estado="REEMBOLSADA",
        )
        return f"Nota de crédito {nc['nota_credito']} registrada."

    herramientas = [
        verificar_precondiciones_reembolso,
        calcular_monto_reembolso,
        revertir_pago,
        registrar_nota_credito,
    ]
    if simulado.activo():
        from src.deep_agents.modelo_guion import ModeloGuion

        modelo = ModeloGuion(
            guion=[
                (
                    "write_todos",
                    {
                        "todos": [
                            {"content": "Verificar precondiciones", "status": "in_progress"},
                            {"content": "Calcular monto", "status": "pending"},
                            {"content": "Revertir pago (requiere aprobación)", "status": "pending"},
                            {"content": "Registrar nota de crédito", "status": "pending"},
                        ]
                    },
                )
            ]
            + [(t.name, {}) for t in herramientas],
            cierre="Reembolso completado.",
        )
    else:
        from src.config import modelo as modelo_por_rol

        modelo = modelo_por_rol("asesor")

    backend, permisos = backend_solo_lectura()
    return create_deep_agent(
        model=modelo,
        tools=herramientas,
        system_prompt=PROMPT,
        name="a7_financiero_deep",
        memory=["/src/agentes/a7_financiero/AGENTS.md"],
        skills=["/src/deep_agents/skills/a7/"],
        backend=backend,
        permissions=permisos,
        middleware=[TodoListMiddleware()],
        interrupt_on={
            "revertir_pago": {
                "allowed_decisions": ["approve", "reject"],
                "description": mensaje_autorizacion(caso, monto, medio)
                if monto is not None
                else "Aprobar la reversión del pago al cliente",
            }
        },
    )


async def reembolsar(caso: dict, trace_id: str = "-") -> dict:
    monto_previo, medio = await _monto(caso, trace_id)  # para el mensaje de autorización
    salida = await construir(caso, trace_id, monto_previo, medio).ainvoke(
        {"messages": [("human", f"Reembolsa el caso {caso['id_caso']} (pedido {caso['pedido']}).")]}
    )
    monto, _, estado = await _reembolso(caso, trace_id)
    if not estado.get("nota_credito"):
        rechazo = [m for m in salida["messages"] if m.type == "tool" and m.name == "revertir_pago"]
        motivo = rechazo[-1].text if rechazo else salida["messages"][-1].text
        return {"completado": False, "motivo": motivo}
    return {
        "completado": True,
        "id_reembolso": estado["id_reembolso"],
        "monto": monto,
        "medio": estado["medio"],
        "nota_credito": estado["nota_credito"],
    }
