"""Modelo falso para MODO_SIMULADO: llama las herramientas en el orden del guion.

Sirve solo para probar la integración del Deep Agent (memoria, skills, HITL, trazas) sin
API key. Con Claude real, el plan lo decide el modelo leyendo la skill.
"""
from __future__ import annotations

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult


class ModeloGuion(BaseChatModel):
    guion: list[tuple[str, dict]] = []
    cierre: str = "Listo."

    @property
    def _llm_type(self) -> str:
        return "guion-simulado"

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs) -> ChatResult:
        hechos = sum(1 for m in messages if isinstance(m, ToolMessage))
        if hechos < len(self.guion):
            nombre, args = self.guion[hechos]
            msg = AIMessage(content="", tool_calls=[{"name": nombre, "args": args, "id": f"guion-{hechos}"}])
        else:
            msg = AIMessage(content=self.cierre)
        return ChatResult(generations=[ChatGeneration(message=msg)])
