"""Deep Agents elegidos: A6 Validador y A7 Financiero (las operaciones delicadas de D2).

Por qué estos dos:
- A7 mueve dinero (reversión en Niubiz/Culqi y nota de crédito). Un Deep Agent le da un plan
  explícito, memoria con su AGENTS.md, la política como skill y HITL por herramienta
  (`interrupt_on`) sobre `revertir_pago`.
- A6 decide si una devolución procede, revisando reglas, políticas y fotos en varios pasos.

Lo que NO cambia: las reglas siguen en código. Las herramientas del Deep Agent son funciones
deterministas (precondiciones, monto, veredicto); el agente solo decide el orden y explica.

Se activan con USAR_DEEP_AGENTS=1. Con MODO_SIMULADO=1 usan `ModeloGuion`, un modelo falso
que sigue el orden de la skill, para probar la integración sin API key.
"""
from __future__ import annotations

import os
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]   # raíz del repositorio


def activos() -> bool:
    return os.getenv("USAR_DEEP_AGENTS", "0") == "1"


def backend_solo_lectura():
    """El agente lee AGENTS.md y skills del repo; no puede escribir archivos."""
    from deepagents import FilesystemPermission
    from deepagents.backends import FilesystemBackend

    return (FilesystemBackend(root_dir=RAIZ, virtual_mode=True),
            [FilesystemPermission(operations=["write"], paths=["/**"], mode="deny")])
