"""A6 Validador como Deep Agent (create_deep_agent).

Memoria: src/agentes/a6_validador/AGENTS.md · Skill: politica-devolucion
Las tres herramientas envuelven el código de A6: reglas duras, cadena LCEL de evidencia y
veredicto final. El Deep Agent organiza los pasos y explica; no puede saltarse las reglas.
Sin HITL propio: un veredicto `complejo` lo deriva el grafo a Soporte.
"""

from __future__ import annotations

from langchain.tools import tool

from src import simulado
from src.agentes.a6_validador import agente as a6
from src.deep_agents import backend_solo_lectura

PROMPT = """Eres A6, el validador de devoluciones de TiendaExpress. Primero escribe tu plan con `write_todos`. Lee la skill `politica-devolucion`
y sigue su orden de trabajo. No prometas reembolsos ni plazos al cliente."""


def construir(
    pedido: str | None,
    motivo: str | None,
    fotos: list[str] | None,
    trace_id: str = "-",
    reevaluacion: str = "",
):
    from deepagents import create_deep_agent
    from langchain.agents.middleware import TodoListMiddleware

    registro: dict = {}

    @tool
    async def validar_reglas_duras() -> str:
        """Contrato (pedido, motivo, fotos), pedido existente y plazo de 7 días. Devuelve el veredicto
        si alguna regla ya decide el caso."""
        r = await a6.validar(pedido, motivo, fotos, trace_id=trace_id, reevaluacion=reevaluacion)
        registro["resultado"] = r
        return f"Veredicto por reglas y evidencia: {r['veredicto']} (p={r.get('p')}). {r['motivo_veredicto']}"

    @tool
    def emitir_veredicto() -> str:
        """Devuelve el veredicto final ya calculado por el código de A6."""
        r = registro.get("resultado")
        return f"VEREDICTO={r['veredicto']}" if r else "Primero validar_reglas_duras."

    herramientas = [validar_reglas_duras, emitir_veredicto]
    if simulado.activo():
        from src.deep_agents.modelo_guion import ModeloGuion

        modelo = ModeloGuion(
            guion=[
                (
                    "write_todos",
                    {
                        "todos": [
                            {"content": "Validar reglas duras y evidencia", "status": "in_progress"},
                            {"content": "Emitir veredicto", "status": "pending"},
                        ]
                    },
                )
            ]
            + [(t.name, {}) for t in herramientas],
            cierre="Veredicto emitido.",
        )
    else:
        from src.config import modelo as modelo_por_rol

        modelo = modelo_por_rol("validador")

    backend, permisos = backend_solo_lectura()
    agente = create_deep_agent(
        model=modelo,
        tools=herramientas,
        system_prompt=PROMPT,
        name="a6_validador_deep",
        memory=["/src/agentes/a6_validador/AGENTS.md"],
        skills=["/src/deep_agents/skills/a6/"],
        backend=backend,
        permissions=permisos,
        middleware=[TodoListMiddleware()],
    )
    return agente, registro


async def validar(pedido, motivo, fotos, trace_id: str = "-", reevaluacion: str = "") -> dict:
    agente, registro = construir(pedido, motivo, fotos, trace_id, reevaluacion)
    await agente.ainvoke({"messages": [("human", f"Valida la devolución del pedido {pedido}.")]})
    if "resultado" not in registro:  # el agente no llamó a las herramientas: se valida igual en código
        registro["resultado"] = await a6.validar(
            pedido, motivo, fotos, trace_id=trace_id, reevaluacion=reevaluacion
        )
    return registro["resultado"]
