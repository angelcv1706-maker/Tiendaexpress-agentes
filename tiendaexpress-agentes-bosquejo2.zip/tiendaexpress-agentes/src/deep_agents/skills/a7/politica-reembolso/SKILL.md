---
name: politica-reembolso
description: Reglas para ejecutar un reembolso de TiendaExpress (precondiciones, monto, reversión y nota de crédito). Léela antes de reembolsar.
---

# Política de reembolso (contexto §5.4 y §9.3)

1. Solo se reembolsa con el caso en `PRODUCTO_RECIBIDO`, veredicto `aprobado` y sin reembolso previo. La herramienta `verificar_precondiciones` lo comprueba en código: si falla, detente y explica por qué.
2. El monto lo calcula `calcular_monto` (código, Decimal): ítem pagado + envío si la falla es atribuible a la tienda, nunca más que el total pagado. No calcules montos tú.
3. `revertir_pago` devuelve el dinero por el mismo medio de pago del cobro. Requiere aprobación humana y es idempotente por `HASH(id_caso|monto)`: nunca la llames dos veces para el mismo caso.
4. Después, `registrar_nota_credito`. Si falla, reintenta solo la nota; nunca la reversión.
5. Termina con un resumen corto: id de reembolso, monto, medio y nota de crédito.
