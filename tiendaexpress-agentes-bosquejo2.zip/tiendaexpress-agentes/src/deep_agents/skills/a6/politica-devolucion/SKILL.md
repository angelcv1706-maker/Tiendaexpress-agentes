---
name: politica-devolucion
description: Reglas para decidir si una devolución procede (plazo, motivos, evidencia, caso complejo). Léela antes de emitir un veredicto.
---

# Política de devolución (contexto §5.1 y §5.2)

- Plazo: hasta 7 días calendario desde la entrega registrada.
- Motivos aceptados: daño en el transporte, producto distinto al pedido, falla de fábrica.
- Motivos rechazados: mal uso, falta de accesorios atribuible al cliente, plazo vencido, pedido inexistente.
- Evidencia obligatoria: código de pedido, motivo de 1 a 300 caracteres y al menos una foto.
- Caso complejo (va a Soporte): fotos no concluyentes, reclamo que contradice el pedido, segundo reclamo del mismo pedido o confianza p < 0,50.

Orden de trabajo: `validar_reglas_duras` → `leer_evidencia` → `emitir_veredicto`. El veredicto final lo combina el código; tú no lo decides solo.
