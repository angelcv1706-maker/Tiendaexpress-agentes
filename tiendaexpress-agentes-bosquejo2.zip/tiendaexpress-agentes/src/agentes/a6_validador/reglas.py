"""Reglas duras de A6 (contexto §5.1–§5.2). Se evalúan ANTES de mirar las fotos con el LLM."""
from __future__ import annotations

from datetime import datetime

from src.comun.base import ahora
from src.decision import PLAZO_DEVOLUCION_DIAS, TAU_REV

MOTIVOS_VALIDOS = {"transporte", "producto_distinto", "falla_fabrica"}


def validar_contrato(pedido: str | None, motivo: str | None, fotos: list[str] | None) -> str | None:
    """Devuelve el motivo exacto del rechazo por datos, o None si el contrato está completo."""
    if not pedido:
        return "Falta el código de pedido."
    if not motivo or not 1 <= len(motivo) <= 300:
        return "El motivo debe tener entre 1 y 300 caracteres."
    if not fotos:
        return "Necesitamos al menos una foto del producto."
    return None


def dentro_de_plazo(fecha_entrega_iso: str, hoy: datetime | None = None) -> bool:
    entrega = datetime.fromisoformat(fecha_entrega_iso).date()
    return ((hoy or ahora()).date() - entrega).days <= PLAZO_DEVOLUCION_DIAS


def veredicto_final(motivo_categoria: str, fotos_concluyentes: bool, fotos_coinciden: bool,
                    contradice_pedido: bool, reclamo_previo: bool, p: float) -> tuple[str, str]:
    """Combina la lectura del LLM con las reglas. Devuelve (veredicto, política aplicada)."""
    if p < TAU_REV or not fotos_concluyentes or contradice_pedido or reclamo_previo:
        return "complejo", "CONTEXTO-5.2"
    if motivo_categoria not in MOTIVOS_VALIDOS or not fotos_coinciden:
        return "rechazado", "POL-DEV-02"
    return "aprobado", "POL-DEV-01"
