"""A6 Validador: reglas en código + cadena LCEL de evidencia (src/cadenas/evidencia.py)."""

from __future__ import annotations


from src.agentes.a6_validador.reglas import (
    dentro_de_plazo,
    validar_contrato,
    veredicto_final,
)
from src.comun.base import clave_idempotencia, nuevo_id
from src.cadenas.evidencia import LecturaEvidencia, cadena_evidencia
from src.conocimiento import buscar
from src.datos import simulados as db
from src.mcp_servers.cliente import llamar

_CASOS_POR_CLAVE: dict[str, dict] = {}


async def leer_evidencia(
    motivo: str, fotos: list[str], producto: str, politicas: str
) -> LecturaEvidencia:
    return await cadena_evidencia().ainvoke(
        {
            "motivo": motivo,
            "fotos": fotos,  # LCEL
            "producto": producto,
            "politicas": politicas,
        }
    )


async def validar(
    pedido: str | None,
    motivo: str | None,
    fotos: list[str] | None,
    trace_id: str = "-",
    reevaluacion: str = "",
) -> dict:
    error = validar_contrato(pedido, motivo, fotos)
    if error:
        return {
            "veredicto": "rechazado",
            "motivo_veredicto": error,
            "p": 1.0,
            "clase_error": "ErrorDeDatos",
            "politica_aplicada": "CONTRATO-LAB03",
        }

    clave = clave_idempotencia(pedido, motivo)
    if clave in _CASOS_POR_CLAVE and not reevaluacion:
        return {**_CASOS_POR_CLAVE[clave], "repetido": True}

    datos = await llamar(
        "a6", "pagos_erp", "buscar_pedido", trace_id=trace_id, pedido=pedido
    )
    if not datos["existe"]:
        return {
            "veredicto": "rechazado",
            "motivo_veredicto": "No encontramos ese pedido.",
            "p": 1.0,
            "politica_aplicada": "POL-DEV-02",
        }
    if not dentro_de_plazo(datos["fecha_entrega"]):
        return {
            "veredicto": "rechazado",
            "p": 1.0,
            "politica_aplicada": "POL-GAR-01",
            "motivo_veredicto": "El plazo de 7 días para devolución venció. Su producto puede "
            "estar cubierto por la garantía del fabricante.",
        }

    politicas = "\n".join(
        f"[{f.doc_id}] {f.texto}"
        for f in buscar("politicas_devolucion", motivo, umbral=0.0)[:3]
    )
    producto = db.PRODUCTOS[datos["sku"]]["nombre"]
    lectura = await leer_evidencia(
        motivo + (f"\nNota del almacén: {reevaluacion}" if reevaluacion else ""),
        fotos,
        producto,
        politicas,
    )
    reclamo_previo = (
        any(c.get("pedido") == pedido for c in _CASOS_POR_CLAVE.values())
        and clave not in _CASOS_POR_CLAVE
    )
    veredicto, politica = veredicto_final(
        lectura.motivo_categoria,
        lectura.fotos_concluyentes,
        lectura.fotos_coinciden,
        lectura.contradice_pedido,
        reclamo_previo,
        lectura.p,
    )
    resultado = {
        "id_caso": _CASOS_POR_CLAVE.get(clave, {}).get("id_caso") or nuevo_id("SOL"),
        "pedido": pedido,
        "veredicto": veredicto,
        "p": lectura.p,
        "motivo_categoria": lectura.motivo_categoria,
        "motivo_veredicto": lectura.motivo_para_cliente,
        "politica_aplicada": politica,
        "evidencias": fotos,
    }
    _CASOS_POR_CLAVE[clave] = resultado
    return resultado
