"""A7 Financiero: sin LLM. Precondiciones y monto en código; dos pasos reanudables."""
from __future__ import annotations

from decimal import Decimal

from src.comun.base import ErrorDeDatos, ErrorManual, clave_idempotencia, soles
from src.mcp_servers.cliente import llamar


def verificar_precondiciones(caso: dict) -> None:
    if caso.get("marca_no_coincide"):
        raise ErrorManual("reevaluar: el almacén reportó que el paquete no coincide")
    if caso.get("estado") != "PRODUCTO_RECIBIDO":
        raise ErrorDeDatos("No se reembolsa sin PRODUCTO_RECIBIDO")
    if caso.get("veredicto") != "aprobado":
        raise ErrorDeDatos("No se reembolsa sin veredicto aprobado")
    if caso.get("id_reembolso"):
        raise ErrorDeDatos("El caso ya tiene un reembolso")


def calcular_monto(monto_item: Decimal, envio: Decimal, total_pagado: Decimal,
                   falla_atribuible_tienda: bool) -> Decimal:
    monto = soles(monto_item + (envio if falla_atribuible_tienda else 0))
    if monto > total_pagado:
        raise ErrorManual("el monto supera el total pagado: revisión humana")
    return monto


async def reembolsar(caso: dict, trace_id: str = "-") -> dict:
    """caso: {id_caso, pedido, estado, veredicto, motivo_categoria, pasos: {...}}"""
    verificar_precondiciones(caso)
    pedido = await llamar("a7", "pagos_erp", "buscar_pedido", trace_id=trace_id, pedido=caso["pedido"])
    atribuible = caso.get("motivo_categoria") in {"transporte", "producto_distinto", "falla_fabrica"}
    monto = calcular_monto(Decimal(pedido["monto_item"]), Decimal(pedido["envio"]),
                           Decimal(pedido["total_pagado"]), atribuible)
    pasos = caso.setdefault("pasos", {})

    if "reversion" not in pasos:   # paso 1: nunca se repite si ya ocurrió
        rev = await llamar("a7", "pagos_erp", "revertir_pago", trace_id=trace_id, pedido=caso["pedido"],
                           monto=str(monto), clave=clave_idempotencia(caso["id_caso"], monto))
        pasos["reversion"] = rev
    if "nota_credito" not in pasos:   # paso 2: se puede reintentar solo
        nc = await llamar("a7", "pagos_erp", "registrar_nota_credito", trace_id=trace_id,
                          pedido=caso["pedido"], monto=str(monto), motivo="devolución",
                          id_reembolso=pasos["reversion"]["id_reembolso"])
        pasos["nota_credito"] = nc
    await llamar("a7", "pagos_erp", "actualizar_estado_caso", trace_id=trace_id,
                 id_caso=caso["id_caso"], estado="REEMBOLSADA")
    return {"id_reembolso": pasos["reversion"]["id_reembolso"], "monto": monto,
            "medio": pedido["medio_pago"], "nota_credito": pasos["nota_credito"]["nota_credito"],
            "pasos": pasos}
