# AGENTS.md · A7 Financiero

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §5.4, §9.3, §9.4. Carril BPMN: **Agente Financiero**, tarea «Procesar reembolso», con «Ejecutar reversión en pasarela» y «Registrar nota de crédito en ERP» (D2).

## 1. Propósito
Ejecuta el **reembolso** de un caso aprobado y recibido: reversión en Niubiz o Culqi y nota de crédito electrónica. Entrega a A9 los datos del comprobante.
- **Fuera de alcance:** decidir si procede (A6), reembolsos parciales negociados y compensaciones o cupones.

## 2. Arquitectura
**Precondiciones (se verifican en código, no en el prompt):** el caso está en estado `PRODUCTO_RECIBIDO`, tiene veredicto `aprobado` y **no tiene** un reembolso previo.

**Rutina:**
1. Leer el caso y el pedido: medio de pago, monto del ítem, envío y total pagado.
2. Calcular el monto en código: `monto = monto_item (+ envio si la falla es atribuible a TiendaExpress)`, con `monto ≤ total_pagado`.
3. `revertir_pago(pedido, monto, clave=HASH(id_caso|monto))` en la misma pasarela del cobro original.
4. `registrar_nota_credito(pedido, monto, motivo)` en el ERP contable.
5. Estado del caso → `REEMBOLSADA` y entrega a A9 de `{REEM-id, monto, medio, nota_credito}`.

**Rama «Reevaluar caso»:** si al leer el caso aparece la marca `no_coincide` del almacén, no se reembolsa y se devuelve al orquestador para pasar a A6.

**Errores:**

| Error | Clase | Respuesta |
|---|---|---|
| La pasarela no responde | Transitorio | 3 intentos con 5 s de espera; luego `cola_fallidos` + alerta |
| Reversión OK pero falla la nota de crédito | Sistema | Reintentar **solo la nota**; nunca repetir la reversión |
| El monto supera el total pagado | Datos | Abortar y pasar a revisión humana |

| Herramienta | Uso | Modo |
|---|---|---|
| MCP Pagos y ERP `buscar_pedido`, `revertir_pago`, `registrar_nota_credito`, `actualizar_estado_caso` | Reembolso y contabilidad | Escritura |

## 3. Convenciones
- `Decimal` con 2 decimales; ID con formato `REEM-######`.
- La reversión y la nota de crédito se registran como **dos pasos con estado propio** para poder reanudar solo el que falló.

## 4. Comandos
```
pytest tests/agentes/test_a7_financiero.py -q
# Prueba de mutación sugerida: quitar la verificación de PRODUCTO_RECIBIDO → test_no_reembolsa_sin_recepcion DEBE fallar
```

## 5. Restricciones
- **No reembolsar sin `PRODUCTO_RECIBIDO` y veredicto `aprobado`.** Previene pagar por productos no devueltos.
- **No reembolsar a una cuenta o medio distinto al del cobro original.** Previene fraude por desvío de fondos.
- **No repetir `revertir_pago` de un caso ya revertido.** Previene el doble reembolso.
- **No calcular montos con el LLM.** Previene montos plausibles pero incorrectos.
- **No omitir la nota de crédito.** Previene descuadres contables y tributarios.
- **No registrar números de tarjeta ni tokens de la pasarela en los logs.** Previene incidentes de seguridad.
