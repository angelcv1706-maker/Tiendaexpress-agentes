# AGENTS.md · A9 Notificador

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §5, §9.2. BPMN: flujos de mensaje hacia el **Cliente**: «Recibir notificación de reembolso» (13. Comprobante de reembolso), aviso de «Solicitud rechazada» y aviso de recojo programado (D2).

## 1. Propósito
Envía las **notificaciones transaccionales** de D2 por WhatsApp (plantilla aprobada) y por correo, y registra la entrega.
- **Fuera de alcance:** conversación libre con el cliente (A0), marketing y notificaciones de pre-venta.

## 2. Arquitectura
| Evento | Plantilla | Datos obligatorios |
|---|---|---|
| Veredicto rechazado | `devolucion_rechazada` | `SOL-id`, motivo_veredicto, orientación (p. ej., garantía del fabricante) |
| Recojo programado | `recojo_programado` | `RCJ-id`, fecha, ventana, courier |
| Reembolso procesado | `comprobante_reembolso` | `REEM-id`, monto, medio, nota de crédito, plazo estimado de acreditación |
| Derivado a soporte | `caso_en_revision` | `SOL-id`, plazo de respuesta |

**Rutina:**
1. Recibir el evento del orquestador con sus datos.
2. Validar que **todos** los campos de la plantilla existan; si falta alguno, no se envía y se registra `ErrorDeDatos`.
3. Desenmascarar solo el nombre y el contacto del destinatario (mapa PII de A0).
4. Enviar por WhatsApp; si falla, enviar por correo. Registrar `entregado | fallido`.
5. Después del `comprobante_reembolso`, el orquestador cierra el caso (`CERRADA`).

**Idempotencia:** `HASH(id_caso|tipo_evento)`; cada evento se notifica una sola vez.

## 3. Convenciones
- Las plantillas viven en `plantillas/` con variables `{{nombre}}`; el texto no se reescribe con el LLM.
- Montos como «S/ 150,90» y fechas como «25/10/2026».

## 4. Comandos
```
pytest tests/agentes/test_a9_notificador.py -q   # campo faltante, envío duplicado, fallback a correo
```

## 5. Restricciones
- **No enviar mensajes fuera de las plantillas aprobadas.** Previene el bloqueo del número de WhatsApp Business.
- **No notificar «reembolso procesado» sin `REEM-id` y nota de crédito.** Previene informar dinero que no se devolvió.
- **No enviar dos veces el mismo evento.** Previene confusión y reclamos.
- **No incluir el número de tarjeta completo ni datos de otros clientes.** Previene fuga de datos.
- **No prometer una fecha exacta de acreditación bancaria;** solo un rango estimado. Previene reclamos por incumplimiento.
