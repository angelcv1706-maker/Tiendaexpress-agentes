"""A9 Notificador: plantillas fijas, sin LLM. Idempotente por id_caso|evento."""
from __future__ import annotations

import re

from src.comun.base import clave_idempotencia, formato_soles

PLANTILLAS = {
    "devolucion_rechazada": "Hola {{nombre}}. Revisamos su solicitud {{id_caso}}: {{motivo_veredicto}} {{orientacion}}",
    "recojo_programado": "Hola {{nombre}}. Programamos el recojo {{id_recojo}} con {{courier}} para el {{fecha}}, entre {{ventana}}.",
    "comprobante_reembolso": "Hola {{nombre}}. Procesamos su reembolso {{id_reembolso}} por {{monto}} a su medio de pago {{medio}} (nota de crédito {{nota_credito}}). La acreditación suele tomar {{plazo_estimado}}, según su banco.",
    "caso_en_revision": "Hola {{nombre}}. Su solicitud {{id_caso}} pasó a nuestro equipo de soporte. Le responderemos en {{plazo_respuesta}}.",
}
_ENVIADOS: set[str] = set()


def renderizar(evento: str, datos: dict) -> str:
    plantilla = PLANTILLAS[evento]
    faltantes = [v for v in re.findall(r"{{(\w+)}}", plantilla) if datos.get(v) in (None, "")]
    if faltantes:
        raise ValueError(f"ErrorDeDatos: faltan {faltantes} para {evento}")
    datos = {k: (formato_soles(v) if k == "monto" else v) for k, v in datos.items()}
    return re.sub(r"{{(\w+)}}", lambda m: str(datos[m.group(1)]), plantilla)


def notificar(id_caso: str, evento: str, datos: dict) -> dict:
    clave = clave_idempotencia(id_caso, evento)
    if clave in _ENVIADOS:
        return {"estado": "omitido", "motivo": "evento ya notificado"}
    texto = renderizar(evento, {"nombre": "<NOMBRE_1>", **datos})
    # Aquí: enviar por WhatsApp (plantilla aprobada); si falla, por correo. Desenmascarar solo
    # el nombre y contacto del destinatario con el mapa PII de A0.
    _ENVIADOS.add(clave)
    return {"estado": "entregado", "canal": "whatsapp", "texto": texto}
