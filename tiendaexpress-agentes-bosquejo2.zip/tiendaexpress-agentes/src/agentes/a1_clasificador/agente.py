"""A1 Clasificador: usa la cadena LCEL `src/cadenas/clasificacion.py` y estima p por autoconsistencia."""
from __future__ import annotations

from collections import Counter

from src import simulado
from src.cadenas.clasificacion import cadena_clasificacion
from src.decision.confianza import calibrar

MUESTRAS = 5   # N de autoconsistencia; súbanlo si la calibración lo pide


def clasificar(texto_enmascarado: str, historial: list[str] | None = None) -> dict:
    """Devuelve {dominio, intencion, requiere, p, motivo}."""
    entrada = {"texto": texto_enmascarado, "historial": historial or []}
    muestras = cadena_clasificacion().batch([entrada] * MUESTRAS)   # LCEL: N muestras en paralelo
    votos = Counter((m.dominio, m.intencion) for m in muestras)
    (dominio, intencion), cuenta = votos.most_common(1)[0]
    ganadoras = [m for m in muestras if (m.dominio, m.intencion) == (dominio, intencion)]
    requiere = sorted({r for m in ganadoras for r in m.requiere})   # no omitir ramas (A1 §5)
    p = simulado.clasificar(texto_enmascarado)["p"] if simulado.activo() else calibrar(cuenta / MUESTRAS)
    return {"dominio": dominio, "intencion": intencion, "requiere": requiere, "p": p,
            "motivo": ganadoras[0].motivo}
