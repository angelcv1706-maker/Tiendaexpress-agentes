# AGENTS.md · A1 Clasificador de intención

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §6, §9.1. Carril BPMN: **Agente Orquestador** · tarea «Clasificar intención» (D1) y el enrutamiento inicial (D2).

## 1. Propósito
Decide **a qué dominio pertenece** cada mensaje y con qué confianza, por medio de `decide()` tipada y calibrada. Su salida alimenta la compuerta «¿Resoluble por agentes?» y la compuerta HITL.
- **Fuera de alcance:** responder al cliente o ejecutar herramientas de negocio.

## 2. Arquitectura
**Salida tipada:**
```
{ dominio: "preventa" | "devolucion" | "fuera_de_alcance",
  intencion: "info_producto" | "precio" | "envio" | "demo" | "compra" | "devolucion" | "compleja",
  requiere: ["producto","precio","envio"],   // ramas de la compuerta inclusiva (D1)
  p: 0.00–1.00, motivo: str }
```
**Rutina:**
1. Leer el texto enmascarado y el historial corto del hilo.
2. Clasificar. Es «compleja» si hay compra por volumen (más de 5 unidades), es empresa o RUC, hay un reclamo o se mezclan D1 y D2.
3. Llenar `requiere` con **todas** las necesidades detectadas, no solo la principal.
4. Devolver `p` calibrada: ≥ 0,80 → automático; entre 0,50 y 0,80 → revisión; < 0,50 → escala.

**Ejemplos guía:**
- «¿Cuánto cuesta y en cuánto llega a Trujillo?» → preventa, `requiere=[precio, envio]`.
- «Me llegó roto el ventilador» → devolucion.
- «Necesito 20 laptops para mi empresa» → compleja.
- «Quiero poner un reclamo formal» → fuera_de_alcance (Libro de Reclamaciones).

## 3. Convenciones
- Las etiquetas son cerradas: solo las listadas. Una categoría nueva requiere acuerdo del equipo y un cambio en el BPMN.
- Cada decisión humana sobre una clasificación se guarda como etiqueta (`etiquetas_calibracion`).

## 4. Comandos
```
pytest tests/agentes/test_a1_clasificador.py -q    # conjunto dorado de 40 mensajes etiquetados
```

## 5. Restricciones
- **No forzar una etiqueta** cuando nada encaja; usar `compleja` o `fuera_de_alcance`. Previene enrutar mal en silencio.
- **No devolver `p` fija ni redondeada a 1,0.** Previene anular la compuerta HITL.
- **No omitir ramas en `requiere`.** Previene respuestas incompletas (precio sin envío).
- **No usar el nombre ni los datos del cliente para clasificar.** Previene sesgos y uso indebido de PII.
- **No cambiar umbrales en el prompt;** viven en `src/decision/`. Previene umbrales distintos entre entornos.
