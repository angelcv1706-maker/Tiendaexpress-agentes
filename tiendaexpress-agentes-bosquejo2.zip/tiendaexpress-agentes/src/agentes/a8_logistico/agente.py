"""A8 Logístico: sin LLM. Recojo y webhook firmado del almacén."""
from __future__ import annotations

import hashlib
import hmac
import os

from src.comun.base import ErrorManual
from src.mcp_servers.cliente import llamar

SECRETO_WEBHOOK = os.getenv("WEBHOOK_ALMACEN_SECRETO", "solo-para-desarrollo")
_WEBHOOKS_PROCESADOS: set[str] = set()


def firmar(cuerpo: str) -> str:
    return hmac.new(SECRETO_WEBHOOK.encode(), cuerpo.encode(), hashlib.sha256).hexdigest()


async def programar_recojo(id_caso: str, pedido: str, veredicto: str, trace_id: str = "-") -> dict:
    if veredicto != "aprobado":
        raise ErrorManual("No se programa recojo sin veredicto aprobado")
    datos = await llamar("a8", "pagos_erp", "buscar_pedido", trace_id=trace_id, pedido=pedido)
    env = await llamar("a8", "courier", "cotizar_envio", trace_id=trace_id,
                       distrito=datos["distrito"], peso_kg="1")
    if not env["opciones"]:
        raise ErrorManual(f"Sin cobertura de courier en {datos['distrito']}: pasa a Soporte")
    courier = min(env["opciones"], key=lambda o: o["plazo_h"])["courier"]   # menor plazo
    rcj = await llamar("a8", "courier", "programar_recojo", trace_id=trace_id, id_caso=id_caso,
                       distrito=datos["distrito"], direccion=datos["direccion"],
                       courier=courier, ventana="09:00–13:00")
    await llamar("a8", "pagos_erp", "actualizar_estado_caso", trace_id=trace_id,
                 id_caso=id_caso, estado="RECOJO_PROGRAMADO")
    return rcj


async def procesar_webhook(id_caso: str, id_recojo: str, coincide: bool, detalle: str,
                           cuerpo: str, firma: str, trace_id: str = "-") -> dict:
    """Devuelve {'estado': 'PRODUCTO_RECIBIDO' | 'REEVALUACION' | 'IGNORADO'}."""
    if not hmac.compare_digest(firmar(cuerpo), firma):
        raise PermissionError("Webhook sin firma válida")
    if id_recojo in _WEBHOOKS_PROCESADOS:
        return {"estado": "IGNORADO", "motivo": "webhook repetido"}
    _WEBHOOKS_PROCESADOS.add(id_recojo)
    estado = "PRODUCTO_RECIBIDO" if coincide else "REEVALUACION"
    await llamar("a8", "pagos_erp", "actualizar_estado_caso", trace_id=trace_id,
                 id_caso=id_caso, estado=estado, detalle=detalle)
    return {"estado": estado, "detalle": detalle}
