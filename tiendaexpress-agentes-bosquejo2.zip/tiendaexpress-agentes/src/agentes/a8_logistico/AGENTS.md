# AGENTS.md · A8 Logístico

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §5.3, §9.4. Carril BPMN: **Agente Logístico**, tareas «Programar recojo del paquete», «Invocar API Courier» y «Actualizar estado a Producto Recibido» (al recibir el webhook) (D2).

## 1. Propósito
Coordina el **retorno físico** del producto: programa el recojo con Scharff u Olva y, cuando el almacén confirma la recepción, actualiza el caso a `PRODUCTO_RECIBIDO` o lo marca para reevaluación.
- **Fuera de alcance:** despachos de venta, elegir o negociar couriers, y cotizar envíos de pre-venta (A3).

## 2. Arquitectura
**Rutina A · Programar recojo** (solo con veredicto `aprobado`):
1. Obtener la dirección y el distrito de `buscar_pedido` (nunca del texto del cliente sin verificar).
2. Elegir el courier según la cobertura del distrito (respuesta de la API); si ambos cubren, el de menor plazo.
3. `programar_recojo(id_caso, direccion, ventana)` con `clave = HASH(id_caso)`.
4. Estado → `RECOJO_PROGRAMADO`; entregar a A9 `{RCJ-id, fecha, ventana}`.

**Rutina B · Webhook «recepción OK» del almacén:**
1. Validar que el webhook corresponda a un `RCJ-id` existente y venga firmado.
2. Si el estado es OK y coincide con lo declarado → `actualizar_estado_caso(id_caso, "PRODUCTO_RECIBIDO")`.
3. Si no coincide → `actualizar_estado_caso(id_caso, "REEVALUACION", detalle)` y aviso al orquestador.

**Errores:** timeout de la API → 4 intentos con 2 s de espera, luego `cola_fallidos`. Sin cobertura en el distrito → `ErrorManual` a Soporte.

| Herramienta | Uso | Modo |
|---|---|---|
| MCP Courier `programar_recojo`, `consultar_estado_envio` | Recojo | Escritura / lectura |
| MCP Pagos y ERP `buscar_pedido`, `actualizar_estado_caso` | Dirección y estado | Lectura / escritura |

## 3. Convenciones
- ID `RCJ-######`; ventanas de recojo de 4 h («mañana 09:00–13:00»).
- El webhook se procesa de forma idempotente por `RCJ-id`; los repetidos se ignoran.

## 4. Comandos
```
pytest tests/agentes/test_a8_logistico.py -q   # webhook repetido, webhook sin firma, paquete que no coincide
```

## 5. Restricciones
- **No programar el recojo sin veredicto `aprobado`.** Previene costos de courier por casos rechazados.
- **No usar una dirección distinta a la del pedido** sin verificación humana. Previene recojos en direcciones fraudulentas.
- **No marcar `PRODUCTO_RECIBIDO` sin webhook firmado del almacén.** Previene liberar reembolsos sin recepción real.
- **No programar dos recojos para el mismo caso.** Previene cobros dobles del courier.
- **No llamar a A7 directamente;** se informa al orquestador. Previene saltarse la compuerta de reevaluación.
