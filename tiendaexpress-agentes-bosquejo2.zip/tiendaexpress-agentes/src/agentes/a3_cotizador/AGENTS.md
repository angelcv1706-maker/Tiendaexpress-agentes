# AGENTS.md · A3 Cotizador

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §4.1–§4.3, §9.1, §9.3. Carriles BPMN: **Agente Comercial** y la cotización de envío del carril **Agente Logístico** (D1).

## 1. Propósito
Calcula el **total a pagar**: precio, promociones, cuotas y envío. Emite la cotización y, cuando el cliente confirma, registra el **pre-pedido**.
- Tareas BPMN: «Calcular precio, promociones y cuotas», «Cotizar envío y plazo con API courier» y «Registrar pre-pedido en ERP».
- **Fuera de alcance:** cobrar, reservar stock, despachar y cotizaciones corporativas.

## 2. Arquitectura
**Rutina:**
1. `obtener_precio(sku)` → precio de lista con IGV.
2. `listar_promociones(sku)` → aplicar solo las vigentes hoy. Descuento ≤ 10 % → automático; **> 10 % → HITL** (Coordinador Comercial).
3. Si el cliente pide cuotas → `calcular_cuotas(monto, medio)`.
4. Si se requiere envío → `cotizar_envio(ubigeo, peso)` en MCP Courier. Envío gratis si el total es ≥ S/ 299 y el destino está en Lima Metropolitana.
5. `crear_cotizacion(...)` con `clave = HASH(id_cliente|sku|cantidad|codigo_promo)`. Vigencia: 72 h.
6. Ante «Intención de compra recibida» → `crear_prepedido(id_cotizacion)` solo si la cotización está `VIGENTE`; si venció, se recotiza.

**Cálculo (en código, `src/agentes/a3_cotizador/calculo.py`):**
```
subtotal = precio_lista × cantidad × (1 − descuento)
total    = subtotal + envio                 # IGV ya incluido; redondeo HALF_UP a 2 decimales
```
| Herramienta | Uso | Modo |
|---|---|---|
| MCP Cotizaciones `obtener_precio`, `listar_promociones`, `calcular_cuotas`, `crear_cotizacion`, `obtener_cotizacion` | Precio y cotización | Lectura / escritura |
| MCP Courier `cotizar_envio` | Costo y plazo de envío | **Solo lectura** |
| MCP Pagos y ERP `crear_prepedido` | Pre-pedido | Escritura (única escritura de D1 en el ERP) |

## 3. Convenciones
- Montos en `Decimal`; nunca `float`. Se muestran como «S/ 1 299,00».
- La cotización siempre muestra su vencimiento: «Válida hasta el 20/10/2026 18:00».

## 4. Comandos
```
pytest tests/agentes/test_a3_cotizador.py -q
# Prueba de mutación sugerida: quitar el tope del 10 % en calculo.py → test_descuento_mayor_10_va_a_hitl DEBE fallar
```

## 5. Restricciones
- **No calcular montos con el LLM;** solo con `calculo.py`. Previene errores aritméticos plausibles.
- **No aplicar descuentos de más del 10 % ni promociones vencidas sin HITL.** Previene pérdida de margen.
- **No usar `programar_recojo` ni otras escrituras del courier.** Previene envíos o recojos fantasma (son de A8).
- **No crear un pre-pedido sobre una cotización vencida** o sin confirmación explícita del cliente. Previene pedidos no deseados.
- **No prometer plazos de entrega** distintos a los que devuelve la API. Previene reclamos por incumplimiento.
- **No ofrecer cuotas «sin intereses»** si la promoción no lo dice. Previene publicidad engañosa.
