"""A3 Cotizador: el LLM solo extrae datos del mensaje; todo lo demás es MCP + calculo.py."""

from __future__ import annotations

from decimal import Decimal

from src.agentes.a3_cotizador.calculo import cotizar, elegir_descuento
from src.comun.base import formato_soles
from src.cadenas.extraccion import DatosCotizacion, cadena_extraccion
from src.conocimiento import resolver_sku
from src.datos.simulados import PRODUCTOS
from src.mcp_servers.cliente import llamar


async def extraer(texto: str) -> DatosCotizacion:
    return await cadena_extraccion().ainvoke({"texto": texto})  # LCEL


async def calcular(
    texto: str,
    requiere: list[str],
    sku: str | None = None,
    id_cliente: str = "CLI-00001",
    trace_id: str = "-",
) -> dict:
    datos = await extraer(texto)
    sku = sku or next(iter(resolver_sku(datos.producto_mencionado or texto)), None)
    if not sku:
        return {
            "necesita_aclaracion": True,
            "detalle": "No identifiqué el producto a cotizar.",
        }

    precio = await llamar(
        "a3", "cotizaciones", "obtener_precio", trace_id=trace_id, sku=sku
    )
    promos = await llamar(
        "a3", "cotizaciones", "listar_promociones", trace_id=trace_id, sku=sku
    )
    descuento, codigo = elegir_descuento(promos)

    costo_envio, lima, plazo = None, False, None
    if "envio" in requiere and datos.distrito:
        env = await llamar(
            "a3",
            "courier",
            "cotizar_envio",
            trace_id=trace_id,
            distrito=datos.distrito,
            peso_kg=str(PRODUCTOS[sku]["peso_kg"]),
        )
        lima = env["lima_metropolitana"]
        if env["opciones"]:
            mejor = min(env["opciones"], key=lambda o: Decimal(o["costo"]))
            costo_envio, plazo = Decimal(mejor["costo"]), mejor["plazo_h"]

    cot = cotizar(
        Decimal(precio["precio_lista"]),
        datos.cantidad,
        descuento,
        costo_envio,
        lima,
        pide_rebaja=datos.pide_rebaja,
        codigo_promo=codigo,
    )
    cuotas = None
    if datos.pide_cuotas and promos:
        p = next(x for x in promos if x["codigo"] == codigo)
        cuotas = (
            await llamar(
                "a3",
                "cotizaciones",
                "calcular_cuotas",
                trace_id=trace_id,
                monto=str(cot["total"]),
                cuotas_max=p["cuotas_max"],
                sin_intereses=p["sin_intereses"],
            )
        )["texto"]
    return {
        "sku": sku,
        **cot,
        "plazo_envio_h": plazo,
        "cuotas": cuotas,
        "sin_cobertura_envio": "envio" in requiere
        and datos.distrito
        and costo_envio is None,
        "total_texto": formato_soles(cot["total"]),
        "p": 0.9,
    }


async def emitir_cotizacion(cot: dict, id_cliente: str, trace_id: str = "-") -> dict:
    """Se llama solo después de pasar la compuerta HITL de descuento, si aplicaba."""
    return await llamar(
        "a3",
        "cotizaciones",
        "crear_cotizacion",
        trace_id=trace_id,
        id_cliente=id_cliente,
        sku=cot["sku"],
        cantidad=cot["cantidad"],
        precio_unitario=str(cot["precio_unitario"]),
        descuento=str(cot["descuento"]),
        subtotal=str(cot["subtotal"]),
        envio=str(cot["envio"]),
        total=str(cot["total"]),
        codigo_promo=cot["codigo_promo"],
    )


async def registrar_prepedido(id_cotizacion: str, trace_id: str = "-") -> dict:
    cot = await llamar(
        "a3",
        "cotizaciones",
        "obtener_cotizacion",
        trace_id=trace_id,
        id_cotizacion=id_cotizacion,
    )
    if cot["estado"] != "VIGENTE":
        return {"recotizar": True, "estado": cot["estado"]}
    return await llamar(
        "a3",
        "pagos_erp",
        "crear_prepedido",
        trace_id=trace_id,
        id_cotizacion=id_cotizacion,
    )
