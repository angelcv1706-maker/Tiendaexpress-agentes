"""Cálculo de A3 en código (A3 §5: nunca con el LLM).

subtotal = precio_lista × cantidad × (1 − descuento)
total    = subtotal + envío          # IGV ya incluido; HALF_UP a 2 decimales

Supuesto del bosquejo: el umbral de envío gratis (S/ 299) se compara con el SUBTOTAL, porque
compararlo con el total que ya incluye el envío es circular. Confírmenlo con el validador del caso.
"""
from __future__ import annotations

from decimal import Decimal

from src.comun.base import ErrorManual, soles
from src.decision import DESCUENTO_MAX_AUTO, ENVIO_GRATIS_DESDE, descuento_requiere_hitl

MAX_UNIDADES = 5   # más de 5 del mismo SKU → asesor (contexto §4.2)


def elegir_descuento(promos_vigentes: list[dict]) -> tuple[Decimal, str]:
    """La mejor promoción VIGENTE (el MCP ya filtra por fecha). Sin promo → 0."""
    if not promos_vigentes:
        return Decimal("0"), ""
    mejor = max(promos_vigentes, key=lambda p: Decimal(p["descuento"]))
    return Decimal(mejor["descuento"]), mejor["codigo"]


def cotizar(precio_lista: Decimal, cantidad: int, descuento: Decimal,
            costo_envio: Decimal | None, lima_metropolitana: bool,
            pide_rebaja: bool = False, codigo_promo: str = "") -> dict:
    if cantidad < 1:
        raise ValueError("cantidad inválida")
    if cantidad > MAX_UNIDADES:
        raise ErrorManual("compra por volumen: pasa a asesor")
    subtotal = soles(precio_lista * cantidad * (1 - descuento))
    envio = soles(0) if costo_envio is None else soles(costo_envio)
    envio_gratis = lima_metropolitana and subtotal >= ENVIO_GRATIS_DESDE
    if envio_gratis:
        envio = soles(0)
    return {
        "precio_unitario": soles(precio_lista),
        "cantidad": cantidad,
        "descuento": descuento,
        "codigo_promo": codigo_promo,
        "subtotal": subtotal,
        "envio": envio,
        "envio_gratis": envio_gratis,
        "total": soles(subtotal + envio),
        "requiere_hitl": pide_rebaja or descuento_requiere_hitl(descuento, bool(codigo_promo)),
        "descuento_max_auto": DESCUENTO_MAX_AUTO,
    }
