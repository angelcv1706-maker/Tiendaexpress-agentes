"""A4 Agendador: reglas de agenda en código; el cliente elige el horario (nunca se reserva solo)."""
from __future__ import annotations

from datetime import datetime, timedelta

from src.comun.base import LIMA, ahora
from src.datos import simulados as db
from src.decision import LEAD_CALIFICADO
from src.mcp_servers.cliente import llamar

DURACION = timedelta(minutes=30)
ANTICIPACION_MIN = timedelta(hours=2)
HORIZONTE = timedelta(days=14)


def horario_valido(inicio: datetime, referencia: datetime | None = None) -> bool:
    """Lun–sáb, 10:00–18:00 (la demo termina a más tardar 18:00), ≥ 2 h y ≤ 14 días."""
    ref = referencia or ahora()
    inicio = inicio.astimezone(LIMA)
    fin = inicio + DURACION
    return (inicio.weekday() < 6
            and inicio.hour >= 10
            and (fin.hour < 18 or (fin.hour == 18 and fin.minute == 0))
            and inicio - ref >= ANTICIPACION_MIN
            and inicio - ref <= HORIZONTE)


def formato_horario(iso: str) -> str:
    dias = ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"]
    d = datetime.fromisoformat(iso).astimezone(LIMA)
    return f"{dias[d.weekday()]} {d:%d/%m}, {d:%H:%M}"


async def ofrecer_horarios(lead_id: str, lead_score: int, trace_id: str = "-") -> dict:
    if lead_score < LEAD_CALIFICADO:
        return {"permitido": False, "motivo": "lead no calificado (score < 60)"}
    activa = next((c for c, d in db.DEMOS.items() if d["lead_id"] == lead_id and d["estado"] == "RESERVADA"), None)
    if activa:
        return {"permitido": False, "motivo": "ya tiene una demo activa", "id_cita": activa}
    desde = ahora() + ANTICIPACION_MIN
    libres = await llamar("a4", "citas", "consultar_disponibilidad", trace_id=trace_id,
                          desde=desde.isoformat(), hasta=(ahora() + HORIZONTE).isoformat())
    validos = [h for h in libres if horario_valido(datetime.fromisoformat(h))][:3]
    return {"permitido": True, "horarios": validos, "texto": [formato_horario(h) for h in validos]}


async def reservar(lead_id: str, sku: str, inicio_elegido: str, trace_id: str = "-") -> dict:
    if not horario_valido(datetime.fromisoformat(inicio_elegido)):
        return {"reservado": False, "motivo": "horario fuera de reglas"}
    cita = await llamar("a4", "citas", "reservar_demo", trace_id=trace_id,
                        lead_id=lead_id, sku=sku, inicio=inicio_elegido)
    return {"reservado": True, **cita, "texto": formato_horario(inicio_elegido)}
