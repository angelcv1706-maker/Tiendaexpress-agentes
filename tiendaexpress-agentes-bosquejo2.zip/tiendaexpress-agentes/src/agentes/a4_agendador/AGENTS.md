# AGENTS.md · A4 Agendador

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §4.4, §9.3. Carril BPMN: **pendiente de modelar** en el TO-BE de pre-venta (ver contexto §13.1). Tarea propuesta: «Agendar demo» después de «¿Lead calificado?».

## 1. Propósito
Reserva, reprograma o cancela **demos virtuales de producto** (30 min con un asesor) para leads calificados.
- **Fuera de alcance:** visitas a domicilio, instalación, soporte técnico y citas de garantía.

## 2. Arquitectura
**Rutina:**
1. Verificar con A5 que `lead_score ≥ 60` (lo entrega el orquestador; A4 no lo recalcula).
2. Verificar que el lead no tenga otra demo `RESERVADA`. Si la tiene, ofrecer reprogramarla.
3. `consultar_disponibilidad(desde, hasta)` dentro de las reglas: lun–sáb de 10:00 a 18:00, al menos 2 h de anticipación y hasta 14 días adelante.
4. Ofrecer **hasta 3 horarios**. El cliente elige; no se reserva sin elección explícita.
5. `reservar_demo(lead_id, sku, inicio)` con `clave = HASH(lead_id|sku|inicio)`.
6. Devolver la confirmación; el orquestador la envía por A0, y A5 actualiza el lead a `DEMO_AGENDADA`.

| Herramienta | Uso | Modo |
|---|---|---|
| MCP Citas `consultar_disponibilidad`, `reservar_demo`, `reprogramar_demo`, `cancelar_demo` | Agenda de asesores | Lectura / escritura |

## 3. Convenciones
- Horarios en America/Lima, mostrados como «mar 20/10, 15:30».
- Identificador `CITA-#####`. Estados: RESERVADA, REALIZADA, CANCELADA, NO_ASISTIÓ.

## 4. Comandos
```
pytest tests/agentes/test_a4_agendador.py -q   # casos límite: 18:00 exacto, domingo, anticipación de 1 h 59 min
```

## 5. Restricciones
- **No reservar fuera del horario ni con menos de 2 h de anticipación.** Previene demos que ningún asesor puede atender.
- **No reservar sin que el cliente elija el horario.** Previene citas no consentidas y ausencias.
- **No agendar a leads con score < 60** salvo instrucción HITL. Previene saturar la agenda de asesores.
- **No permitir dos demos activas para el mismo lead.** Previene duplicados y horas perdidas.
- **No compartir el nombre ni el contacto del asesor** fuera del enlace de la cita. Previene exponer datos del personal.
