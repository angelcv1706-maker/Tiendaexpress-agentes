"""A0 Recepción: única puerta de entrada y salida con el cliente (AGENTS.md de A0).

El enmascarado con expresiones regulares es un punto de partida. Los nombres propios y las
direcciones libres se escapan fácilmente: para producción evalúen Microsoft Presidio o un
modelo NER en español, y prueben con mensajes reales anonimizados.
"""
from __future__ import annotations

import re

from src.comun.base import clave_idempotencia, nuevo_id

LIMITE_CARACTERES = 2000

# Orden importa: tarjeta (13-19 dígitos) antes que RUC (11) y DNI (8).
PATRONES = [
    ("TARJETA", re.compile(r"\b(?:\d[ -]?){13,19}\b")),
    ("CORREO", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
    ("RUC", re.compile(r"\b(?:10|15|17|20)\d{9}\b")),
    ("TEL", re.compile(r"(?:\+?51[ -]?)?\b9\d{2}[ -]?\d{3}[ -]?\d{3}\b")),
    ("DNI", re.compile(r"\b\d{8}\b")),
    ("DIRECCION", re.compile(r"\b(?:Av\.?|Avenida|Jr\.?|Jir[oó]n|Calle|Psje\.?|Pasaje|Mz\.?)\s+[^,.\n]{3,60}", re.I)),
    ("NOMBRE", re.compile(r"(?<=\bme llamo )[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?: [A-ZÁÉÍÓÚÑ][a-záéíóúñ]+){0,3}")),
]

# Tabla de correspondencia: en producción es la tabla `pii_mapa` en la BD, nunca el estado del grafo.
PII_MAPA: dict[str, dict[str, str]] = {}
_VISTOS: dict[str, str] = {}   # clave del mensaje del canal → id_consulta


def enmascarar(texto: str, id_consulta: str) -> tuple[str, bool]:
    """Devuelve (texto_enmascarado, habia_tarjeta)."""
    mapa = PII_MAPA.setdefault(id_consulta, {})
    habia_tarjeta = False
    for tipo, patron in PATRONES:
        def _reemplazo(m, tipo=tipo):
            nonlocal habia_tarjeta
            if tipo == "TARJETA":
                habia_tarjeta = True
                return "<TARJETA>"          # ni siquiera se guarda en el mapa
            n = sum(1 for k in mapa if k.startswith(f"<{tipo}_")) + 1
            marcador = f"<{tipo}_{n}>"
            mapa[marcador] = m.group(0)
            return marcador
        texto = patron.sub(_reemplazo, texto)
    return texto, habia_tarjeta


def recibir(canal: str, id_mensaje_canal: str, texto: str, adjuntos: list[str] | None = None,
            cliente_ref: str = "CLI-00001") -> dict:
    """Rutina de entrada. Devuelve lo que el orquestador necesita, ya enmascarado."""
    clave = clave_idempotencia(canal, id_mensaje_canal)
    if clave in _VISTOS:
        return {"duplicado": True, "id_consulta": _VISTOS[clave]}
    id_consulta = nuevo_id("CON")
    _VISTOS[clave] = id_consulta
    texto = " ".join(texto.split())
    truncado = len(texto) > LIMITE_CARACTERES
    texto = texto[:LIMITE_CARACTERES]
    enmascarado, habia_tarjeta = enmascarar(texto, id_consulta)
    return {"duplicado": False, "id_consulta": id_consulta, "canal": canal,
            "texto_enmascarado": enmascarado, "adjuntos": adjuntos or [],
            "cliente_ref": cliente_ref, "truncado": truncado, "aviso_tarjeta": habia_tarjeta}


def desenmascarar_propios(texto: str, id_consulta: str, tipos_permitidos=("NOMBRE",)) -> str:
    """Rutina de salida: solo se restauran los datos del propio cliente (por defecto, su nombre)."""
    for marcador, valor in PII_MAPA.get(id_consulta, {}).items():
        if any(marcador.startswith(f"<{t}_") for t in tipos_permitidos):
            texto = texto.replace(marcador, valor)
    return texto
