# AGENTS.md · A0 Recepción

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §2, §9.2, §9.3. Carril BPMN: **Agente de Atención al Cliente** (D1 y D2).

## 1. Propósito
Es la única puerta de entrada y salida conversacional con el cliente (portal web y WhatsApp).
- **Entrada:** recibe el mensaje, lo normaliza, **enmascara la PII**, descarta duplicados y registra la interacción.
- **Salida:** entrega al cliente la respuesta que consolida el orquestador.
- Tareas BPMN: «Consulta recibida», «Registrar consulta en historial», «Enviar respuesta al cliente», «Intención de compra recibida» (D1) y «Recibir solicitud por Portal Web / WhatsApp» (D2).
- **Fuera de alcance:** clasificar la intención (A1), responder sobre productos (A2) y las notificaciones transaccionales de D2 (A9).

## 2. Arquitectura
**Rutina de entrada:**
1. Calcular `clave = HASH(canal|id_mensaje_del_canal)`. Si ya existe → responder con el estado actual del hilo y no crear otro.
2. Normalizar: recortar, unificar el canal y adjuntar URLs de imágenes (fotos de devolución).
3. Enmascarar PII: nombre, DNI/RUC, teléfono, correo y dirección → `<TIPO_n>`. Guardar el mapa en `pii_mapa` (BD), nunca en el estado del LLM.
4. Registrar con MCP CRM `registrar_interaccion` y vincular o crear el cliente con `buscar_cliente`.
5. Entregar al orquestador `{id_consulta, canal, texto_enmascarado, adjuntos, cliente_ref}`.

**Rutina de salida:** recibe el texto final, **desenmascara solo los datos del propio cliente** y lo envía por el mismo canal de entrada.

| Herramienta | Uso | Modo |
|---|---|---|
| MCP CRM `buscar_cliente`, `registrar_interaccion` | Historial de consultas | Lectura / escritura |
| Conector de canal (WhatsApp Business, chat web) | Recibir y responder | Entrada / salida |

## 3. Convenciones
- `id_consulta` con formato `CON-AAAAMMDD-####`; `id_caso` con formato `SOL-#####` cuando el orquestador lo abre.
- Un mensaje de más de 2 000 caracteres se trunca y se marca `truncado=true`.
- Tono de salida: español peruano neutro, «usted» y como máximo 3 párrafos cortos.

## 4. Comandos
```
pytest tests/agentes/test_a0_recepcion.py -q    # incluye pruebas de enmascaramiento y duplicados
```

## 5. Restricciones
- **No enviar texto sin enmascarar al orquestador, a otros agentes ni a los logs.** Previene fugas de PII (Ley 29733).
- **No desenmascarar datos de un tercero** mencionado en el mensaje. Previene revelar datos de otra persona.
- **No responder contenido de negocio por cuenta propia** (precios, stock, plazos). Previene respuestas sin fuente.
- **No crear una consulta nueva ante un reintento del canal.** Previene hilos y respuestas duplicadas.
- **No usar plantillas de WhatsApp para conversación libre** (eso es de A9). Previene rechazos de Meta y bloqueo del número.
- **No guardar números de tarjeta** si el cliente los escribe: se enmascaran como `<TARJETA>` y se avisa que no los comparta. Previene incumplimientos de seguridad de pagos.
