"""Lead score en código (contexto §4.4). El LLM no suma puntos: solo se detectan señales."""
from __future__ import annotations

from decimal import Decimal

PUNTOS = {
    "intencion": 30,      # intención de compra explícita
    "stock": 15,          # producto consultado con stock
    "monto": 15,          # monto cotizado ≥ S/ 1 000
    "presupuesto": 15,    # presupuesto o fecha de compra declarados
    "recurrencia": 10,    # segunda interacción o más en 7 días
    "demo": 15,           # pidió demo o hablar con un asesor
}
MONTO_ALTO = Decimal("1000.00")


def detectar_senales(intencion: str | None, stock: int | None, monto_cotizado: Decimal | None,
                     presupuesto_declarado: bool, interacciones_7d: int, pidio_demo: bool) -> set[str]:
    s = set()
    if intencion == "compra":
        s.add("intencion")
    if stock and stock > 0:
        s.add("stock")
    if monto_cotizado is not None and monto_cotizado >= MONTO_ALTO:
        s.add("monto")
    if presupuesto_declarado:
        s.add("presupuesto")
    if interacciones_7d >= 2:
        s.add("recurrencia")
    if pidio_demo or intencion == "demo":
        s.add("demo")
    return s


def calcular(senales_previas: dict[str, int], nuevas: set[str]) -> tuple[int, dict[str, int]]:
    """Une señales sin duplicar (una señal suma una sola vez por hilo). Tope 100."""
    desglose = dict(senales_previas)
    for s in nuevas:
        desglose.setdefault(s, PUNTOS[s])
    return min(sum(desglose.values()), 100), desglose
