"""A5 Calificador: mantiene el lead en el CRM."""
from __future__ import annotations

from src.agentes.a5_calificador.puntaje import calcular, detectar_senales
from src.decision import LEAD_CALIFICADO
from src.mcp_servers.cliente import llamar


async def actualizar(cliente_ref: str, senales: set[str], trace_id: str = "-") -> dict:
    lead = await llamar("a5", "crm", "upsert_lead", trace_id=trace_id, cliente_ref=cliente_ref)
    score, desglose = calcular(lead.get("senales", {}), senales)
    estado = lead["estado"]
    if score >= LEAD_CALIFICADO and estado == "NUEVO":
        estado = "CALIFICADO"
    res = await llamar("a5", "crm", "actualizar_lead_score", trace_id=trace_id,
                       lead_id=lead["lead_id"], score=score, senales=desglose, estado=estado)
    return {"lead_id": lead["lead_id"], "score": score, "estado": res["estado"],
            "calificado": score >= LEAD_CALIFICADO}


async def cerrar_no_convertida(lead_id: str, trace_id: str = "-") -> dict:
    return await llamar("a5", "crm", "cerrar_lead", trace_id=trace_id,
                        lead_id=lead_id, motivo="sin_respuesta_24h")


__all__ = ["actualizar", "cerrar_no_convertida", "detectar_senales"]
