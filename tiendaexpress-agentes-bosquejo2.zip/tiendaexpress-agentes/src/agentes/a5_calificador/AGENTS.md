# AGENTS.md · A5 Calificador de leads

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §4.4, §10. Carril BPMN: **Agente Orquestador**, tareas «Consolidar respuesta y verificar datos» (actualización del lead) y «Registrar consulta como no convertida» (D1).

## 1. Propósito
Mantiene el **lead** de cada cliente en el CRM: calcula el lead score (0–100), lo marca como calificado (≥ 60) y cierra como no convertidas las consultas sin respuesta en 24 h.
- **Fuera de alcance:** contactar al cliente, enviar campañas de marketing o decidir descuentos.

## 2. Arquitectura
**Rutina tras cada respuesta:**
1. `upsert_lead(cliente_ref)` y lectura de las señales del hilo (intención, stock, monto cotizado, presupuesto, recurrencia, pedido de demo).
2. Calcular el score **en código** (`puntaje.py`) con la tabla del contexto §4.4. Tope: 100.
3. `actualizar_lead_score(lead_id, score, señales)`. Si es ≥ 60 → estado `CALIFICADO` y se avisa al orquestador (que puede ofrecer demo con A4).

**Rutina por temporizador de 24 h:** `cerrar_lead(lead_id, motivo="sin_respuesta_24h")`, la consulta pasa a `NO_CONVERTIDA` y el lead **no se borra**.

**Rutina de conversión:** cuando A3 registra el pre-pedido → el lead pasa a `CONVERTIDO`.

| Herramienta | Uso | Modo |
|---|---|---|
| MCP CRM `upsert_lead`, `actualizar_lead_score`, `cerrar_lead` | Ciclo de vida del lead | Escritura |

## 3. Convenciones
- Se guarda el **desglose** del score (`señales: {intencion:30, stock:15, …}`), no solo el total, para poder auditarlo.
- Estados: NUEVO, CALIFICADO, DEMO_AGENDADA, CONVERTIDO, PERDIDO.

## 4. Comandos
```
pytest tests/agentes/test_a5_calificador.py -q   # casos límite: score 59 vs 60; señales repetidas no suman dos veces
```

## 5. Restricciones
- **No calcular el score con el LLM;** solo detectar señales, y el puntaje lo suma el código. Previene scores incoherentes entre ejecuciones.
- **No usar datos sensibles** (edad, género, distrito como proxy socioeconómico) como señal. Previene discriminación.
- **No borrar leads ni consultas no convertidas.** Previene perder la historia comercial y la medición.
- **No sumar dos veces la misma señal en un hilo.** Previene inflar el score con mensajes repetidos.
- **No escribir en el ERP ni en la agenda.** Previene salirse de su responsabilidad (son de A3 y A4).
