# AGENTS.md · A2 Asesor RAG

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §3, §6. Carril BPMN: **Agente de Catálogo y Stock** (D1).

## 1. Propósito
Responde preguntas de producto con **fuente verificable**: ficha técnica, FAQ, compatibilidad, garantía del fabricante y stock en tiempo real. Propone alternativas cuando no hay stock.
- Tareas BPMN: «Consultar ficha técnica y stock en ERP» y «Proponer productos alternativos».
- **Fuera de alcance:** precios, descuentos y envío (A3), así como políticas de devolución aplicadas a un caso (A6).

## 2. Arquitectura
**Rutina:**
1. Identificar el SKU. Si es ambiguo, recuperar hasta 3 candidatos y devolver `necesita_aclaracion` con las opciones.
2. Recuperar de pgvector (`catalogo`, `faq`) los fragmentos con `similitud ≥ 0,75` (máximo 5).
3. Consultar `consultar_stock(sku)` en MCP Pagos y ERP **en cada consulta**, sin caché de más de 15 min.
4. Si `stock = 0`, buscar hasta 3 alternativas: misma categoría, precio de lista ±20 % y `stock > 0`.
5. Devolver la respuesta con citas.

**Salida:**
```
{ sku, nombre, atributos: {..}, stock: int, stock_leido_en: ISO8601,
  alternativas: [{sku, nombre, motivo}], fuentes: [{coleccion, doc_id}], p }
```
| Herramienta | Uso | Modo |
|---|---|---|
| RAG `catalogo`, `faq` | Ficha técnica y preguntas frecuentes | Lectura |
| MCP Pagos y ERP `consultar_stock` | Stock actual | Lectura |

**Decisión:** el stock se lee del ERP y no del índice RAG, porque el índice se actualiza por lotes y quedaría desfasado.

## 3. Convenciones
- Cada afirmación técnica lleva su `fuente`. Sin fuente, no se afirma.
- Las unidades van en el sistema métrico y con las del fabricante entre paréntesis si difieren (p. ej., pulgadas de pantalla).

## 4. Comandos
```
python -m src.conocimiento.ingestar --coleccion catalogo
pytest tests/agentes/test_a2_asesor_rag.py -q
```

## 5. Restricciones
- **No responder sin fragmento recuperado ni inventar especificaciones.** Previene alucinaciones sobre el producto.
- **No mencionar precios ni promociones.** Previene contradicciones con A3, la única fuente de precio.
- **No informar stock leído del índice RAG.** Previene vender lo que no hay.
- **No recomendar productos de otras tiendas ni comparar marcas con juicios de valor.** Previene problemas comerciales y de reputación.
- **No proponer alternativas sin stock** o fuera del rango de ±20 %. Previene una segunda frustración del cliente.
