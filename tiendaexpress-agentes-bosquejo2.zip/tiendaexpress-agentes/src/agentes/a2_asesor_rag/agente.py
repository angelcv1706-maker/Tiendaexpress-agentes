"""A2 Asesor RAG: cadena LCEL RAG (src/cadenas/rag.py) para el lenguaje; código para las garantías.

El stock y las alternativas se calculan en código, porque A2 §5 prohíbe informar stock sin
leerlo del ERP y proponer alternativas sin stock o fuera de ±20 %.
"""

from __future__ import annotations

from decimal import Decimal


from src.cadenas.rag import cadena_rag
from src.conocimiento import resolver_sku
from src.datos.simulados import PRODUCTOS
from src.mcp_servers.cliente import llamar


def alternativas(sku: str, maximo: int = 3) -> list[dict]:
    """Misma categoría, precio de lista ±20 % y stock > 0 (contexto §3)."""
    base = PRODUCTOS[sku]
    lo, hi = (
        base["precio_lista"] * Decimal("0.8"),
        base["precio_lista"] * Decimal("1.2"),
    )
    return [
        {
            "sku": s,
            "nombre": p["nombre"],
            "motivo": "misma categoría, precio similar y con stock",
        }
        for s, p in PRODUCTOS.items()
        if s != sku
        and p["categoria"] == base["categoria"]
        and p["stock"] > 0
        and lo <= p["precio_lista"] <= hi
    ][:maximo]


async def consultar(texto: str, trace_id: str = "-") -> dict:
    """Rutina completa de A2. Devuelve la salida del AGENTS.md de A2."""
    candidatos = resolver_sku(texto)
    if len(candidatos) != 1:
        return {
            "necesita_aclaracion": True,
            "opciones": [
                {"sku": s, "nombre": PRODUCTOS[s]["nombre"]} for s in candidatos
            ],
            "p": 0.4,
        }
    sku = candidatos[0]

    # Garantías en código: stock real y alternativas válidas
    stock = await llamar(
        "a2", "pagos_erp", "consultar_stock", trace_id=trace_id, sku=sku
    )
    alts = alternativas(sku) if stock["stock"] == 0 else []

    salida = await cadena_rag().ainvoke({"pregunta": texto, "sku": sku})  # LCEL
    return {
        "sku": sku,
        "nombre": PRODUCTOS[sku]["nombre"],
        "stock": stock["stock"],
        "stock_leido_en": stock["leido_en"],
        "alternativas": alts,
        "respuesta": salida.respuesta,
        "fuentes": salida.fuentes,
        "p": 0.9 if salida.fuentes else 0.5,
    }
