"""Modelos Claude por rol. Cambien los IDs por variables de entorno, no en el código.

Precios y IDs verificados el 29/10/2026 en platform.claude.com (pueden cambiar):
  claude-haiku-5-5   desde US$ 0,10 / 0,50 por millón de tokens (entrada / salida)
  claude-sonnet-5-5  US$ 2 / 10
"""
from __future__ import annotations

import os
from functools import lru_cache

from dotenv import load_dotenv
from langchain_anthropic import ChatAnthropic

load_dotenv()

MODELOS = {
    "clasificador": os.getenv("MODELO_CLASIFICADOR", "claude-haiku-5-5"),   # A1, muchas llamadas
    "extractor": os.getenv("MODELO_EXTRACTOR", "claude-haiku-5-5"),         # A3: SKU, cantidad, destino
    "asesor": os.getenv("MODELO_ASESOR", "claude-sonnet-5-5"),              # A2 (RAG) y redacción
    "validador": os.getenv("MODELO_VALIDADOR", "claude-sonnet-5-5"),        # A6: visión sobre fotos
}


@lru_cache
def modelo(rol: str, temperatura: float = 0.0):
    return ChatAnthropic(model=MODELOS[rol], temperature=temperatura, max_tokens=1024,
                         timeout=60, max_retries=2)
