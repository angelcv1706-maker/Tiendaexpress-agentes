"""Redacción de la respuesta consolidada (cadena LCEL en src/cadenas/redaccion.py)."""
from __future__ import annotations

from src.cadenas.redaccion import cadena_redaccion


def redactar(datos: dict) -> str:
    return cadena_redaccion().invoke(datos)
