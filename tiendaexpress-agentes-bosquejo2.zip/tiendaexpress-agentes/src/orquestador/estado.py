"""Estado del hilo y esquemas de las interrupciones (HITL y esperas)."""
from __future__ import annotations

import operator
from typing import Annotated, Literal, Optional, TypedDict

from pydantic import BaseModel


def fusionar(a: dict | None, b: dict | None) -> dict:
    """Reductor para ramas paralelas: A2 y A3 escriben claves distintas del mismo dict."""
    return {**(a or {}), **(b or {})}


class Estado(TypedDict, total=False):
    # entrada (lo que llega del canal; A0 la enmascara)
    entrada: dict
    trace_id: str
    id_consulta: str
    canal: str
    cliente_ref: str
    texto: str                     # SIEMPRE enmascarado
    adjuntos: list[str]
    historial: Annotated[list[str], operator.add]
    # A1
    dominio: str
    intencion: str
    requiere: list[str]
    p: float
    revisado_por_humano: bool
    # D1
    resultados_parciales: Annotated[dict, fusionar]
    lead_id: str
    lead_score: int
    lead_calificado: bool
    horarios_ofrecidos: list[str]
    respuesta: str
    cerrar: bool
    estado: str                    # estado de la consulta (contexto §10)
    # D2
    id_caso: str
    pedido: str
    veredicto: str
    motivo_veredicto: str
    motivo_categoria: str
    reevaluacion: str
    id_recojo: str
    estado_caso: str
    reembolso: dict
    notificaciones: Annotated[list[dict], operator.add]


# ----------------------------------------------------- respuestas válidas al reanudar
class RevisionClasificacion(BaseModel):
    aprobar: bool
    dominio: Optional[Literal["preventa", "devolucion", "fuera_de_alcance"]] = None
    intencion: Optional[str] = None
    requiere: list[str] = []


class RespuestaAsesor(BaseModel):
    respuesta: str


class AprobacionDescuento(BaseModel):
    aprobado: bool
    comentario: str = ""


class DecisionSoporte(BaseModel):
    veredicto: Literal["aprobado", "rechazado"]
    motivo_veredicto: str


class EventoCliente(BaseModel):
    evento: Literal["mensaje", "sin_respuesta_24h"]
    texto: str = ""
    id_mensaje: str = ""
    adjuntos: list[str] = []


class WebhookAlmacen(BaseModel):
    id_recojo: str
    coincide: bool
    detalle: str = ""
    cuerpo: str
    firma: str
