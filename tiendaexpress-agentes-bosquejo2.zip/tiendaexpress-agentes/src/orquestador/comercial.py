"""Subgrafo de la rama comercial (A3): calcular → [aprobar descuento] → emitir cotización.

Es un subgrafo para que la interrupción HITL del descuento no obligue a repetir el cálculo
(ni la llamada al LLM extractor) al reanudar: LangGraph retoma dentro del subgrafo.
Tiene su propio esquema de estado y solo devuelve `resultados_parciales`.
"""
from __future__ import annotations

from typing import Annotated, TypedDict

from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from src.agentes.a3_cotizador import agente as a3
from src.comun.base import formato_soles, registrar
from src.orquestador.estado import AprobacionDescuento, fusionar


class EstadoComercial(TypedDict, total=False):
    texto: str
    requiere: list[str]
    cliente_ref: str
    trace_id: str
    borrador: dict
    resultados_parciales: Annotated[dict, fusionar]


class SalidaComercial(TypedDict, total=False):
    resultados_parciales: Annotated[dict, fusionar]


async def calcular_precio(estado: EstadoComercial) -> dict:
    """«Calcular precio, promociones y cuotas» + «Cotizar envío y plazo con API courier»."""
    sku = None  # el SKU lo resuelve A3; si A2 corre en paralelo no se espera su resultado
    r = await a3.calcular(estado["texto"], estado.get("requiere", []), sku,
                          estado.get("cliente_ref", "CLI-00001"), trace_id=estado.get("trace_id", "-"))
    return {"borrador": r}


def ruta_descuento(estado: EstadoComercial) -> str:
    b = estado["borrador"]
    if b.get("necesita_aclaracion"):
        return "devolver_aclaracion"
    return "aprobar_descuento" if b.get("requiere_hitl") else "emitir_cotizacion"


def aprobar_descuento(estado: EstadoComercial) -> dict:
    """Coordinador Comercial: descuento > 10 % o rebaja sin promoción (contexto §4.1)."""
    b = estado["borrador"]
    r = AprobacionDescuento.model_validate(interrupt(
        {"tipo": "aprobacion_descuento", "cola": "coordinador_comercial", "sku": b["sku"],
         "descuento": str(b["descuento"]), "total": formato_soles(b["total"])},
        response_schema=AprobacionDescuento))
    registrar(estado.get("trace_id", "-"), "hitl", decision="descuento_aprobado" if r.aprobado else "descuento_rechazado")
    if r.aprobado:
        return {}
    return {"borrador": {**b, "descuento_rechazado": True}}


async def emitir_cotizacion(estado: EstadoComercial) -> dict:
    b = estado["borrador"]
    if b.get("descuento_rechazado"):
        return {"resultados_parciales": {"a3": {**b, "nota": "La rebaja solicitada no fue aprobada; "
                                                            "se mantiene el precio de lista o la promoción vigente."}}}
    cot = await a3.emitir_cotizacion(b, estado.get("cliente_ref", "CLI-00001"), estado.get("trace_id", "-"))
    return {"resultados_parciales": {"a3": {**b, "id_cotizacion": cot["id_cotizacion"], "vence": cot["vence"]}}}


def devolver_aclaracion(estado: EstadoComercial) -> dict:
    return {"resultados_parciales": {"a3": estado["borrador"]}}


_g = StateGraph(EstadoComercial, output_schema=SalidaComercial)
_g.add_node("calcular_precio", calcular_precio)
_g.add_node("aprobar_descuento", aprobar_descuento)
_g.add_node("emitir_cotizacion", emitir_cotizacion)
_g.add_node("devolver_aclaracion", devolver_aclaracion)
_g.add_edge(START, "calcular_precio")
_g.add_conditional_edges("calcular_precio", ruta_descuento,
                         ["aprobar_descuento", "emitir_cotizacion", "devolver_aclaracion"])
_g.add_edge("aprobar_descuento", "emitir_cotizacion")
_g.add_edge("emitir_cotizacion", END)
_g.add_edge("devolver_aclaracion", END)
rama_comercial = _g.compile(name="rama_comercial")
