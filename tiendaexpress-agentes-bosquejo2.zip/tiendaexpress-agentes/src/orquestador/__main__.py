"""Ejecutar el orquestador desde la terminal o el IDE.

  python -m src.orquestador --demo d1          # pre-venta completa hasta el pre-pedido
  python -m src.orquestador --demo d2          # devolución completa hasta el cierre
  python -m src.orquestador --mensaje "¿Tienen la Vivobook 15 en stock?"

Sin ANTHROPIC_API_KEY se activa MODO_SIMULADO (heurísticas, sin costo).
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import uuid

from dotenv import load_dotenv

load_dotenv()
if not os.getenv("ANTHROPIC_API_KEY"):
    os.environ.setdefault("MODO_SIMULADO", "1")

from langgraph.checkpoint.memory import InMemorySaver  # noqa: E402
from langgraph.types import Command  # noqa: E402

from src.agentes.a8_logistico.agente import firmar  # noqa: E402
from src.orquestador.grafo import construir  # noqa: E402


def mostrar(resultado: dict) -> dict | None:
    if resultado.get("respuesta"):
        print(f"\n  → Cliente recibe: {resultado['respuesta']}")
    for n in resultado.get("notificaciones", [])[-1:]:
        print(f"  → Notificación: {n.get('texto', n)}")
    pendientes = resultado.get("__interrupt__") or []
    if pendientes:
        valor = pendientes[0].value
        print(f"  ⏸  Hilo en espera: {json.dumps(valor, ensure_ascii=False, default=str)}")
        return valor
    print(f"  ✓ Fin. Estado consulta={resultado.get('estado')} caso={resultado.get('estado_caso')}")
    return None


async def correr(guion: list, entrada: dict) -> None:
    app = construir().compile(checkpointer=InMemorySaver())
    cfg = {"configurable": {"thread_id": str(uuid.uuid4())}, "tags": ["cli"]}
    print(f"\nCliente: {entrada['texto']}")
    espera = mostrar(await app.ainvoke({"entrada": entrada}, cfg))
    pasos = list(guion)
    while espera:
        if "action_requests" in espera:   # HITL de un Deep Agent (A7 antes de revertir_pago)
            valor = {"decisions": [{"type": "approve"}]}
        elif pasos:
            paso = pasos.pop(0)
            valor = paso(espera) if callable(paso) else paso
        else:
            break
        print(f"\n⏵  Reanudar con: {json.dumps(valor, ensure_ascii=False)}")
        espera = mostrar(await app.ainvoke(Command(resume=valor), cfg))


def webhook_ok(espera: dict) -> dict:
    cuerpo = json.dumps({"id_recojo": espera["id_recojo"], "estado": "OK"})
    return {"id_recojo": espera["id_recojo"], "coincide": True, "cuerpo": cuerpo, "firma": firmar(cuerpo)}


DEMOS = {
    "d1": ({"canal": "whatsapp", "id_mensaje": "wa-1",
            "texto": "Hola, me llamo Ana Torres. ¿Tienen la Vivobook 15 en stock y cuánto cuesta con envío a Miraflores?"},
           [{"evento": "mensaje", "texto": "Lo quiero, ¿cómo pago?", "id_mensaje": "wa-2"}]),
    "d2": ({"canal": "web", "id_mensaje": "web-1",
            "texto": "Me llegó roto el ventilador del pedido PED-10001, la caja venía golpeada.",
            "adjuntos": ["https://ejemplo.pe/fotos/ventilador-roto.jpg"]},
           [webhook_ok]),
    "d2-vencido": ({"canal": "web", "id_mensaje": "web-2",
                    "texto": "El celular del pedido PED-10002 llegó dañado.",
                    "adjuntos": ["https://ejemplo.pe/fotos/celular.jpg"]}, []),
    "d2-complejo": ({"canal": "web", "id_mensaje": "web-3",
                     "texto": "Mi ventilador del pedido PED-10001 no funciona.",
                     "adjuntos": ["https://ejemplo.pe/fotos/borrosa.jpg"]},
                    [{"veredicto": "aprobado", "motivo_veredicto": "Soporte confirmó la falla de fábrica."}, webhook_ok]),
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", choices=sorted(DEMOS))
    ap.add_argument("--mensaje")
    a = ap.parse_args()
    print(f"MODO_SIMULADO={os.getenv('MODO_SIMULADO', '0')}")
    if a.mensaje:
        asyncio.run(correr([], {"canal": "web", "id_mensaje": str(uuid.uuid4()), "texto": a.mensaje}))
    else:
        entrada, guion = DEMOS[a.demo or "d1"]
        asyncio.run(correr(guion, entrada))


if __name__ == "__main__":
    main()
