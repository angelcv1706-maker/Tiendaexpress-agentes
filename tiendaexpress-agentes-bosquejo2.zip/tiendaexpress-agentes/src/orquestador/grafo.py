"""Orquestador de TiendaExpress como grafo de LangGraph.

Un nodo por elemento BPMN, con su nombre en infinitivo (orquestador/AGENTS.md §3).
Las compuertas son funciones de ruteo: solo encaminan; la lógica vive en el agente previo.
Las esperas (cliente 24 h, webhook del almacén, cola HITL) son `interrupt()`; el hilo queda
guardado en el checkpointer y se reanuda con `Command(resume=...)`.
"""
from __future__ import annotations

import re
import uuid

from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from src.agentes.a0_recepcion import agente as a0
from src.agentes.a1_clasificador import agente as a1
from src.agentes.a2_asesor_rag import agente as a2
from src.agentes.a3_cotizador import agente as a3
from src.agentes.a4_agendador import agente as a4
from src.agentes.a5_calificador import agente as a5
from src.agentes.a6_validador import agente as a6
from src.agentes.a7_financiero import agente as a7
from src.agentes.a8_logistico import agente as a8
from src.agentes.a9_notificador import agente as a9
from src import deep_agents
from src.comun.base import ErrorManual, registrar
from src.comun.trazas import configurar_langsmith
from src.mcp_servers.cliente import llamar
from src.decision import TAU_AUTO, TAU_REV
from src.orquestador.comercial import rama_comercial
from src.orquestador.estado import (DecisionSoporte, Estado, EventoCliente, RespuestaAsesor,
                                    RevisionClasificacion, WebhookAlmacen)
from src.orquestador.redaccion import redactar

configurar_langsmith()   # trazas sin datos personales (src/comun/trazas.py)


# =================================================================== entrada (A0, A1)
async def recibir_consulta(estado: Estado) -> dict:
    """«Consulta recibida» + «Registrar consulta en historial» (A0)."""
    e = estado["entrada"]
    r = a0.recibir(e.get("canal", "web"), e.get("id_mensaje", str(uuid.uuid4())), e["texto"],
                   e.get("adjuntos"), e.get("cliente_ref", "CLI-00001"))
    if r["duplicado"]:
        return {"cerrar": True, "respuesta": "", "id_consulta": r["id_consulta"]}
    trace_id = estado.get("trace_id") or str(uuid.uuid4())
    registrar(trace_id, "a0", decision="recibida", id_consulta=r["id_consulta"])
    await llamar("a0", "crm", "buscar_cliente", trace_id=trace_id, cliente_ref=r["cliente_ref"])
    await llamar("a0", "crm", "registrar_interaccion", trace_id=trace_id,
                 id_consulta=estado.get("id_consulta") or r["id_consulta"], canal=r["canal"],
                 texto_enmascarado=r["texto_enmascarado"])
    return {"trace_id": trace_id, "id_consulta": estado.get("id_consulta") or r["id_consulta"],
            "canal": r["canal"], "cliente_ref": r["cliente_ref"], "texto": r["texto_enmascarado"],
            "adjuntos": r["adjuntos"], "historial": [r["texto_enmascarado"]], "cerrar": False,
            "revisado_por_humano": False, "estado": "RECIBIDA"}


def clasificar_intencion(estado: Estado) -> dict:
    c = a1.clasificar(estado["texto"], estado.get("historial", [])[-6:-1])
    registrar(estado["trace_id"], "a1", p=c["p"], decision=f"{c['dominio']}/{c['intencion']}")
    return {**{k: c[k] for k in ("dominio", "intencion", "requiere", "p")}, "estado": "CLASIFICADA"}


def revisar_clasificacion(estado: Estado) -> dict:
    """0,50 ≤ p < 0,80: una persona confirma o corrige antes de seguir."""
    r = interrupt({"tipo": "revision_clasificacion", "cola": "coordinador_atencion",
                   "propuesta": {k: estado.get(k) for k in ("dominio", "intencion", "requiere", "p")},
                   "texto": estado["texto"]}, response_schema=RevisionClasificacion)
    r = RevisionClasificacion.model_validate(r)
    cambios = {"revisado_por_humano": True}
    if not r.aprobar:
        cambios.update({k: v for k, v in r.model_dump().items() if k != "aprobar" and v})
    return cambios


def ruta_resoluble(estado: Estado) -> str:
    """Compuerta «¿Resoluble por agentes?» + compuerta HITL por confianza."""
    if estado.get("cerrar"):
        return END
    if not estado.get("revisado_por_humano"):
        if estado["p"] < TAU_REV:
            return "atender_consulta_compleja"
        if estado["p"] < TAU_AUTO:
            return "revisar_clasificacion"
    if estado["dominio"] == "fuera_de_alcance":
        return "responder_fuera_de_alcance"
    if estado["dominio"] == "devolucion":
        return "validar_garantia_y_fotos"
    if estado["intencion"] == "compleja":
        return "atender_consulta_compleja"
    if estado["intencion"] == "compra":
        return "registrar_prepedido"
    return "que_informacion_requiere"


def responder_fuera_de_alcance(estado: Estado) -> dict:
    return {"respuesta": "Esta consulta la atiende otro canal de TiendaExpress (por ejemplo, el Libro "
                         "de Reclamaciones o el servicio técnico del fabricante). ¿Le ayudo con algo más "
                         "sobre productos o devoluciones?", "cerrar": True}


# =================================================================== D1 · pre-venta
def que_informacion_requiere(estado: Estado) -> dict:
    """Compuerta inclusiva: solo prepara; el ruteo paralelo lo hace `ramas_requeridas`."""
    return {"resultados_parciales": {}}


def ramas_requeridas(estado: Estado) -> list[str]:
    req = set(estado.get("requiere") or [])
    if estado.get("intencion") == "demo" and not req:
        return ["consolidar_respuesta"]
    ramas = []
    if "producto" in req or not req:
        ramas.append("consultar_ficha_y_stock")
    if req & {"precio", "envio"}:
        ramas.append("calcular_precio_y_envio")
    return ramas


async def consultar_ficha_y_stock(estado: Estado) -> dict:
    """«Consultar ficha técnica y stock en ERP» + «Proponer productos alternativos» (A2)."""
    r = await a2.consultar(estado["texto"], trace_id=estado["trace_id"])
    return {"resultados_parciales": {"a2": r}}


def consolidar_respuesta(estado: Estado) -> dict:
    """Verifica que cada dato tenga fuente y redacta. Corre cuando TODAS las ramas terminaron."""
    rp = estado.get("resultados_parciales", {})
    for clave in ("a2", "a3"):
        if rp.get(clave, {}).get("necesita_aclaracion"):
            opciones = rp[clave].get("opciones") or []
            nombres = "; ".join(o["nombre"] for o in opciones) or "el producto exacto"
            return {"respuesta": f"Para ayudarle mejor, ¿se refiere a: {nombres}?"}
    if "a2" in rp:
        assert rp["a2"].get("stock_leido_en"), "stock sin fuente"
    if "a3" in rp:
        assert rp["a3"].get("id_cotizacion") or rp["a3"].get("descuento_rechazado"), "precio sin cotización"
    return {"respuesta": redactar(rp), "estado": "RESPONDIDA"}


async def actualizar_lead(estado: Estado) -> dict:
    """A5 recalcula el score con señales detectadas (el puntaje lo suma el código)."""
    rp = estado.get("resultados_parciales", {})
    monto = rp.get("a3", {}).get("total")
    senales = a5.detectar_senales(estado.get("intencion"), rp.get("a2", {}).get("stock"), monto,
                                  presupuesto_declarado=bool(re.search(r"presupuesto|hasta s/", estado["texto"], re.I)),
                                  interacciones_7d=len(estado.get("historial", [])),
                                  pidio_demo=estado.get("intencion") == "demo")
    r = await a5.actualizar(estado["cliente_ref"], senales, trace_id=estado["trace_id"])
    return {"lead_id": r["lead_id"], "lead_score": r["score"], "lead_calificado": r["calificado"]}


def ruta_lead(estado: Estado) -> str:
    """Propuesta para cerrar la brecha §13.1: «¿Lead calificado?» → «Agendar demo»."""
    if estado.get("intencion") == "demo":
        return "agendar_demo"
    return "enviar_respuesta"


async def agendar_demo(estado: Estado) -> dict:
    texto = estado["texto"].lower()
    elegido = re.search(r"opci[oó]n\s*([1-3])", texto)
    if elegido and estado.get("horarios_ofrecidos"):
        inicio = estado["horarios_ofrecidos"][int(elegido.group(1)) - 1]
        sku = (estado.get("resultados_parciales", {}).get("a2") or {}).get("sku", "")
        r = await a4.reservar(estado["lead_id"], sku, inicio, trace_id=estado["trace_id"])
        msg = f"Listo: su demo quedó reservada para el {r['texto']} ({r.get('id_cita')})." if r["reservado"] else r["motivo"]
        return {"respuesta": msg, "horarios_ofrecidos": []}
    r = await a4.ofrecer_horarios(estado["lead_id"], estado.get("lead_score", 0), trace_id=estado["trace_id"])
    if not r["permitido"]:
        extra = " Un asesor puede contactarle para coordinar." if "calificado" in r["motivo"] else ""
        return {"respuesta": (estado.get("respuesta") or "") + extra}
    opciones = " ".join(f"Opción {i + 1}: {t}." for i, t in enumerate(r["texto"]))
    return {"respuesta": f"{estado.get('respuesta') or ''} Podemos agendar una demo de 30 min. {opciones} "
                         "Responda con el número de opción.".strip(),
            "horarios_ofrecidos": r["horarios"]}


async def registrar_prepedido(estado: Estado) -> dict:
    cot = (estado.get("resultados_parciales", {}).get("a3") or {}).get("id_cotizacion")
    if not cot:
        return {"requiere": ["precio"], "respuesta": ""}
    r = await a3.registrar_prepedido(cot, trace_id=estado["trace_id"])
    if r.get("recotizar"):
        return {"requiere": ["precio"], "respuesta": ""}
    await a5.actualizar(estado["cliente_ref"], {"intencion"}, trace_id=estado["trace_id"])
    return {"respuesta": f"Registramos su pre-pedido {r['id_prepedido']}. Le enviaremos el enlace de pago.",
            "cerrar": True, "estado": "CONVERTIDA"}


def ruta_prepedido(estado: Estado) -> str:
    return "enviar_respuesta" if estado.get("cerrar") else "que_informacion_requiere"


def atender_consulta_compleja(estado: Estado) -> dict:
    """Asesor de Ventas humano vía cola HITL. El SLA de 2 h lo vigila un proceso externo (ver doc)."""
    r = interrupt({"tipo": "consulta_compleja", "cola": "asesor_ventas", "sla_h": 2,
                   "id_consulta": estado["id_consulta"], "texto": estado["texto"]},
                  response_schema=RespuestaAsesor)
    return {"respuesta": RespuestaAsesor.model_validate(r).respuesta, "estado": "EN_ASESOR"}


def enviar_respuesta(estado: Estado) -> dict:
    texto = a0.desenmascarar_propios(estado.get("respuesta", ""), estado["id_consulta"])
    registrar(estado["trace_id"], "a0", decision="respuesta_enviada")
    # Aquí: enviar por el mismo canal de entrada (WhatsApp Business / chat web).
    return {"respuesta": texto}


def ruta_tras_enviar(estado: Estado) -> str:
    return END if estado.get("cerrar") else "esperar_cliente"


def esperar_cliente(estado: Estado) -> dict:
    """Evento basado en compuerta: mensaje del cliente o temporizador de 24 h (lo dispara un cron)."""
    r = EventoCliente.model_validate(interrupt(
        {"tipo": "esperar_cliente", "id_consulta": estado["id_consulta"], "vence_en_h": 24},
        response_schema=EventoCliente))
    if r.evento == "sin_respuesta_24h":
        return {"entrada": {}, "estado": "NO_CONVERTIDA"}
    return {"entrada": {"canal": estado["canal"], "id_mensaje": r.id_mensaje or str(uuid.uuid4()),
                        "texto": r.texto, "adjuntos": r.adjuntos, "cliente_ref": estado["cliente_ref"]}}


def ruta_espera(estado: Estado) -> str:
    return "registrar_no_convertida" if estado.get("estado") == "NO_CONVERTIDA" else "recibir_consulta"


async def registrar_no_convertida(estado: Estado) -> dict:
    if estado.get("lead_id"):
        await a5.cerrar_no_convertida(estado["lead_id"], trace_id=estado["trace_id"])
    return {"cerrar": True}


# =================================================================== D2 · devoluciones
async def validar_garantia_y_fotos(estado: Estado) -> dict:
    m = re.search(r"PED-\d{5}", estado["texto"])
    validar = a6.validar
    if deep_agents.activos():   # A6 como Deep Agent (src/deep_agents/validador.py)
        from src.deep_agents.validador import validar
    r = await validar(m.group(0) if m else None, estado["texto"][:300], estado.get("adjuntos"),
                      trace_id=estado["trace_id"], reevaluacion=estado.get("reevaluacion", ""))
    registrar(estado["trace_id"], "a6", p=r.get("p"), decision=r["veredicto"])
    return {"id_caso": r.get("id_caso", ""), "pedido": r.get("pedido", m.group(0) if m else ""),
            "veredicto": r["veredicto"], "motivo_veredicto": r["motivo_veredicto"],
            "motivo_categoria": r.get("motivo_categoria", ""), "reevaluacion": "",
            "estado_caso": "EN_VALIDACION"}


def ruta_veredicto(estado: Estado) -> str:
    """«¿Veredicto aprobado?» y «¿Caso complejo?»."""
    return {"aprobado": "programar_recojo", "complejo": "atender_caso_complejo"}.get(
        estado["veredicto"], "notificar_rechazo")


def atender_caso_complejo(estado: Estado) -> dict:
    id_caso = estado.get("id_caso") or "SOL-pendiente"
    n = a9.notificar(id_caso, "caso_en_revision", {"id_caso": id_caso, "plazo_respuesta": "24 horas hábiles"})
    r = DecisionSoporte.model_validate(interrupt(
        {"tipo": "caso_complejo", "cola": "soporte_postventa", "id_caso": id_caso,
         "texto": estado["texto"], "adjuntos": estado.get("adjuntos", [])},
        response_schema=DecisionSoporte))
    return {"veredicto": r.veredicto, "motivo_veredicto": r.motivo_veredicto,
            "estado_caso": "EN_SOPORTE", "notificaciones": [n]}


def ruta_soporte(estado: Estado) -> str:
    return "programar_recojo" if estado["veredicto"] == "aprobado" else "notificar_rechazo"


def notificar_rechazo(estado: Estado) -> dict:
    n = a9.notificar(estado.get("id_caso") or "SOL-sin-caso", "devolucion_rechazada",
                     {"id_caso": estado.get("id_caso") or "(sin caso)",
                      "motivo_veredicto": estado["motivo_veredicto"],
                      "orientacion": "Si necesita ayuda adicional, responda este mensaje."})
    return {"notificaciones": [n], "estado_caso": "RECHAZADA", "cerrar": True}


async def programar_recojo(estado: Estado) -> dict:
    try:
        r = await a8.programar_recojo(estado["id_caso"], estado["pedido"], estado["veredicto"],
                                      trace_id=estado["trace_id"])
    except ErrorManual as e:
        return {"veredicto": "complejo", "motivo_veredicto": str(e)}
    n = a9.notificar(estado["id_caso"], "recojo_programado",
                     {"id_recojo": r["id_recojo"], "courier": r["courier"].capitalize(),
                      "fecha": r["fecha"], "ventana": r["ventana"]})
    return {"id_recojo": r["id_recojo"], "estado_caso": "RECOJO_PROGRAMADO", "notificaciones": [n]}


def ruta_recojo(estado: Estado) -> str:
    return "atender_caso_complejo" if estado["veredicto"] == "complejo" else "esperar_recepcion"


def esperar_recepcion(estado: Estado) -> dict:
    """El hilo se suspende hasta el webhook firmado «recepción OK» del almacén."""
    r = WebhookAlmacen.model_validate(interrupt(
        {"tipo": "webhook_almacen", "id_caso": estado["id_caso"], "id_recojo": estado["id_recojo"]},
        response_schema=WebhookAlmacen))
    return {"entrada": r.model_dump()}


async def actualizar_estado_recibido(estado: Estado) -> dict:
    w = estado["entrada"]
    r = await a8.procesar_webhook(estado["id_caso"], w["id_recojo"], w["coincide"], w["detalle"],
                                  w["cuerpo"], w["firma"], trace_id=estado["trace_id"])
    if r["estado"] == "REEVALUACION":
        return {"estado_caso": "REEVALUACION", "reevaluacion": r["detalle"] or "paquete no coincide"}
    if r["estado"] == "IGNORADO":
        return {}
    return {"estado_caso": "PRODUCTO_RECIBIDO"}


def ruta_recepcion(estado: Estado) -> str:
    return {"PRODUCTO_RECIBIDO": "procesar_reembolso", "REEVALUACION": "validar_garantia_y_fotos"}.get(
        estado["estado_caso"], "esperar_recepcion")


async def procesar_reembolso(estado: Estado) -> dict:
    caso = {"id_caso": estado["id_caso"], "pedido": estado["pedido"], "estado": estado["estado_caso"],
            "veredicto": estado["veredicto"], "motivo_categoria": estado.get("motivo_categoria", "transporte"),
            "pasos": (estado.get("reembolso") or {}).get("pasos", {}), "texto": estado.get("texto", "")[:200]}
    if deep_agents.activos():   # A7 como Deep Agent con HITL en revertir_pago
        from src.deep_agents.financiero import reembolsar
        r = await reembolsar(caso, trace_id=estado["trace_id"])
        if not r["completado"]:
            return {"reembolso": r, "estado_caso": "REEMBOLSO_PENDIENTE", "cerrar": True}
    else:
        r = await a7.reembolsar(caso, trace_id=estado["trace_id"])
    return {"reembolso": r, "estado_caso": "REEMBOLSADA"}


def notificar_comprobante(estado: Estado) -> dict:
    r = estado["reembolso"]
    n = a9.notificar(estado["id_caso"], "comprobante_reembolso",
                     {"id_reembolso": r["id_reembolso"], "monto": r["monto"], "medio": r["medio"].capitalize(),
                      "nota_credito": r["nota_credito"], "plazo_estimado": "de 5 a 15 días hábiles"})
    return {"notificaciones": [n]}


def cerrar_caso(estado: Estado) -> dict:
    registrar(estado["trace_id"], "orquestador", decision="CERRADA", id_caso=estado["id_caso"])
    return {"estado_caso": "CERRADA", "cerrar": True}


# =================================================================== ensamblaje
def construir() -> StateGraph:
    g = StateGraph(Estado)
    for nodo in [recibir_consulta, clasificar_intencion, revisar_clasificacion, responder_fuera_de_alcance,
                 que_informacion_requiere, consultar_ficha_y_stock, consolidar_respuesta, actualizar_lead,
                 agendar_demo, registrar_prepedido, atender_consulta_compleja, enviar_respuesta,
                 esperar_cliente, registrar_no_convertida, validar_garantia_y_fotos, atender_caso_complejo,
                 notificar_rechazo, programar_recojo, esperar_recepcion, actualizar_estado_recibido,
                 procesar_reembolso, notificar_comprobante, cerrar_caso]:
        g.add_node(nodo.__name__, nodo)
    g.add_node("calcular_precio_y_envio", rama_comercial)   # subgrafo con HITL de descuento

    g.add_edge(START, "recibir_consulta")
    g.add_conditional_edges("recibir_consulta", lambda s: END if s.get("cerrar") else "clasificar_intencion",
                            ["clasificar_intencion", END])
    destinos = ["atender_consulta_compleja", "revisar_clasificacion",
                "responder_fuera_de_alcance", "validar_garantia_y_fotos", "registrar_prepedido",
                "que_informacion_requiere", END]
    g.add_conditional_edges("clasificar_intencion", ruta_resoluble, destinos)
    g.add_conditional_edges("revisar_clasificacion", ruta_resoluble,
                            [d for d in destinos if d != "revisar_clasificacion"])
    g.add_edge("responder_fuera_de_alcance", "enviar_respuesta")

    # D1
    g.add_conditional_edges("que_informacion_requiere", ramas_requeridas,
                            ["consultar_ficha_y_stock", "calcular_precio_y_envio", "consolidar_respuesta"])
    g.add_edge("consultar_ficha_y_stock", "consolidar_respuesta")
    g.add_edge("calcular_precio_y_envio", "consolidar_respuesta")
    g.add_edge("consolidar_respuesta", "actualizar_lead")
    g.add_conditional_edges("actualizar_lead", ruta_lead, ["agendar_demo", "enviar_respuesta"])
    g.add_edge("agendar_demo", "enviar_respuesta")
    g.add_conditional_edges("registrar_prepedido", ruta_prepedido, ["enviar_respuesta", "que_informacion_requiere"])
    g.add_edge("atender_consulta_compleja", "enviar_respuesta")
    g.add_conditional_edges("enviar_respuesta", ruta_tras_enviar, ["esperar_cliente", END])
    g.add_conditional_edges("esperar_cliente", ruta_espera, ["registrar_no_convertida", "recibir_consulta"])
    g.add_edge("registrar_no_convertida", END)

    # D2
    g.add_conditional_edges("validar_garantia_y_fotos", ruta_veredicto,
                            ["programar_recojo", "atender_caso_complejo", "notificar_rechazo"])
    g.add_conditional_edges("atender_caso_complejo", ruta_soporte, ["programar_recojo", "notificar_rechazo"])
    g.add_edge("notificar_rechazo", END)
    g.add_conditional_edges("programar_recojo", ruta_recojo, ["esperar_recepcion", "atender_caso_complejo"])
    g.add_edge("esperar_recepcion", "actualizar_estado_recibido")
    g.add_conditional_edges("actualizar_estado_recibido", ruta_recepcion,
                            ["procesar_reembolso", "validar_garantia_y_fotos", "esperar_recepcion"])
    g.add_conditional_edges("procesar_reembolso",
                            lambda s: "notificar_comprobante" if s["estado_caso"] == "REEMBOLSADA" else END,
                            ["notificar_comprobante", END])
    g.add_edge("notificar_comprobante", "cerrar_caso")
    g.add_edge("cerrar_caso", END)
    return g


# `langgraph dev` / Studio inyectan su propio checkpointer: aquí se compila sin uno.
graph = construir().compile(name="tiendaexpress")
