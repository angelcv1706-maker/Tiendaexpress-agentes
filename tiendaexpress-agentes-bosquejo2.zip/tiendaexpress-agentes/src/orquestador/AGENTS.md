# AGENTS.md · Orquestador (Deep Agent supervisor)

> Hereda `/AGENTS.md`. Reglas: `docs/CONTEXTO_NEGOCIO.md` §6–§9. Carril BPMN: **Agente Orquestador** (D1 y D2).

## 1. Propósito
Recibe cada solicitud ya enmascarada por A0, pide a A1 la intención y su confianza `p`, y la enruta a D1 (pre-venta) o D2 (devolución). Lleva el estado del hilo de principio a fin.
- **D1:** abre en paralelo las consultas a A2 y A3 (según la información requerida), consolida, pide a A5 que actualice el lead y devuelve la respuesta a A0. Espera la confirmación del cliente o el temporizador de 24 h.
- **D2:** encadena A6 → (HITL) → A8 → espera del webhook de almacén → A7 → A9.
- **Fuera de alcance:** responder con conocimiento propio del dominio. Delega siempre.

## 2. Arquitectura
**Rutina D1** (TO-BE de pre-venta):
1. `decide(intencion)` ← A1. Si `p < 0,80` o la intención es «compleja», va a la compuerta HITL (asesor, SLA de 2 h).
2. Compuerta inclusiva «¿Qué información requiere?»: producto → A2; precio → A3; envío → A3 (`cotizar_envio`). Se lanzan en paralelo y **se espera a todas** las ramas abiertas.
3. «Consolidar respuesta y verificar datos»: comprueba que cada dato tenga su fuente (herramienta + hora). Si no hay stock → A2 propone alternativas.
4. A5 recalcula el lead score. Si es ≥ 60 y el cliente pidió demo → A4.
5. Envía la respuesta por A0 y queda en espera: confirmación → A3 `crear_prepedido`; 24 h sin respuesta → A5 `cerrar_lead`.

**Rutina D2** (TO-BE de devoluciones):
1. A6 emite el veredicto. Si es rechazado y el caso no es complejo → A9 notifica el rechazo. Si es complejo → Soporte (HITL).
2. Si es aprobado → A8 programa el recojo y el hilo **se suspende** hasta el webhook «recepción OK».
3. A8 marca `PRODUCTO_RECIBIDO`. Si el paquete no coincide → vuelve a A6 («Reevaluar caso»).
4. A7 reembolsa → A9 envía el comprobante → el caso queda `CERRADA`.

**Estado del hilo (LangGraph):** `{trace_id, dominio, intencion, p, id_consulta|id_caso, lead_id, resultados_parciales, estado}`. Se persiste con un *checkpointer* en PostgreSQL para sobrevivir a esperas de horas o días.

**Decisión:** las compuertas del BPMN son nodos condicionales del grafo y solo encaminan; la lógica vive en el agente previo (regla BPMN 4).

## 3. Convenciones
- Un nodo del grafo por elemento BPMN, con el **mismo nombre en infinitivo** (trazabilidad).
- Las esperas (24 h, SLA de 2 h, webhook) son interrupciones del grafo con temporizador, nunca `sleep`.
- Toda delegación registra `agente_destino`, `entrada_resumida` y `p`.

## 4. Comandos
```
python -m src.orquestador --dominio d1 --mensaje "¿Tienen la laptop X en stock?"
pytest tests/orquestador -q
```

## 5. Restricciones
- **No llamar a servidores MCP directamente;** se delega en el agente dueño. Previene escrituras sin el control del agente responsable.
- **No invocar a A7 antes de `PRODUCTO_RECIBIDO`.** Previene reembolsos sin devolución.
- **No consolidar con ramas inclusivas pendientes.** Previene respuestas con precio pero sin stock (o al revés).
- **No reintentar una delegación que ya escribió** sin su clave de idempotencia. Previene cotizaciones o reembolsos duplicados.
- **No continuar si `p < 0,50`;** se escala. Previene que el sistema adivine en casos ambiguos.
- **No mantener el hilo solo en memoria.** Previene perder casos durante esperas de 24 h o del webhook.
