---
name: bpmn-a-langgraph
description: Traducir un diagrama BPMN TO-BE (XML .bpmn, texto de Eraser o imagen) a un esqueleto de StateGraph de LangGraph con nodos, rutas, ramas paralelas e interrupt().
---

# BPMN → LangGraph

Convierte un proceso BPMN en un grafo de LangGraph 1.x sin perder trazabilidad: cada elemento del diagrama se encuentra en el código con el mismo nombre.

## 1. Leer el diagrama

- `.bpmn`: extraer `lane`, tareas, `exclusiveGateway`, `inclusiveGateway`, `parallelGateway`, `eventBasedGateway`, eventos timer/message, `sequenceFlow`, `messageFlow`.
- Texto de Eraser o imagen: listar carriles, tareas, compuertas y flujos; pedir confirmación si algo es ilegible.
- Mostrar la tabla de equivalencias al usuario antes de generar código.

## 2. Equivalencias

| BPMN | LangGraph |
|---|---|
| Tarea de carril de agente | Nodo en infinitivo, `snake_case` |
| Tarea de carril humano | Nodo con `interrupt(valor, response_schema=Modelo)` |
| Compuerta exclusiva | `add_conditional_edges(nodo, ruta, [destinos])` |
| Compuerta inclusiva | Ruta que devuelve una lista de nodos + nodo de unión; cada rama es un nodo o subgrafo |
| Compuerta paralela | Lista fija de destinos |
| Compuerta basada en eventos | `interrupt()` cuyo esquema distingue el evento + ruta según el evento |
| Temporizador | `interrupt()` + cron externo que reanuda; `interrupt()` no tiene reloj |
| Webhook entrante | `interrupt()`; se reanuda con `Command(resume=payload)` tras validar la firma |
| Subproceso | Subgrafo con su propio estado y `output_schema` |
| Bucle de retorno | Arista condicional hacia el nodo anterior; el `recursion_limit` corta bucles sin salida |
| Fin | `END` con el estado final guardado |

## 3. Generar

1. `estado.py`: `TypedDict` y un esquema Pydantic por cada `interrupt()`.
2. `grafo.py`: nodos con docstring «Elemento BPMN: …», rutas y `construir()`; exportar `graph = construir().compile()` para `langgraph.json`.
3. Exportar el diagrama desde el código: `graph.get_graph(xray=1).draw_mermaid()` y compararlo con el TO-BE.
4. Una prueba por camino: invocar, comprobar `__interrupt__`, reanudar y verificar el estado final.

## 4. Revisar

Cada elemento del BPMN tiene nodo o ruta; las compuertas no contienen lógica; ninguna espera usa `sleep`; señalar inconsistencias del modelo encontradas al traducir.
