---
name: tiendaexpress-agentes
description: Agregar, cambiar o revisar un agente, nodo, cadena LCEL, Deep Agent, herramienta MCP o regla del proyecto multiagente TiendaExpress (LangGraph + LangChain + Claude) respetando sus AGENTS.md.
---

# TiendaExpress · trabajar en el repositorio multiagente

Proyecto académico (UPAO 2026-20) que automatiza D1 «Atender consultas pre-venta» y D2 «Gestionar devoluciones y reembolsos» con un orquestador LangGraph y 10 agentes (A0–A9).

## 1. Leer antes de escribir

1. `/AGENTS.md` y `docs/CONTEXTO_NEGOCIO.md` (fuente de verdad del dominio).
2. El `AGENTS.md` del agente afectado en `src/agentes/<id>/` y, si cambia el flujo, `src/orquestador/AGENTS.md`.
3. Si hay conflicto, manda el más específico; si no se resuelve, preguntar.
4. Ubicar el elemento BPMN del TO-BE que corresponde (contexto §6 y §7).

## 2. Dónde va cada cosa

| Necesito… | Va en |
|---|---|
| Un paso del proceso | Nodo en `src/orquestador/grafo.py`, nombre en infinitivo igual a la tarea BPMN |
| Una compuerta BPMN | Función `ruta_*` que solo encamina, con su lista de destinos (si no, el grafo exportado sale incompleto) |
| Una espera (cliente, webhook, humano, temporizador) | `interrupt(valor, response_schema=Modelo)`; esquema en `src/orquestador/estado.py` |
| Una llamada a Claude | Cadena LCEL en `src/cadenas/` (`prompt | eslabon_modelo(...) | parser`) con `run_name` |
| Un umbral o límite | `src/decision/__init__.py`; nunca en un prompt |
| Un cálculo de dinero o puntaje | Código del agente (`calculo.py`, `puntaje.py`, `reglas.py`) con `Decimal` |
| Una llamada a un sistema externo | Servidor FastMCP en `src/mcp_servers/` + permiso en `PERMISOS` de `cliente.py` |
| Un Deep Agent | `src/deep_agents/`: herramientas que envuelven código, memoria = su `AGENTS.md`, skill propia en `skills/<agente>/`, `interrupt_on` para operaciones con dinero |

## 3. Reglas que no se negocian

- Claude solo clasifica, extrae, lee evidencia o redacta. Montos, puntajes, plazos y permisos los decide el código.
- Los agentes no se llaman entre sí; el orquestador delega. Todo acceso externo pasa por `cliente.py::llamar`.
- Toda escritura externa lleva clave de idempotencia. Las herramientas de un Deep Agent con HITL no guardan estado: al reanudar, el nodo se re-ejecuta.
- Nada sin enmascarar entra al grafo, a los logs ni a LangSmith.
- Nodos `async`: nada bloqueante (`langgraph dev` lanza `BlockingError`).

## 4. Procedimiento

1. Confirmar el elemento BPMN; si el TO-BE no lo modela, proponer el cambio al BPMN.
2. Actualizar el `AGENTS.md` del agente (Propósito, Arquitectura, Convenciones, Comandos, Restricciones con «Previene…»).
3. Implementar: reglas en código primero; Claude solo por una cadena LCEL.
4. Heurística equivalente en `src/simulado.py` para `MODO_SIMULADO=1`.
5. Conectar en `construir()`; si hay espera, su fila en la tabla de interrupciones de `BOSQUEJO.md`.
6. Pruebas límite y un recorrido del grafo con `InMemorySaver` y `Command(resume=...)`.
7. `pytest -q`, `python -m scripts.exportar_grafos` y, si cambió el flujo, `python -m scripts.ejecutar_langsmith --local`.

## 5. Al revisar un cambio

¿Una regla quedó en un prompt? ¿Escritura sin idempotencia? ¿Un agente llama a otro? ¿Una llamada a Claude fuera de `src/cadenas/`? ¿Falta la prueba límite? ¿Algún log recibe texto sin enmascarar? Reportar con archivo y línea.
