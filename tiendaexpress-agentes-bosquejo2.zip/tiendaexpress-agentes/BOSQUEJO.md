# Bosquejo ejecutable · TiendaExpress multiagente

> Bosquejo académico: datos, sistemas externos y políticas están **simulados**. Tómenlo como
> punto de partida para revisar con el equipo, no como código de producción. Probado el
> 29/10/2026 con Python 3.13, langgraph 1.2.18, langchain 1.4.7, langchain-anthropic 1.7.7.

Los `AGENTS.md` y `docs/` de su zip se conservan **sin cambios**. Lo nuevo es el código.

## Ejecutar en 5 minutos (VS Code o PyCharm)

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                 # Windows: copy .env.example .env
pytest -q                                            # 29 pruebas, sin API key
python -m src.orquestador --demo d1                  # pre-venta hasta el pre-pedido
python -m src.orquestador --demo d2                  # devolución hasta el cierre
langgraph dev                                        # abre LangGraph Studio con el grafo
python -m scripts.exportar_grafos                    # grafos a docs/grafos/ (.mmd y .png)
python -m scripts.ejecutar_langsmith                 # una corrida por las 4 capas + log en logs/
```

Con `MODO_SIMULADO=1` (por defecto en `.env.example`) no se llama a Claude: las decisiones
de A1, A2, A3 y A6 usan heurísticas. Para usar Claude, pongan `ANTHROPIC_API_KEY` y
`MODO_SIMULADO=0`. Para ver trazas, pongan `LANGSMITH_API_KEY`.

En Studio, inicien un hilo con esta entrada y reanuden cada interrupción desde la interfaz:

```json
{"entrada": {"canal": "web", "id_mensaje": "1", "texto": "Me llegó roto el ventilador del pedido PED-10001", "adjuntos": ["https://ejemplo.pe/foto.jpg"]}}
```

## Qué hay

| Ruta | Qué es |
|---|---|
| `src/cadenas/` | **Cadenas LCEL** (`prompt \| Claude \| parser`) de A1, A2, A3, A6 y la redacción |
| `src/deep_agents/` | **Deep Agents** A6 y A7 (`create_deep_agent`), sus skills y el HITL de `revertir_pago` |
| `scripts/` | `exportar_grafos.py` y `ejecutar_langsmith.py` |
| `docs/grafos/`, `docs/ecosistema_tiendaexpress.png` | Grafos exportados desde LangGraph y diagrama de capas |
| `.claude/skills/` | Skills para Claude Code: `tiendaexpress-agentes` y `bpmn-a-langgraph` |
| `src/orquestador/grafo.py` | El grafo: un nodo por tarea BPMN (en infinitivo), compuertas como funciones de ruteo |
| `src/orquestador/comercial.py` | Subgrafo de A3 con la interrupción HITL de descuento > 10 % |
| `src/orquestador/estado.py` | Estado del hilo y esquemas válidos para reanudar cada interrupción |
| `src/agentes/aN_*/agente.py` | Un agente por carpeta; `prompt.md` en los que usan Claude (A1, A2, A6) |
| `src/agentes/a3_cotizador/calculo.py`, `a5_calificador/puntaje.py`, `a6_validador/reglas.py` | Reglas de negocio en código |
| `src/decision/` | Umbrales τ_auto = 0,80 y τ_rev = 0,50; `p` por autoconsistencia + calibración |
| `src/mcp_servers/` | Servidores FastMCP simulados; `cliente.py` aplica la tabla «Quién escribe» |
| `src/conocimiento/` | RAG léxico en memoria (misma firma que la futura versión pgvector) |
| `src/simulado.py` | Heurísticas que reemplazan a Claude con `MODO_SIMULADO=1` |
| `evals/evaluar_a1.py` | Conjunto dorado y evaluadores de A1 en LangSmith |
| `tests/` | Reglas límite (día 7/8, score 59/60, 10 %/11 %…) y recorridos completos del grafo |

## Interrupciones del grafo (cómo se reanuda cada espera)

| Nodo | Quién responde | Reanudar con |
|---|---|---|
| `revisar_clasificacion` | Coordinador de Atención | `{"aprobar": true}` o `{"aprobar": false, "dominio": "...", "intencion": "..."}` |
| `atender_consulta_compleja` | Asesor de Ventas | `{"respuesta": "texto"}` |
| `aprobar_descuento` (subgrafo) | Coordinador Comercial | `{"aprobado": true}` |
| `esperar_cliente` | Cliente o cron de 24 h | `{"evento": "mensaje", "texto": "..."}` o `{"evento": "sin_respuesta_24h"}` |
| `atender_caso_complejo` | Soporte postventa | `{"veredicto": "aprobado", "motivo_veredicto": "..."}` |
| `revertir_pago` (Deep Agent A7) | Responsable financiero | `{"decisions": [{"type": "approve"}]}` o `reject` |
| `esperar_recepcion` | Webhook del almacén | `{"id_recojo", "coincide", "detalle", "cuerpo", "firma"}` (HMAC-SHA256) |

## Pendiente antes de producción

- Checkpointer PostgreSQL (`langgraph-checkpoint-postgres`) y pgvector reales.
- Cron que reanude con `sin_respuesta_24h` y alerta del SLA de 2 h (no los da `interrupt()`).
- Enmascarado de PII más robusto que expresiones regulares (nombres, direcciones libres).
- Conectores reales de WhatsApp Business, chat web, Niubiz/Culqi, Scharff/Olva y ERP.
- Calibrar `p` con las decisiones humanas guardadas; completar el conjunto dorado de 40 mensajes.
