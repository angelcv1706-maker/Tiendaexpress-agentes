"""Pruebas de las reglas que los AGENTS.md exigen en código (sin LLM)."""
from datetime import timedelta
from decimal import Decimal

import pytest

from src.agentes.a0_recepcion.agente import desenmascarar_propios, enmascarar, recibir
from src.agentes.a3_cotizador.calculo import cotizar
from src.agentes.a4_agendador.agente import horario_valido
from src.agentes.a5_calificador.puntaje import calcular
from src.agentes.a6_validador.reglas import dentro_de_plazo, validar_contrato, veredicto_final
from src.agentes.a7_financiero.agente import calcular_monto, verificar_precondiciones
from src.agentes.a9_notificador.agente import notificar, renderizar
from src.comun.base import ErrorDeDatos, ErrorManual, ahora, formato_soles
from src.decision import Ruta, ruta_por_confianza


# ---------------------------------------------------------------- decision (§9.1)
@pytest.mark.parametrize("p,ruta", [(0.80, Ruta.AUTOMATICO), (0.79, Ruta.REVISION),
                                    (0.50, Ruta.REVISION), (0.49, Ruta.ESCALAR)])
def test_umbrales_hitl(p, ruta):
    assert ruta_por_confianza(p) == ruta


# ---------------------------------------------------------------- A0
def test_a0_enmascara_pii_y_tarjeta():
    texto, tarjeta = enmascarar("Soy de DNI 45678912, cel 987 654 321, ana@correo.pe, "
                                "tarjeta 4111 1111 1111 1111", "CON-T1")
    assert "45678912" not in texto and "987 654 321" not in texto and "ana@correo.pe" not in texto
    assert "<TARJETA>" in texto and tarjeta


def test_a0_desenmascara_solo_el_nombre_propio():
    texto, _ = enmascarar("me llamo Ana Torres y mi DNI es 45678912", "CON-T2")
    salida = desenmascarar_propios(f"Hola {texto}", "CON-T2")
    assert "Ana Torres" in salida and "45678912" not in salida


def test_a0_no_duplica_reintentos_del_canal():
    r1 = recibir("whatsapp", "msg-99", "hola")
    r2 = recibir("whatsapp", "msg-99", "hola")
    assert r2["duplicado"] and r2["id_consulta"] == r1["id_consulta"]


# ---------------------------------------------------------------- A3
def test_a3_descuento_10_es_automatico():
    c = cotizar(Decimal("2499.00"), 1, Decimal("0.10"), None, False, codigo_promo="CYBER10")
    assert c["total"] == Decimal("2249.10") and not c["requiere_hitl"]


def test_descuento_mayor_10_va_a_hitl():
    c = cotizar(Decimal("2499.00"), 1, Decimal("0.11"), None, False, codigo_promo="X")
    assert c["requiere_hitl"]


def test_a3_rebaja_sin_promocion_va_a_hitl():
    assert cotizar(Decimal("100"), 1, Decimal("0"), None, False, pide_rebaja=True)["requiere_hitl"]


def test_a3_envio_gratis_desde_299_en_lima():
    assert cotizar(Decimal("299.00"), 1, Decimal("0"), Decimal("12"), True)["envio"] == Decimal("0.00")
    assert cotizar(Decimal("298.99"), 1, Decimal("0"), Decimal("12"), True)["envio"] == Decimal("12.00")
    assert cotizar(Decimal("500.00"), 1, Decimal("0"), Decimal("25"), False)["envio"] == Decimal("25.00")


def test_a3_volumen_pasa_a_asesor():
    with pytest.raises(ErrorManual):
        cotizar(Decimal("100"), 6, Decimal("0"), None, False)


def test_formato_soles():
    assert formato_soles(Decimal("1299")) == "S/ 1 299,00"


# ---------------------------------------------------------------- A4
def _proximo(dia_semana: int, hora: int, minuto: int = 0):
    base = ahora() + timedelta(days=1)
    while base.weekday() != dia_semana:
        base += timedelta(days=1)
    return base.replace(hour=hora, minute=minuto, second=0, microsecond=0)


def test_a4_limites_de_horario():
    assert horario_valido(_proximo(1, 17, 30))        # termina 18:00 exacto
    assert not horario_valido(_proximo(1, 18, 0))     # empieza 18:00
    assert not horario_valido(_proximo(6, 11, 0))     # domingo
    ref = _proximo(2, 10, 0)                          # miércoles 10:00
    assert not horario_valido(ref + timedelta(hours=1, minutes=59), ref)   # 1 h 59 min de anticipación
    assert horario_valido(ref + timedelta(hours=2), ref)                   # 2 h exactas


# ---------------------------------------------------------------- A5
def test_a5_score_59_vs_60_y_sin_duplicar():
    score, d = calcular({}, {"intencion", "stock", "monto"})
    assert score == 60
    score2, _ = calcular(d, {"intencion"})
    assert score2 == 60                                # la misma señal no suma dos veces
    assert calcular({}, {"intencion", "stock", "recurrencia"})[0] == 55


# ---------------------------------------------------------------- A6
def test_a6_contrato():
    assert validar_contrato("PED-1", "roto", []) is not None             # sin fotos
    assert validar_contrato("PED-1", "x" * 301, ["u"]) is not None       # 301 caracteres
    assert validar_contrato("PED-1", "x" * 300, ["u"]) is None           # 300 caracteres


def test_a6_dia_7_vs_dia_8():
    assert dentro_de_plazo((ahora() - timedelta(days=7)).isoformat())
    assert not dentro_de_plazo((ahora() - timedelta(days=8)).isoformat())


def test_a6_p_baja_es_complejo_aunque_el_motivo_sea_valido():
    assert veredicto_final("transporte", True, True, False, False, 0.49)[0] == "complejo"
    assert veredicto_final("mal_uso", True, True, False, False, 0.95)[0] == "rechazado"
    assert veredicto_final("transporte", True, True, False, False, 0.95)[0] == "aprobado"


# ---------------------------------------------------------------- A7
def test_no_reembolsa_sin_recepcion():
    with pytest.raises(ErrorDeDatos):
        verificar_precondiciones({"estado": "RECOJO_PROGRAMADO", "veredicto": "aprobado"})


def test_a7_monto_nunca_supera_lo_pagado():
    assert calcular_monto(Decimal("149.90"), Decimal("15"), Decimal("164.90"), True) == Decimal("164.90")
    with pytest.raises(ErrorManual):
        calcular_monto(Decimal("200"), Decimal("15"), Decimal("164.90"), True)


# ---------------------------------------------------------------- A9
def test_a9_no_envia_con_campo_faltante_ni_dos_veces():
    with pytest.raises(ValueError):
        renderizar("comprobante_reembolso", {"nombre": "x", "id_reembolso": "REEM-1"})
    datos = {"id_caso": "SOL-T", "plazo_respuesta": "24 h"}
    assert notificar("SOL-T", "caso_en_revision", datos)["estado"] == "entregado"
    assert notificar("SOL-T", "caso_en_revision", datos)["estado"] == "omitido"


# ---------------------------------------------------------------- trazas (LangSmith)
def test_trazas_sin_datos_personales_pero_con_ids():
    from src.comun.trazas import anonimizador

    entrada = {"entrada": {"texto": "Hola, me llamo Ana Torres, DNI 45678912, cel 987 654 321, ana@correo.pe"},
               "id_consulta": "CON-20261102-0001", "trace": "01a18a34-cb2e-73ff-905c-b8fa70f0de55"}
    salida = anonimizador()(entrada)
    texto = salida["entrada"]["texto"]
    for dato in ("Ana Torres", "45678912", "987 654 321", "ana@correo.pe"):
        assert dato not in texto
    assert salida["id_consulta"] == "CON-20261102-0001" and salida["trace"] == entrada["trace"]
