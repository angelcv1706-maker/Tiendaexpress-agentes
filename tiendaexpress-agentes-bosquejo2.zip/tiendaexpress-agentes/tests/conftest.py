import os

import pytest

os.environ["MODO_SIMULADO"] = "1"   # las pruebas nunca llaman a Claude ni gastan tokens
os.environ["LANGSMITH_TRACING"] = "false"
# Por defecto, A6 y A7 sin Deep Agents; las pruebas de Deep Agents lo activan con monkeypatch.
# Se fija aquí porque .env.example trae USAR_DEEP_AGENTS=1 y load_dotenv() lo cargaría.
os.environ["USAR_DEEP_AGENTS"] = "0"


@pytest.fixture(autouse=True)
def _estado_limpio():
    """Aísla cada prueba: vacía los almacenes en memoria que simulan las bases de datos."""
    from src.agentes.a6_validador import agente as a6
    from src.agentes.a8_logistico import agente as a8
    from src.agentes.a9_notificador import agente as a9
    from src.datos import simulados as db
    a6._CASOS_POR_CLAVE.clear(); a8._WEBHOOKS_PROCESADOS.clear(); a9._ENVIADOS.clear()
    for almacen in (db.CASOS, db.COTIZACIONES, db.DEMOS, db.REEMBOLSOS, db.IDEMPOTENCIA):
        almacen.clear()
    db.INTERACCIONES.clear()
    yield
