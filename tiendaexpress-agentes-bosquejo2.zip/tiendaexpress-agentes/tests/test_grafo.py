"""Recorridos completos del grafo en MODO_SIMULADO (sin LLM), incluidas las interrupciones."""
import json
import uuid

import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from src.agentes.a8_logistico.agente import firmar
from src.datos import simulados as db
from src.mcp_servers.cliente import llamar
from src.orquestador.grafo import construir


def _app():
    return construir().compile(checkpointer=InMemorySaver()), {"configurable": {"thread_id": str(uuid.uuid4())}}


def _espera(r):
    return r["__interrupt__"][0].value if r.get("__interrupt__") else None


@pytest.mark.asyncio
async def test_d1_hasta_prepedido():
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "¿Tienen la Vivobook 15 en stock y cuánto cuesta con envío a Miraflores?"}}, cfg)
    assert "S/ 2 249,10" in r["respuesta"] and _espera(r)["tipo"] == "esperar_cliente"
    r = await app.ainvoke(Command(resume={"evento": "mensaje", "texto": "Lo quiero, ¿cómo pago?"}), cfg)
    assert r["estado"] == "CONVERTIDA" and "pre-pedido" in r["respuesta"]


@pytest.mark.asyncio
async def test_d1_sin_respuesta_24h_cierra_no_convertida():
    app, cfg = _app()
    await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()), "texto": "¿Tienen la HP 15 en stock?"}}, cfg)
    r = await app.ainvoke(Command(resume={"evento": "sin_respuesta_24h"}), cfg)
    assert r["estado"] == "NO_CONVERTIDA" and r["cerrar"]


@pytest.mark.asyncio
async def test_d2_completo_y_reembolso_incluye_envio_por_transporte():
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "Me llegó roto el ventilador del pedido PED-10001",
                                       "adjuntos": ["https://x/foto.jpg"]}}, cfg)
    w = _espera(r)
    assert w["tipo"] == "webhook_almacen"
    cuerpo = json.dumps({"id_recojo": w["id_recojo"]})
    r = await app.ainvoke(Command(resume={"id_recojo": w["id_recojo"], "coincide": True,
                                          "cuerpo": cuerpo, "firma": firmar(cuerpo)}), cfg)
    assert r["estado_caso"] == "CERRADA"
    assert str(r["reembolso"]["monto"]) == "164.90"


@pytest.mark.asyncio
async def test_d2_paquete_que_no_coincide_vuelve_a_validacion():
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "Llegó dañado el ventilador, pedido PED-10001",
                                       "adjuntos": ["https://x/foto2.jpg"]}}, cfg)
    w = _espera(r)
    cuerpo = json.dumps({"id_recojo": w["id_recojo"], "n": 2})
    r = await app.ainvoke(Command(resume={"id_recojo": w["id_recojo"] + "-B", "coincide": False,
                                          "detalle": "llegó otro modelo", "cuerpo": cuerpo,
                                          "firma": firmar(cuerpo)}), cfg)
    assert r.get("estado_caso") != "REEMBOLSADA" and "reembolso" not in r


@pytest.mark.asyncio
async def test_webhook_sin_firma_no_libera_reembolso():
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "Me llegó roto el ventilador del pedido PED-10001",
                                       "adjuntos": ["https://x/foto3.jpg"]}}, cfg)
    w = _espera(r)
    with pytest.raises(PermissionError):
        await app.ainvoke(Command(resume={"id_recojo": w["id_recojo"], "coincide": True,
                                          "cuerpo": "{}", "firma": "falsa"}), cfg)


@pytest.mark.asyncio
async def test_permisos_mcp_a3_no_puede_programar_recojo():
    with pytest.raises(PermissionError):
        await llamar("a3", "courier", "programar_recojo", id_caso="SOL-1", distrito="Miraflores",
                     direccion="x", courier="olva", ventana="09:00–13:00")


@pytest.mark.asyncio
async def test_d2_con_deep_agents_pide_aprobacion_antes_de_revertir(monkeypatch):
    """USAR_DEEP_AGENTS=1: A6 y A7 corren como Deep Agents; revertir_pago pausa el grafo (HITL)."""
    monkeypatch.setenv("USAR_DEEP_AGENTS", "1")
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "Me llegó roto el ventilador del pedido PED-10001",
                                       "adjuntos": ["https://x/foto4.jpg"]}}, cfg)
    w = _espera(r)
    cuerpo = json.dumps({"id_recojo": w["id_recojo"], "deep": True})
    r = await app.ainvoke(Command(resume={"id_recojo": w["id_recojo"], "coincide": True,
                                          "cuerpo": cuerpo, "firma": firmar(cuerpo)}), cfg)
    hitl = _espera(r)
    assert hitl["action_requests"][0]["name"] == "revertir_pago"
    assert not db.REEMBOLSOS                       # todavía no se movió dinero
    r = await app.ainvoke(Command(resume={"decisions": [{"type": "approve"}]}), cfg)
    assert r["estado_caso"] == "CERRADA" and str(r["reembolso"]["monto"]) == "164.90"


@pytest.mark.asyncio
async def test_deep_agent_a7_rechazo_humano_no_reembolsa(monkeypatch):
    monkeypatch.setenv("USAR_DEEP_AGENTS", "1")
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "Me llegó roto el ventilador del pedido PED-10001",
                                       "adjuntos": ["https://x/foto5.jpg"]}}, cfg)
    w = _espera(r)
    cuerpo = json.dumps({"id_recojo": w["id_recojo"], "deep": 2})
    await app.ainvoke(Command(resume={"id_recojo": w["id_recojo"], "coincide": True,
                                      "cuerpo": cuerpo, "firma": firmar(cuerpo)}), cfg)
    r = await app.ainvoke(Command(resume={"decisions": [{"type": "reject", "message": "Monto por revisar"}]}), cfg)
    assert r["estado_caso"] == "REEMBOLSO_PENDIENTE" and not db.REEMBOLSOS


@pytest.mark.asyncio
async def test_a0_registra_la_consulta_en_el_historial_enmascarada():
    """BPMN D1 «Registrar consulta en historial»: va al CRM, y sin datos personales."""
    app, cfg = _app()
    await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                   "texto": "Soy DNI 45678912, ¿tienen la HP 15 en stock?"}}, cfg)
    assert len(db.INTERACCIONES) == 1 and "45678912" not in db.INTERACCIONES[0]["texto"]


@pytest.mark.asyncio
async def test_autorizacion_de_reembolso_muestra_monto_y_opciones(monkeypatch):
    """Sin firma en blanco: quien aprueba ve acción, efecto, motivo, caso original y opciones."""
    monkeypatch.setenv("USAR_DEEP_AGENTS", "1")
    app, cfg = _app()
    r = await app.ainvoke({"entrada": {"id_mensaje": str(uuid.uuid4()),
                                       "texto": "Me llegó roto el ventilador del pedido PED-10001",
                                       "adjuntos": ["https://x/foto6.jpg"]}}, cfg)
    w = _espera(r)
    cuerpo = json.dumps({"id_recojo": w["id_recojo"], "n": 6})
    r = await app.ainvoke(Command(resume={"id_recojo": w["id_recojo"], "coincide": True,
                                          "cuerpo": cuerpo, "firma": firmar(cuerpo)}), cfg)
    texto = _espera(r)["action_requests"][0]["description"]
    for parte in ("Acción:", "Efecto:", "Motivo de la detención:", "Caso original:", "Opciones:", "S/ 164,90"):
        assert parte in texto
    r = await app.ainvoke(Command(resume={"decisions": [{"type": "reject", "message": "Falta foto del embalaje"}]}), cfg)
    assert "Falta foto del embalaje" in r["reembolso"]["motivo"]
