"""Una ejecución por TODAS las capas del ecosistema LangChain, trazada en LangSmith.

  python -m scripts.ejecutar_langsmith            # requiere LANGSMITH_API_KEY en .env
  python -m scripts.ejecutar_langsmith --local    # sin LangSmith: solo el log local

Recorre:
  - LangChain Core: cadenas LCEL de A1, A2, A3, A6 y redacción (src/cadenas/)
  - LangGraph: el grafo del orquestador, con sus interrupciones (HITL, webhook, cliente)
  - Deep Agents: A6 y A7 (src/deep_agents/), con aprobación humana antes de revertir_pago
  - LangSmith: cada invocación queda como traza en el proyecto LANGSMITH_PROJECT

Deja dos archivos en logs/:
  - langsmith_<fecha>.json   árbol de runs descargado de LangSmith (+ URL de cada traza)
  - local_<fecha>.json       el mismo árbol capturado en local con RunCollectorCallbackHandler
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()
os.environ.setdefault("USAR_DEEP_AGENTS", "1")
if not os.getenv("ANTHROPIC_API_KEY"):
    os.environ["MODO_SIMULADO"] = "1"

from langchain_core.tracers.langchain import wait_for_all_tracers  # noqa: E402
from langchain_core.tracers.run_collector import RunCollectorCallbackHandler  # noqa: E402
from langgraph.checkpoint.memory import InMemorySaver  # noqa: E402
from langgraph.types import Command  # noqa: E402

from src.agentes.a8_logistico.agente import firmar  # noqa: E402
from src.orquestador.grafo import construir  # noqa: E402

LOGS = Path(__file__).resolve().parents[1] / "logs"
PROYECTO = os.getenv("LANGSMITH_PROJECT", "tiendaexpress-agentes")


def resumir_run(run, nivel: int = 0) -> dict:
    """Árbol compacto: nombre, tipo, estado, duración, tokens e hijos."""
    dur = (run.end_time - run.start_time).total_seconds() if run.end_time else None
    return {"nombre": run.name, "tipo": run.run_type, "error": run.error,
            "duracion_s": round(dur, 3) if dur is not None else None,
            "tokens": getattr(run, "total_tokens", None),
            "hijos": [resumir_run(h, nivel + 1) for h in sorted(run.child_runs or [], key=lambda r: r.start_time)]}


async def correr(colector: RunCollectorCallbackHandler) -> list[dict]:
    """D2 completo (con Deep Agents y aprobación) y D1 hasta el pre-pedido."""
    app = construir().compile(checkpointer=InMemorySaver())
    eventos = []

    async def paso(entrada, cfg, etiqueta):
        r = await app.ainvoke(entrada, cfg)
        espera = r["__interrupt__"][0].value if r.get("__interrupt__") else None
        eventos.append({"paso": etiqueta, "espera": espera, "respuesta": r.get("respuesta"),
                        "estado_caso": r.get("estado_caso"), "estado": r.get("estado")})
        print(f"  {etiqueta}: espera={espera and (espera.get('tipo') or 'aprobacion_humana')}")
        return espera

    # ---- D2: devolución con Deep Agents A6/A7
    hilo = f"d2-{uuid.uuid4().hex[:8]}"
    cfg = {"configurable": {"thread_id": hilo}, "callbacks": [colector], "recursion_limit": 50,
           "tags": ["tiendaexpress", "d2", "entregable-langsmith"],
           "metadata": {"proceso": "D2", "empresa": "TiendaExpress"}, "run_name": "TiendaExpress-D2"}
    print(f"D2 · hilo {hilo}")
    w = await paso({"entrada": {"canal": "web", "id_mensaje": hilo,
                                "texto": "Me llegó roto el ventilador del pedido PED-10001, la caja venía golpeada.",
                                "adjuntos": ["https://ejemplo.pe/fotos/ventilador-roto.jpg"]}}, cfg, "1-solicitud")
    cuerpo = json.dumps({"id_recojo": w["id_recojo"], "estado": "OK"})
    w = await paso(Command(resume={"id_recojo": w["id_recojo"], "coincide": True, "cuerpo": cuerpo,
                                   "firma": firmar(cuerpo)}), cfg, "2-webhook-almacen")
    if w and "action_requests" in w:   # HITL del Deep Agent A7 antes de revertir_pago
        await paso(Command(resume={"decisions": [{"type": "approve"}]}), cfg, "3-aprobacion-reembolso")

    # ---- D1: pre-venta hasta el pre-pedido
    hilo = f"d1-{uuid.uuid4().hex[:8]}"
    cfg = {**cfg, "configurable": {"thread_id": hilo}, "tags": ["tiendaexpress", "d1", "entregable-langsmith"],
           "metadata": {"proceso": "D1", "empresa": "TiendaExpress"}, "run_name": "TiendaExpress-D1"}
    print(f"D1 · hilo {hilo}")
    await paso({"entrada": {"canal": "whatsapp", "id_mensaje": hilo,
                            "texto": "Hola, me llamo Ana Torres (cel 987 654 321). ¿Tienen la Vivobook 15 en stock "
                                      "y cuánto cuesta con envío a Miraflores?"}}, cfg, "1-consulta")
    await paso(Command(resume={"evento": "mensaje", "texto": "Lo quiero, ¿cómo pago?"}), cfg, "2-confirmacion")
    return eventos


def descargar_de_langsmith(inicio: datetime) -> dict:
    from langsmith import Client

    cliente = Client()
    trazas = []
    for raiz in cliente.list_runs(project_name=PROYECTO, is_root=True, start_time=inicio):
        runs = list(cliente.list_runs(project_name=PROYECTO, trace_id=raiz.trace_id))
        trazas.append({
            "nombre": raiz.name, "url": cliente.get_run_url(run=raiz, project_name=PROYECTO),
            "estado": raiz.status, "error": raiz.error, "tags": raiz.tags,
            "duracion_s": (raiz.end_time - raiz.start_time).total_seconds() if raiz.end_time else None,
            "tokens_totales": raiz.total_tokens, "costo_usd": float(raiz.total_cost or 0),
            "runs": [{"nombre": r.name, "tipo": r.run_type, "estado": r.status, "padre": str(r.parent_run_id),
                      "tokens": r.total_tokens, "error": r.error} for r in sorted(runs, key=lambda r: r.dotted_order or "")],
        })
    return {"proyecto": PROYECTO, "trazas": trazas}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--local", action="store_true", help="no enviar ni descargar de LangSmith")
    a = ap.parse_args()
    usar_langsmith = not a.local and bool(os.getenv("LANGSMITH_API_KEY"))
    os.environ["LANGSMITH_TRACING"] = "true" if usar_langsmith else "false"
    os.environ.setdefault("LANGSMITH_PROJECT", PROYECTO)
    print(f"LangSmith={'sí, proyecto ' + PROYECTO if usar_langsmith else 'no'} · "
          f"MODO_SIMULADO={os.getenv('MODO_SIMULADO', '0')} · USAR_DEEP_AGENTS={os.getenv('USAR_DEEP_AGENTS')}")

    LOGS.mkdir(exist_ok=True)
    marca = datetime.now().strftime("%Y%m%d_%H%M%S")
    inicio = datetime.now(timezone.utc)
    colector = RunCollectorCallbackHandler()
    eventos = asyncio.run(correr(colector))

    local = {"generado": marca, "eventos": eventos,
             "trazas": [resumir_run(r) for r in colector.traced_runs]}
    (LOGS / f"local_{marca}.json").write_text(json.dumps(local, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"Log local: logs/local_{marca}.json ({len(colector.traced_runs)} trazas raíz)")

    if usar_langsmith:
        wait_for_all_tracers()
        time.sleep(5)   # LangSmith indexa las trazas en unos segundos
        try:
            remoto = descargar_de_langsmith(inicio)
            (LOGS / f"langsmith_{marca}.json").write_text(json.dumps(remoto, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
            print(f"Log de LangSmith: logs/langsmith_{marca}.json")
            for t in remoto["trazas"]:
                print(f"  {t['nombre']}: {t['url']}")
        except Exception as e:   # sin red, clave inválida, región distinta…
            print(f"No pude descargar de LangSmith ({e}). Revisen LANGSMITH_API_KEY y LANGSMITH_ENDPOINT.")


if __name__ == "__main__":
    main()
