"""Exporta los grafos compilados a Mermaid (.mmd) y PNG en docs/grafos/.

  python -m scripts.exportar_grafos          # .mmd siempre; .png si está instalado mmdc (Mermaid CLI)

Los diagramas salen del código, no se dibujan a mano: si el grafo cambia, se regeneran.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

os.environ.setdefault("MODO_SIMULADO", "1")
os.environ.setdefault("USAR_DEEP_AGENTS", "1")

from src.deep_agents import financiero  # noqa: E402
from src.orquestador.comercial import rama_comercial  # noqa: E402
from src.orquestador.grafo import construir  # noqa: E402

SALIDA = Path(__file__).resolve().parents[1] / "docs" / "grafos"

CASO_EJEMPLO = {"id_caso": "SOL-00001", "pedido": "PED-10001", "estado": "PRODUCTO_RECIBIDO",
                "veredicto": "aprobado", "motivo_categoria": "transporte"}


def main() -> None:
    SALIDA.mkdir(parents=True, exist_ok=True)
    grafos = {
        "01_orquestador": construir().compile().get_graph(),
        "02_orquestador_con_subgrafos": construir().compile().get_graph(xray=1),
        "03_rama_comercial_a3": rama_comercial.get_graph(),
        "04_deep_agent_a7_financiero": financiero.construir(CASO_EJEMPLO).get_graph(),
    }
    mmdc = shutil.which("mmdc")
    for nombre, g in grafos.items():
        mmd = SALIDA / f"{nombre}.mmd"
        mmd.write_text(g.draw_mermaid(), encoding="utf-8")
        if mmdc:
            subprocess.run([mmdc, "-i", str(mmd), "-o", str(SALIDA / f"{nombre}.png"), "-b", "white", "-s", "2"],
                           check=True, capture_output=True)
        print(f"{nombre}: {len(g.nodes)} nodos, {len(g.edges)} aristas")


if __name__ == "__main__":
    main()
